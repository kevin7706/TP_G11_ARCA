-- Base independiente para este TP. No borra ninguna base ni tabla.
CREATE DATABASE IF NOT EXISTS tpgrupal_arca CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
-- Configurar DB_USER y DB_PASSWORD con un usuario que tenga permisos sobre esta base.
