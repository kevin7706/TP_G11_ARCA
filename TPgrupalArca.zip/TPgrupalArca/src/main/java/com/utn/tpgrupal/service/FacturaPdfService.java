package com.utn.tpgrupal.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.zxing.*;
import com.google.zxing.qrcode.QRCodeWriter;
import com.lowagie.text.*;
import com.lowagie.text.pdf.*;
import com.utn.tpgrupal.entities.FacturaVenta;
import com.utn.tpgrupal.exception.RecursoNoEncontradoException;
import com.utn.tpgrupal.service.arca.*;
import jakarta.persistence.EntityManager;
import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class FacturaPdfService {
    private final EntityManager em;
    private final EmisionArcaService emision;
    private final ObjectMapper json;
    public FacturaPdfService(EntityManager em, EmisionArcaService emision, ObjectMapper json) { this.em = em; this.emision = emision; this.json = json; }
    @Transactional(readOnly = true)
    public byte[] generar(Long id) {
        FacturaVenta f = em.find(FacturaVenta.class, id);
        if (f == null) throw new RecursoNoEncontradoException("Factura no encontrada");
        Comprobante c = emision.datosImpresion(id);
        try (var out = new ByteArrayOutputStream()) {
            Document doc = new Document(PageSize.A4, 36, 36, 35, 35);
            PdfWriter writer = PdfWriter.getInstance(doc, out);
            writer.setPageEvent(new PdfPageEventHelper() {
                @Override public void onEndPage(PdfWriter w, Document d) {
                    ColumnText.showTextAligned(w.getDirectContent(), Element.ALIGN_CENTER,
                            new Phrase("HOMOLOGACION - Comprobante de prueba | Pagina " + w.getPageNumber(), FontFactory.getFont(FontFactory.HELVETICA, 9)), 297, 20, 0);
                }
            });
            doc.open();
            boolean autorizada = f.getCae() != null && !f.getCae().isBlank();
            doc.add(new Paragraph(autorizada ? "FACTURA " + letra(c.tipo()) : "VISTA PREVIA - NO AUTORIZADA", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18)));
            doc.add(new Paragraph("HOMOLOGACION ARCA - SIN VALIDEZ FISCAL", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10)));
            doc.add(new Paragraph(c.emisor() + " | CUIT: " + c.cuit()));
            doc.add(new Paragraph(c.domicilioEmisor() + " | " + c.ivaEmisor()));
            doc.add(new Paragraph("IIBB: " + c.iibb() + " | Inicio de actividades: " + c.inicioActividades()));
            doc.add(new Paragraph("Punto de venta: " + String.format("%05d", c.puntoVenta()) + " | Numero: " + (autorizada ? String.format("%08d", f.getNumero()) : "Pendiente") + " | Fecha: " + c.fecha()));
            doc.add(new Paragraph("Cliente: " + c.receptor() + " | Documento: " + c.documento()));
            doc.add(new Paragraph("Domicilio: " + c.domicilioReceptor() + " | Condicion IVA receptor (codigo): " + c.condicionIvaReceptor()));
            doc.add(new Paragraph(" "));
            PdfPTable tabla = new PdfPTable(new float[]{4, 1, 2, 1, 1, 2});
            tabla.setWidthPercentage(100);
            for (String h : new String[]{"Descripcion", "Cant.", "P. unitario", "Dto.%", "IVA%", "Subtotal"}) tabla.addCell(new Phrase(h, FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10)));
            tabla.setHeaderRows(1);
            for (var i : c.items()) {
                for (String valor : new String[]{i.descripcion(), String.valueOf(i.cantidad()), importe(i.precio()), String.valueOf(i.descuento()), String.valueOf(i.alicuota()), importe(i.subtotal())}) tabla.addCell(new Phrase(valor == null ? "" : valor, FontFactory.getFont(FontFactory.HELVETICA, 10)));
            }
            doc.add(tabla);
            if (autorizada) {
                PdfPTable pie = new PdfPTable(new float[]{1, 3}); pie.setWidthPercentage(100); pie.setKeepTogether(true); pie.setSpacingBefore(14);
                PdfPCell totales = new PdfPCell(new Phrase("Neto: " + importe(c.neto()) + " | IVA: " + importe(c.iva())
                        + "\nTOTAL " + c.moneda() + ": " + importe(c.total()), FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12)));
                totales.setColspan(2); totales.setBorder(Rectangle.NO_BORDER); totales.setPaddingBottom(10); pie.addCell(totales);
                pie.addCell(new PdfPCell(qr(c, f), false));
                pie.addCell("CAE: " + f.getCae() + "\nVencimiento CAE: " + new java.text.SimpleDateFormat("yyyy-MM-dd").format(f.getCaeFechaVencimiento()) + "\nDocumento emitido en entorno de homologacion.");
                doc.add(pie);
            } else {
                doc.add(new Paragraph("Neto: " + importe(c.neto()) + " | IVA: " + importe(c.iva())));
                doc.add(new Paragraph("TOTAL " + c.moneda() + ": " + importe(c.total()), FontFactory.getFont(FontFactory.HELVETICA_BOLD, 14)));
            }
            doc.close();
            return out.toByteArray();
        } catch (Exception e) { throw new IllegalStateException("No se pudo generar la factura PDF", e); }
    }
    private Image qr(Comprobante c, FacturaVenta f) throws Exception {
        Map<String, Object> datos = new LinkedHashMap<>();
        datos.put("ver", 1); datos.put("fecha", c.fecha()); datos.put("cuit", Long.parseLong(c.cuit())); datos.put("ptoVta", c.puntoVenta());
        datos.put("tipoCmp", c.tipo()); datos.put("nroCmp", f.getNumero()); datos.put("importe", c.total()); datos.put("moneda", c.moneda()); datos.put("ctz", 1);
        datos.put("tipoDocRec", c.tipoDocumento()); datos.put("nroDocRec", Long.parseLong(c.documento())); datos.put("tipoCodAut", "E"); datos.put("codAut", Long.parseLong(f.getCae()));
        String url = "https://www.arca.gob.ar/fe/qr/?p=" + Base64.getEncoder().encodeToString(json.writeValueAsString(datos).getBytes(StandardCharsets.UTF_8));
        var matrix = new QRCodeWriter().encode(url, BarcodeFormat.QR_CODE, 220, 220);
        byte[] pixeles = new byte[220 * 220];
        for (int y = 0; y < 220; y++) for (int x = 0; x < 220; x++) pixeles[y * 220 + x] = (byte) (matrix.get(x, y) ? 0 : 255);
        Image image = Image.getInstance(220, 220, 1, 8, pixeles); image.scaleToFit(115, 115); return image;
    }
    private static String letra(int tipo) { return tipo == 1 ? "A" : tipo == 11 ? "C" : "B"; }
    private static String importe(BigDecimal importe) { return importe.setScale(2, java.math.RoundingMode.HALF_UP).toPlainString(); }
}
