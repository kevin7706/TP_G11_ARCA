package com.utn.tpgrupal.rest;

import com.utn.tpgrupal.dto.catalogo.ArticuloPrecioResumenDTO;
import com.utn.tpgrupal.dto.catalogo.ClienteResumenDTO;
import com.utn.tpgrupal.dto.catalogo.CondicionIvaResumenDTO;
import com.utn.tpgrupal.dto.catalogo.ListaPrecioResumenDTO;
import com.utn.tpgrupal.dto.catalogo.PuntoVentaResumenDTO;
import com.utn.tpgrupal.dto.catalogo.TipoMonedaResumenDTO;
import com.utn.tpgrupal.service.CatalogoService;
import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/catalogos")
public class CatalogoRestController {
    private final CatalogoService catalogoService;

    public CatalogoRestController(CatalogoService catalogoService) {
        this.catalogoService = catalogoService;
    }

    /**
     * Listas de precio. Sin parametros devuelve todas; con {@code q} filtra
     * por codigo o denominacion.
     */
    @GetMapping("/listas-precio")
    public List<ListaPrecioResumenDTO> listasPrecio(
            @RequestParam(required = false) String q) {
        return catalogoService.listarListasPrecio(q);
    }

    /**
     * Clientes. Sin parametros devuelve todos; con {@code q} filtra por
     * denominacion o cuit/cuil.
     */
    @GetMapping("/clientes")
    public List<ClienteResumenDTO> clientes(@RequestParam(required = false) String q) {
        return catalogoService.listarClientes(q);
    }

    @GetMapping("/condiciones-iva")
    public List<CondicionIvaResumenDTO> condicionesIva() {
        return catalogoService.listarCondicionesIva();
    }

    @GetMapping("/puntos-venta")
    public List<PuntoVentaResumenDTO> puntosVenta() {
        return catalogoService.listarPuntosVenta();
    }

    @GetMapping("/tipos-moneda")
    public List<TipoMonedaResumenDTO> tiposMoneda() {
        return catalogoService.listarTiposMoneda();
    }

    /**
     * Articulos con su precio de venta. El precio pertenece a la lista precio
     * articulo, por eso se puede acotar con {@code listaPrecioId}; con
     * {@code q} se filtra por codigo o denominacion del articulo.
     */
    @GetMapping("/articulos")
    public List<ArticuloPrecioResumenDTO> articulos(
            @RequestParam(required = false) Long listaPrecioId,
            @RequestParam(required = false) String q) {
        return catalogoService.listarArticulos(listaPrecioId, q);
    }
}
