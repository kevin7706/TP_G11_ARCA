package com.utn.tpgrupal.dto.catalogo;

public record PuntoVentaResumenDTO(Long id, Integer numero, String descripcion) {
}
