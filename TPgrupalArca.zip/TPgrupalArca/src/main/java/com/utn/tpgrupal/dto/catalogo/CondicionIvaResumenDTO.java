package com.utn.tpgrupal.dto.catalogo;
public record CondicionIvaResumenDTO(Long id, String denominacion, Integer codigoAfip) {
    public CondicionIvaResumenDTO(Long id, String denominacion) { this(id, denominacion, null); }
}
