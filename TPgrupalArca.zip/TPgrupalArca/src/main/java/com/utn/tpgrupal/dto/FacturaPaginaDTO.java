package com.utn.tpgrupal.dto;
import java.util.List;
public record FacturaPaginaDTO(List<FacturaReporteDTO> contenido, int pagina, int tamanio,
        long totalElementos, int totalPaginas) {}
