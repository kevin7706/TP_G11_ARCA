package com.utn.tpgrupal.validation;

import com.utn.tpgrupal.exception.DatosInvalidosException;
import java.util.Set;

public record DocumentoFiscal(int tipo, String numero) {
    public static DocumentoFiscal validar(Integer tipo, String numero) {
        if (tipo == null || !Set.of(80, 86, 87, 96, 99).contains(tipo))
            throw new DatosInvalidosException("Seleccione un tipo de documento valido: CUIT, CUIL, CDI, DNI o sin identificar");
        String limpio = numero == null ? "" : numero.strip().replaceAll("[ .-]", "");
        if (!limpio.matches("[0-9]+")) throw new DatosInvalidosException("El documento debe contener numeros; no se admiten letras");
        if (tipo == 99) {
            if (!"0".equals(limpio)) throw new DatosInvalidosException("Sin identificar requiere documento 0");
        } else if (tipo == 96) {
            if (!limpio.matches("[0-9]{7,8}") || Long.parseLong(limpio) == 0)
                throw new DatosInvalidosException("El DNI debe tener 7 u 8 digitos y ser mayor que cero");
        } else if (!identificadorValido(limpio)) {
            throw new DatosInvalidosException("CUIT/CUIL/CDI invalido: revise sus 11 digitos y el digito verificador");
        }
        return new DocumentoFiscal(tipo, limpio);
    }
    public static boolean identificadorValido(String numero) {
        if (numero == null || !numero.matches("[0-9]{11}") || numero.equals("00000000000")) return false;
        int[] pesos = {5,4,3,2,7,6,5,4,3,2};
        int suma = 0;
        for (int i = 0; i < 10; i++) suma += (numero.charAt(i) - '0') * pesos[i];
        int digito = 11 - suma % 11;
        if (digito == 11) digito = 0;
        if (digito == 10) return false;
        return digito == numero.charAt(10) - '0';
    }
}
