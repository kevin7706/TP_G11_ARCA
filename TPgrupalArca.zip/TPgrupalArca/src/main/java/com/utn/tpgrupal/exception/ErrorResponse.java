package com.utn.tpgrupal.exception;

import java.time.LocalDateTime;

/**
 * Cuerpo uniforme de error de la API.
 *
 * <p>Formato tomado del ejemplo del profesor
 * (EjemploAplicacionControllerAdvice.pdf): status + mensaje + fecha.
 * Lo devuelve el {@code GlobalExceptionHandler} para todas las excepciones
 * de negocio y de validación.
 */
public class ErrorResponse {
    private int status;
    private String mensaje;
    private LocalDateTime fecha;

    public ErrorResponse(int status, String mensaje) {
        this.status = status;
        this.mensaje = mensaje;
        this.fecha = LocalDateTime.now();
    }

    public int getStatus() {
        return status;
    }

    public String getMensaje() {
        return mensaje;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }
}
