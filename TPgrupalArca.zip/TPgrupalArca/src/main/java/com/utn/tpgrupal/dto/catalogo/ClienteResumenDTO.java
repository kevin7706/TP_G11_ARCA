package com.utn.tpgrupal.dto.catalogo;

public record ClienteResumenDTO(Long id, String denominacion, String cuitCuil,
        Integer tipoDocumento, String numeroDocumento, Integer codigoCondicionIva, Boolean datosEjemplo) {
    public ClienteResumenDTO(Long id, String denominacion, String cuitCuil) {
        this(id, denominacion, cuitCuil, null, null, null, false);
    }
}
