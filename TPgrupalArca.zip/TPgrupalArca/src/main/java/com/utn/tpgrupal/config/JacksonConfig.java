package com.utn.tpgrupal.config;

import java.util.TimeZone;
import org.springframework.boot.autoconfigure.jackson.Jackson2ObjectMapperBuilderCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Las fechas de la facturacion son fechas puras (sin hora) y la base de
 * datos las guarda en columnas DATE, sin zona horaria.
 *
 * <p>Por defecto Jackson trabaja con UTC mientras que Hibernate escribe la
 * columna DATE usando la zona horaria del servidor. Esa diferencia hace que
 * una factura enviada con la fecha 2026-10-21 se guarde como 2026-10-20 (el
 * instante UTC medianoche cae en el dia anterior en hora local).
 *
 * <p>Configurando Jackson con la misma zona horaria que usa la persistencia,
 * el ida y vuelta por JSON conserva la fecha tal como la manda el cliente.
 */
@Configuration
public class JacksonConfig {

    @Bean
    public Jackson2ObjectMapperBuilderCustomizer fechaSinZonaHorariaCustomizer() {
        return builder -> builder.timeZone(TimeZone.getDefault());
    }
}
