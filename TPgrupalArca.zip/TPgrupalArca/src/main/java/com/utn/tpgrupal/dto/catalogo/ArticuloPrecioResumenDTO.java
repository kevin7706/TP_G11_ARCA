package com.utn.tpgrupal.dto.catalogo;

public record ArticuloPrecioResumenDTO(
        Long listaPrecioArticuloId,
        Long articuloId,
        String codigo,
        String denominacion,
        Double precioVenta,
        Long listaPrecioId,
        String listaPrecioDenominacion) {
}
