package com.utn.tpgrupal.dto;

import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class FacturaReporteDTO {
    private Long id;
    private Long numeroFactura;
    @com.fasterxml.jackson.annotation.JsonFormat(pattern = "yyyy-MM-dd")
    private Date fechaEmision;
    private String clienteDenominacion;
    private String condicionIva;
    private String puntoVentaDescripcion;
    private String estado;
    private double importeTotal;
    private long cantidadItems;
    private String cae;
    @com.fasterxml.jackson.annotation.JsonFormat(pattern = "yyyy-MM-dd")
    private Date caeFechaVencimiento;
    private String motivoRechazo;

    public FacturaReporteDTO(Long id, Long numeroFactura, Date fechaEmision, String clienteDenominacion,
            String condicionIva, String puntoVentaDescripcion, String estado, double importeTotal, long cantidadItems) {
        this.id = id; this.numeroFactura = numeroFactura; this.fechaEmision = fechaEmision;
        this.clienteDenominacion = clienteDenominacion; this.condicionIva = condicionIva;
        this.puntoVentaDescripcion = puntoVentaDescripcion; this.estado = estado;
        this.importeTotal = importeTotal; this.cantidadItems = cantidadItems;
    }
}
