package com.utn.tpgrupal.service;

import com.utn.tpgrupal.dto.catalogo.ArticuloPrecioResumenDTO;
import com.utn.tpgrupal.dto.catalogo.ClienteResumenDTO;
import com.utn.tpgrupal.dto.catalogo.CondicionIvaResumenDTO;
import com.utn.tpgrupal.dto.catalogo.ListaPrecioResumenDTO;
import com.utn.tpgrupal.dto.catalogo.PuntoVentaResumenDTO;
import com.utn.tpgrupal.dto.catalogo.TipoMonedaResumenDTO;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class CatalogoService {
    private final EntityManager entityManager;

    public CatalogoService(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    /**
     * Lista de precios de venta. Si se pasa {@code q} filtra por codigo o por
     * denominacion (no distingue mayusculas).
     */
    @Transactional(readOnly = true)
    public List<ListaPrecioResumenDTO> listarListasPrecio(String q) {
        StringBuilder jpql = new StringBuilder("""
                SELECT new com.utn.tpgrupal.dto.catalogo.ListaPrecioResumenDTO(
                    lp.id, lp.codigo, lp.denominacion)
                FROM ListaPrecio lp
                WHERE 1 = 1
                """);
        Map<String, Object> parametros = new HashMap<>();

        if (q != null && !q.isBlank()) {
            jpql.append(" AND (LOWER(lp.codigo) LIKE :q OR LOWER(lp.denominacion) LIKE :q)");
            parametros.put("q", patronBusqueda(q));
        }

        jpql.append(" ORDER BY lp.codigo");

        TypedQuery<ListaPrecioResumenDTO> query = entityManager.createQuery(
                jpql.toString(), ListaPrecioResumenDTO.class);
        parametros.forEach(query::setParameter);
        return query.getResultList();
    }

    /** Lista de precios sin filtro: atajo de {@code listarListasPrecio(null)}. */
    @Transactional(readOnly = true)
    public List<ListaPrecioResumenDTO> listarListasPrecio() {
        return listarListasPrecio(null);
    }

    /**
     * Clientes. Si se pasa {@code q} filtra por denominacion o por cuit/cuil
     * (no distingue mayusculas).
     */
    @Transactional(readOnly = true)
    public List<ClienteResumenDTO> listarClientes(String q) {
        StringBuilder jpql = new StringBuilder("""
                SELECT new com.utn.tpgrupal.dto.catalogo.ClienteResumenDTO(
                    c.id, c.denominacion, c.cuitCuil, c.tipoDocumento, c.numeroDocumento, c.codigoCondicionIva, c.datosEjemplo)
                FROM Cliente c
                WHERE 1 = 1
                """);
        Map<String, Object> parametros = new HashMap<>();

        if (q != null && !q.isBlank()) {
            jpql.append(" AND (LOWER(c.denominacion) LIKE :q OR LOWER(c.cuitCuil) LIKE :q OR c.numeroDocumento LIKE :q)");
            parametros.put("q", patronBusqueda(q));
        }

        jpql.append(" ORDER BY c.denominacion");

        TypedQuery<ClienteResumenDTO> query = entityManager.createQuery(
                jpql.toString(), ClienteResumenDTO.class);
        parametros.forEach(query::setParameter);
        return query.getResultList();
    }

    /** Clientes sin filtro: atajo de {@code listarClientes(null)}. */
    @Transactional(readOnly = true)
    public List<ClienteResumenDTO> listarClientes() {
        return listarClientes(null);
    }

    @Transactional(readOnly = true)
    public List<CondicionIvaResumenDTO> listarCondicionesIva() {
        return entityManager.createQuery("""
                SELECT new com.utn.tpgrupal.dto.catalogo.CondicionIvaResumenDTO(
                    ci.id, ci.denominacion, ci.codigoAfip)
                FROM CondicionIva ci
                ORDER BY ci.denominacion
                """, CondicionIvaResumenDTO.class).getResultList();
    }

    @Transactional(readOnly = true)
    public List<PuntoVentaResumenDTO> listarPuntosVenta() {
        return entityManager.createQuery("""
                SELECT new com.utn.tpgrupal.dto.catalogo.PuntoVentaResumenDTO(
                    pv.id, pv.numero, pv.descripcion)
                FROM PuntoVenta pv
                ORDER BY pv.numero
                """, PuntoVentaResumenDTO.class).getResultList();
    }

    @Transactional(readOnly = true)
    public List<TipoMonedaResumenDTO> listarTiposMoneda() {
        return entityManager.createQuery("""
                SELECT new com.utn.tpgrupal.dto.catalogo.TipoMonedaResumenDTO(
                    tm.id, tm.denominacion, tm.simbolo)
                FROM TipoMoneda tm
                ORDER BY tm.denominacion
                """, TipoMonedaResumenDTO.class).getResultList();
    }

    /**
     * Articulos con su precio de venta. El precio vive en la lista precio
     * articulo, asi que el filtro por {@code listaPrecioId} es el que define
     * de que lista se toman los precios. Si se pasa {@code q} filtra por codigo
     * o por denominacion del articulo (no distingue mayusculas).
     */
    @Transactional(readOnly = true)
    public List<ArticuloPrecioResumenDTO> listarArticulos(Long listaPrecioId, String q) {
        StringBuilder jpql = new StringBuilder("""
                SELECT new com.utn.tpgrupal.dto.catalogo.ArticuloPrecioResumenDTO(
                    lpa.id, a.id, a.codigo, a.denominacion, lpa.precioVenta,
                    lp.id, lp.denominacion)
                FROM ListaPrecioArticulo lpa
                JOIN lpa.articulo a
                JOIN lpa.listaPrecio lp
                WHERE 1 = 1
                """);
        Map<String, Object> parametros = new HashMap<>();

        if (listaPrecioId != null) {
            jpql.append(" AND lp.id = :listaPrecioId");
            parametros.put("listaPrecioId", listaPrecioId);
        }
        if (q != null && !q.isBlank()) {
            jpql.append(" AND (LOWER(a.codigo) LIKE :q OR LOWER(a.denominacion) LIKE :q)");
            parametros.put("q", patronBusqueda(q));
        }

        jpql.append(" ORDER BY a.denominacion, lp.denominacion");

        TypedQuery<ArticuloPrecioResumenDTO> query = entityManager.createQuery(
                jpql.toString(), ArticuloPrecioResumenDTO.class);
        parametros.forEach(query::setParameter);
        return query.getResultList();
    }

    /** Articulos sin filtro: atajo de {@code listarArticulos(null, null)}. */
    @Transactional(readOnly = true)
    public List<ArticuloPrecioResumenDTO> listarArticulos() {
        return listarArticulos(null, null);
    }

    /**
     * Arma el patron del LIKE escapando los comodines, para que un texto
     * buscado con {@code %} o {@code _} no matchee de mas.
     */
    private String patronBusqueda(String texto) {
        return "%" + texto.trim().toLowerCase()
                .replace("\\", "\\\\")
                .replace("%", "\\%")
                .replace("_", "\\_") + "%";
    }
}
