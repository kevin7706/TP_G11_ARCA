package com.utn.tpgrupal.rest;
import com.utn.tpgrupal.service.ClienteFiscalService;
import com.utn.tpgrupal.dto.catalogo.ClienteResumenDTO;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("/api/catalogos/clientes")
public class ClienteFiscalController {
    private final ClienteFiscalService service;
    public ClienteFiscalController(ClienteFiscalService service) { this.service = service; }
    @PutMapping("/{id}/datos-fiscales")
    public ClienteResumenDTO actualizar(@PathVariable Long id, @RequestBody ClienteFiscalService.Solicitud solicitud) {
        return service.actualizar(id, solicitud);
    }
}
