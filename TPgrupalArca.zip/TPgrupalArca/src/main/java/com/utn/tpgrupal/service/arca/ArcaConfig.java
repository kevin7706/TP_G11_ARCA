package com.utn.tpgrupal.service.arca;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import com.utn.tpgrupal.exception.DatosInvalidosException;

@Component
public class ArcaConfig {
    @Value("${arca.habilitada:false}") public boolean habilitada;
    @Value("${arca.cuit:}") public String cuit;
    @Value("${arca.clave:}") public String clave;
    @Value("${arca.certificado:}") public String certificado;
    @Value("${arca.tipo-comprobante:6}") public int tipoComprobante;
    @Value("${arca.emisor-razon-social:Emisor de prueba}") public String razonSocial;
    @Value("${arca.emisor-domicilio:}") public String domicilio;
    @Value("${arca.emisor-condicion-iva:}") public String condicionIva;
    @Value("${arca.emisor-iibb:}") public String iibb;
    @Value("${arca.emisor-inicio-actividades:}") public String inicioActividades;

    @Value("${arca.limite-sin-identificar:10000000}")
    public java.math.BigDecimal limiteSinIdentificar = new java.math.BigDecimal("10000000");

    public void validar() {
        if (!habilitada) throw new DatosInvalidosException("ARCA no esta habilitada. Configure las credenciales propias de homologacion; no se generan CAE simulados.");
        if (!cuit.matches("[0-9]{11}") || clave.isBlank() || certificado.isBlank())
            throw new DatosInvalidosException("Configure CUIT, clave privada y certificado de homologacion");
        if (tipoComprobante != 1 && tipoComprobante != 6 && tipoComprobante != 11)
            throw new DatosInvalidosException("Este TP admite facturas A (1), B (6) y C (11) de productos en pesos");
        if (razonSocial.isBlank() || domicilio.isBlank() || condicionIva.isBlank())
            throw new DatosInvalidosException("Complete los datos fiscales del emisor para imprimir el comprobante");
    }
}
