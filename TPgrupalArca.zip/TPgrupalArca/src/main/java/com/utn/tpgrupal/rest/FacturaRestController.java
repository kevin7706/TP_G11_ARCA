package com.utn.tpgrupal.rest;

import com.utn.tpgrupal.dto.FacturaEdicionDTO;
import com.utn.tpgrupal.dto.FacturaReporteDTO;
import com.utn.tpgrupal.dto.FacturaRequestDTO;
import com.utn.tpgrupal.service.FacturaService;
import java.net.URI;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/facturas")
public class FacturaRestController {

    private final FacturaService facturaService;

    private final com.utn.tpgrupal.service.arca.EmisionArcaService emision;
    private final com.utn.tpgrupal.service.FacturaPdfService pdf;
    public FacturaRestController(FacturaService facturaService,
            com.utn.tpgrupal.service.arca.EmisionArcaService emision,
            com.utn.tpgrupal.service.FacturaPdfService pdf) {
        this.facturaService = facturaService; this.emision = emision; this.pdf = pdf;
    }

    @PostMapping("/{id}/informar-arca")
    public ResponseEntity<Void> informarArca(@PathVariable Long id) {
        emision.informar(id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/{id}/verificar-arca")
    public ResponseEntity<Void> verificarArca(@PathVariable Long id) {
        emision.verificar(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{id}/pdf")
    public ResponseEntity<byte[]> imprimir(@PathVariable Long id) {
        return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=factura-" + id + ".pdf")
                .contentType(MediaType.APPLICATION_PDF).body(pdf.generar(id));
    }

    @GetMapping
    public ResponseEntity<com.utn.tpgrupal.dto.FacturaPaginaDTO> buscarFacturas(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaDesde,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaHasta,
            @RequestParam(required = false) String estado,
            @RequestParam(required = false) Double montoMinimo,
            @RequestParam(required = false) Long numero,
            @RequestParam(required = false) Long clienteId,
            @RequestParam(required = false) Boolean informada,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        return ResponseEntity.ok(facturaService.buscarPagina(aFecha(fechaDesde), aFecha(fechaHasta),
                estado, montoMinimo, numero, clienteId, informada, page, size));
    }

    @GetMapping("/exportar/excel")
    public ResponseEntity<byte[]> exportarExcel(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaDesde,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaHasta,
            @RequestParam(required = false) String estado,
            @RequestParam(required = false) Double montoMinimo,
            @RequestParam(required = false) Long numero,
            @RequestParam(required = false) Long clienteId,
            @RequestParam(required = false) Boolean informada) {

        byte[] contenido = facturaService.generarReporteExcel(
                aFecha(fechaDesde), aFecha(fechaHasta), estado, montoMinimo, numero, clienteId, informada);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=reporte-facturas.xlsx")
                .contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                .body(contenido);
    }

    @GetMapping("/exportar/pdf")
    public ResponseEntity<byte[]> exportarPdf(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaDesde,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaHasta,
            @RequestParam(required = false) String estado,
            @RequestParam(required = false) Double montoMinimo,
            @RequestParam(required = false) Long numero,
            @RequestParam(required = false) Long clienteId,
            @RequestParam(required = false) Boolean informada) {

        byte[] contenido = facturaService.generarReportePdf(
                aFecha(fechaDesde), aFecha(fechaHasta), estado, montoMinimo, numero, clienteId, informada);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=reporte-facturas.pdf")
                .contentType(MediaType.APPLICATION_PDF)
                .body(contenido);
    }

    @GetMapping("/{id}")
    public ResponseEntity<FacturaEdicionDTO> obtener(@PathVariable Long id) {
        return ResponseEntity.ok(facturaService.obtener(id));
    }

    /**
     * Alta de factura: 201 Created con el FacturaReporteDTO generado y la
     * cabecera Location apuntando al recurso recien creado.
     */
    @PostMapping
    public ResponseEntity<FacturaReporteDTO> crear(@RequestBody FacturaRequestDTO dto) {
        FacturaReporteDTO reporte = facturaService.crear(dto);
        return ResponseEntity
                .created(URI.create("/api/facturas/" + reporte.getId()))
                .body(reporte);
    }

    /**
     * Actualizacion de la factura. El cuerpo es una actualizacion parcial
     * controlada: los campos en null no se tocan y la lista de detalles, si
     * viene, reconcilia los renglones existentes con los recibidos.
     */
    @PutMapping("/{id}")
    public ResponseEntity<FacturaReporteDTO> actualizar(
            @PathVariable Long id, @RequestBody FacturaRequestDTO dto) {
        return ResponseEntity.ok(facturaService.actualizar(id, dto));
    }

    /**
     * Anulacion logica de la factura (criterio AFIP): la comprobante no se
     * borra, cambia de estado a ANULADA y se le asigna la fecha de anulacion.
     * Responde 204 No Content.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        facturaService.eliminar(id);
        return ResponseEntity.noContent().build();
    }

    /**
     * Eliminacion fisica de la factura: se borra la cabecera y sus detalles en
     * cascada. Responde 204 No Content.
     */
    @DeleteMapping("/{id}/definitiva")
    public ResponseEntity<Void> eliminarDefinitivamente(@PathVariable Long id) {
        facturaService.eliminarFisicamente(id);
        return ResponseEntity.noContent().build();
    }

    /**
     * Convierte un filtro de fecha (yyyy-MM-dd) al instante que representa
     * ese dia en la zona horaria del servidor. Los filtros son inclusivos:
     * buscar desde y hasta el mismo dia devuelve las facturas de ese dia.
     */
    private Date aFecha(LocalDate fecha) {
        if (fecha == null) {
            return null;
        }
        return Date.from(fecha.atStartOfDay(ZoneId.systemDefault()).toInstant());
    }
}
