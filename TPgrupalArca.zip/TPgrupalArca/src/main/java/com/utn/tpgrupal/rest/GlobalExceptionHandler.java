package com.utn.tpgrupal.rest;

import com.utn.tpgrupal.exception.DatosInvalidosException;
import com.utn.tpgrupal.exception.ErrorResponse;
import com.utn.tpgrupal.exception.RecursoNoEncontradoException;
import jakarta.persistence.PersistenceException;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

/**
 * Manejo global de excepciones: centraliza el try/catch de los controllers
 * y traduce cada error a un codigo HTTP coherente.
 *
 * <p>Reglas:
 * <ul>
 *   <li>Recurso inexistente -> 404 Not Found</li>
 *   <li>Datos invalidos -> 400 Bad Request</li>
 *   <li>Violacion de integridad referencial -> 409 Conflict</li>
 *   <li>Error de la base de datos -> 500 con el mensaje real del driver</li>
 *   <li>Error inesperado -> 500 Internal Server Error</li>
 * </ul>
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger LOG = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(RecursoNoEncontradoException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ErrorResponse manejarRecursoNoEncontrado(RecursoNoEncontradoException ex) {
        return new ErrorResponse(HttpStatus.NOT_FOUND.value(), ex.getMessage());
    }

    @ExceptionHandler(DatosInvalidosException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ErrorResponse manejarDatosInvalidos(DatosInvalidosException ex) {
        return new ErrorResponse(HttpStatus.BAD_REQUEST.value(), ex.getMessage());
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ErrorResponse manejarValidacion(MethodArgumentNotValidException ex) {
        String detalle = ex.getBindingResult().getFieldErrors().stream()
                .map(error -> error.getField() + ": " + error.getDefaultMessage())
                .collect(Collectors.joining("; "));
        return new ErrorResponse(HttpStatus.BAD_REQUEST.value(),
                detalle.isBlank() ? "Datos de entrada invalidos" : detalle);
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ErrorResponse manejarMensajeInvalido(HttpMessageNotReadableException ex) {
        return new ErrorResponse(HttpStatus.BAD_REQUEST.value(),
                "El cuerpo de la peticion no es valido");
    }

    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ErrorResponse manejarTipoInvalido(MethodArgumentTypeMismatchException ex) {
        return new ErrorResponse(HttpStatus.BAD_REQUEST.value(),
                "El valor '" + ex.getValue() + "' no es valido para el parametro '"
                        + ex.getName() + "'");
    }

    @ExceptionHandler(DataIntegrityViolationException.class)
    @ResponseStatus(HttpStatus.CONFLICT)
    public ErrorResponse manejarViolacionIntegridad(DataIntegrityViolationException ex) {
        return new ErrorResponse(HttpStatus.CONFLICT.value(),
                "La operacion infringe una restriccion de integridad de datos");
    }

    /**
     * Error de la base de datos (esquema desactualizado, columna que no
     * existe, valor NOT NULL sin default, etc). Se devuelve el mensaje real
     * del driver para que el problema se pueda diagnosticar en el momento.
     */
    @ExceptionHandler(DataAccessException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ErrorResponse manejarErrorDeBase(DataAccessException ex) {
        LOG.error("Error de base de datos al atender la peticion", ex);
        return new ErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(),
                "Error de base de datos: " + mensajeDe(ex));
    }

    /**
     * Cuando el error lo lanza Hibernate sobre el EntityManager, la excepcion
     * llega como PersistenceException de JPA (sin convertir a DataAccessException).
     * Es el caso tipico de un INSERT que no puede completarse por un
     * desajuste entre el esquema de la base y las entidades mapeadas.
     */
    @ExceptionHandler(PersistenceException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ErrorResponse manejarErrorDePersistencia(PersistenceException ex) {
        LOG.error("Error de persistencia al atender la peticion", ex);
        return new ErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(),
                "Error de base de datos: " + mensajeDe(ex));
    }

    @ExceptionHandler({org.springframework.orm.ObjectOptimisticLockingFailureException.class, jakarta.persistence.OptimisticLockException.class})
    @ResponseStatus(HttpStatus.CONFLICT)
    public ErrorResponse manejarConflictoConcurrente(Exception ex) {
        return new ErrorResponse(409, "La factura cambio durante la operacion. Recargue antes de continuar");
    }

    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ErrorResponse manejarErrorGeneral(Exception ex) {
        LOG.error("Error inesperado al atender la peticion", ex);
        return new ErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(),
                "Se produjo un error interno en el servidor");
    }

    /** Devuelve la causa mas concreta de una excepcion (la del driver). */
    private Throwable causaRaiz(Throwable ex) {
        Throwable causa = ex;
        while (causa.getCause() != null && causa.getCause() != causa) {
            causa = causa.getCause();
        }
        return causa;
    }

    /** Mensaje del driver, sin el prefijo técnico de conexión. */
    private String mensajeDe(Throwable ex) {
        String mensaje = causaRaiz(ex).getMessage();
        if (mensaje == null || mensaje.isBlank()) {
            return ex.getClass().getSimpleName();
        }
        return mensaje.replaceAll("\\(conn=\\d+\\)\\s*", "").trim();
    }
}
