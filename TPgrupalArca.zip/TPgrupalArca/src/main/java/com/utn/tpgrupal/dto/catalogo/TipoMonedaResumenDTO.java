package com.utn.tpgrupal.dto.catalogo;

public record TipoMonedaResumenDTO(Long id, String denominacion, String simbolo) {
}
