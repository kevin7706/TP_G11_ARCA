package com.utn.tpgrupal.service.arca;

import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.cert.*;
import java.time.*;
import java.util.*;
import org.bouncycastle.asn1.pkcs.PrivateKeyInfo;
import org.bouncycastle.openssl.*;
import org.bouncycastle.openssl.jcajce.JcaPEMKeyConverter;
import org.bouncycastle.cms.*;
import org.bouncycastle.cms.jcajce.JcaSignerInfoGeneratorBuilder;
import org.bouncycastle.operator.jcajce.*;
import org.bouncycastle.cert.jcajce.JcaCertStore;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.springframework.stereotype.Service;
import static com.utn.tpgrupal.service.arca.SoapArca.*;

@Service
public class WsaaService {
    private final ArcaConfig config;
    private final SoapArca soap;
    private Ticket ticket;
    public record Ticket(String token, String sign, Instant vencimiento) {}
    public WsaaService(ArcaConfig config, SoapArca soap) { this.config = config; this.soap = soap; }
    public synchronized Ticket obtener() throws Exception {
        config.validar();
        if (ticket != null && ticket.vencimiento().isAfter(Instant.now().plusSeconds(120))) return ticket;
        Security.addProvider(new BouncyCastleProvider());
        PrivateKey key;
        try (PEMParser parser = new PEMParser(Files.newBufferedReader(Path.of(config.clave)))) {
            Object pem = parser.readObject();
            JcaPEMKeyConverter converter = new JcaPEMKeyConverter().setProvider("BC");
            if (pem instanceof PEMKeyPair pair) key = converter.getKeyPair(pair).getPrivate();
            else if (pem instanceof PrivateKeyInfo info) key = converter.getPrivateKey(info);
            else throw new IllegalArgumentException("La clave debe ser PEM RSA PKCS#1 o PKCS#8 sin cifrar");
        }
        X509Certificate cert;
        try (var in = Files.newInputStream(Path.of(config.certificado))) {
            cert = (X509Certificate) CertificateFactory.getInstance("X.509").generateCertificate(in);
        }
        cert.checkValidity();
        String huella = HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(cert.getEncoded())).substring(0, 16);
        Path cache = Path.of("datos", "wsaa-" + config.cuit + "-" + huella + ".properties");
        if (Files.exists(cache)) {
            try (var in = Files.newInputStream(cache)) {
                Properties p = new Properties(); p.load(in);
                Ticket guardado = new Ticket(p.getProperty("token"), p.getProperty("sign"), Instant.parse(p.getProperty("vencimiento")));
                if (guardado.token() != null && guardado.sign() != null && guardado.vencimiento().isAfter(Instant.now().plusSeconds(120))) {
                    ticket = guardado; return ticket;
                }
            } catch (Exception ignorada) { /* Cache invalida: se solicita un ticket nuevo. */ }
        }
        String subject = cert.getSubjectX500Principal().getName();
        // La coincidencia CUIT/servicio se valida ademas en WSAA/WSFE.
        if (subject.isBlank()) throw new IllegalArgumentException("Certificado invalido");
        Instant ahora = Instant.now();
        String tra = "<loginTicketRequest version=\"1.0\"><header>" + tag("uniqueId", ahora.getEpochSecond())
                + tag("generationTime", ahora.minusSeconds(300).toString()) + tag("expirationTime", ahora.plusSeconds(600).toString())
                + "</header><service>wsfe</service></loginTicketRequest>";
        CMSSignedDataGenerator gen = new CMSSignedDataGenerator();
        gen.addSignerInfoGenerator(new JcaSignerInfoGeneratorBuilder(new JcaDigestCalculatorProviderBuilder().setProvider("BC").build())
                .build(new JcaContentSignerBuilder("SHA256withRSA").setProvider("BC").build(key), cert));
        gen.addCertificates(new JcaCertStore(List.of(cert)));
        String cms = Base64.getEncoder().encodeToString(gen.generate(new CMSProcessableByteArray(tra.getBytes(StandardCharsets.UTF_8)), true).getEncoded());
        var response = soap.enviar("https://wsaahomo.afip.gov.ar/ws/services/LoginCms", "", "<loginCms xmlns=\"http://wsaa.view.sua.dvadac.desein.afip.gov\">" + tag("in0", cms) + "</loginCms>");
        var ta = parsear(texto(response, "loginCmsReturn"));
        String token = texto(ta, "token"), sign = texto(ta, "sign");
        if (token.isBlank() || sign.isBlank()) throw new java.io.IOException("WSAA no devolvio un ticket valido");
        ticket = new Ticket(token, sign, OffsetDateTime.parse(texto(ta, "expirationTime")).toInstant());
        Files.createDirectories(cache.getParent());
        Path temporal = Files.createTempFile(cache.getParent(), "wsaa-", ".tmp");
        try {
            try { Files.setPosixFilePermissions(temporal, java.nio.file.attribute.PosixFilePermissions.fromString("rw-------")); }
            catch (UnsupportedOperationException ignorada) { /* Windows: permisos del usuario del sistema. */ }
            Properties p = new Properties(); p.setProperty("token", token); p.setProperty("sign", sign); p.setProperty("vencimiento", ticket.vencimiento().toString());
            try (var out = Files.newOutputStream(temporal)) { p.store(out, "Ticket de homologacion wsfe - no compartir"); }
            Files.move(temporal, cache, StandardCopyOption.REPLACE_EXISTING);
        } finally { Files.deleteIfExists(temporal); }
        return ticket;
    }
}
