package com.utn.tpgrupal.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Datos de entrada de un renglon de factura.
 *
 * <p>Solo viajan identificadores de las relaciones (nunca entidades anidadas)
 * y los datos que el cliente conoce. Los importes netos, el IVA y el subtotal
 * los calcula el servidor.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class FacturaDetalleRequestDTO {
    /**
     * Id del detalle ya persistido. Si viene informado, el backend actualiza
     * ese renglon en el lugar (conserva su id y su relacion con la factura)
     * en lugar de borrarlo y volverlo a crear.
     */
    private Long detalleId;
    private Long articuloId;
    private Long listaPrecioArticuloId;
    private String descripcion;
    private Double cantidad;
    private Double precioUnitario;
    private Double porcentajeBonificacion;
    private Double porcentajeIva;
}
