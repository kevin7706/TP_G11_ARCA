package com.utn.tpgrupal.service.arca;

import org.springframework.stereotype.Service;
import org.w3c.dom.*;
import static com.utn.tpgrupal.service.arca.SoapArca.*;

@Service
public class WsfeService {
    private final ArcaConfig config;
    private final WsaaService wsaa;
    private final SoapArca soap;
    public record Respuesta(String resultado, String cae, String vencimiento, String mensaje) {}
    public WsfeService(ArcaConfig config, WsaaService wsaa, SoapArca soap) { this.config = config; this.wsaa = wsaa; this.soap = soap; }
    private Document llamar(String operacion, String datos) throws Exception {
        var t = wsaa.obtener();
        return soap.enviar("https://wswhomo.afip.gov.ar/wsfev1/service.asmx", "http://ar.gov.afip.dif.FEV1/" + operacion,
                "<" + operacion + " xmlns=\"http://ar.gov.afip.dif.FEV1/\"><Auth>" + tag("Token", t.token()) + tag("Sign", t.sign())
                + tag("Cuit", config.cuit) + "</Auth>" + datos + "</" + operacion + ">");
    }
    public long ultimo(int punto, int tipo) throws Exception {
        Document d = llamar("FECompUltimoAutorizado", tag("PtoVta", punto) + tag("CbteTipo", tipo));
        if (!texto(d, "Errors").isBlank() || texto(d, "CbteNro").isBlank()) throw new java.io.IOException("No se pudo consultar el ultimo comprobante ARCA");
        return Long.parseLong(texto(d, "CbteNro"));
    }
    public Respuesta autorizar(String solicitud) throws Exception {
        Document d = llamar("FECAESolicitar", solicitud);
        NodeList detalles = d.getElementsByTagNameNS("*", "FECAEDetResponse");
        if (detalles.getLength() == 0 && !texto(d, "Errors").isBlank()) {
            return new Respuesta("R", "", "", mensajes(d, "Errors"));
        }
        if (detalles.getLength() != 1) throw new java.io.IOException("Respuesta ARCA sin detalle; verificar antes de reenviar");
        Node det = detalles.item(0);
        String resultado = texto(det, "Resultado");
        if ("A".equals(resultado) && "A".equals(texto(d, "Resultado")) && !texto(det, "CAE").isBlank())
            return new Respuesta("A", texto(det, "CAE"), texto(det, "CAEFchVto"), mensajes(det, "Observaciones"));
        if ("R".equals(resultado)) return new Respuesta("R", "", "", (mensajes(d, "Errors") + " " + mensajes(det, "Observaciones")).strip());
        throw new java.io.IOException("Resultado ARCA ambiguo; consultar comprobante");
    }
    public Respuesta consultarVerificada(Comprobante esperado, long numero) throws Exception {
        Document d = llamar("FECompConsultar", "<FeCompConsReq>" + tag("CbteTipo", esperado.tipo()) + tag("CbteNro", numero) + tag("PtoVta", esperado.puntoVenta()) + "</FeCompConsReq>");
        String cae = texto(d, "CodAutorizacion");
        if (cae.isBlank() || !"A".equals(texto(d, "Resultado")) || !"CAE".equals(texto(d, "EmisionTipo")))
            throw new java.io.IOException("ARCA no confirma la autorizacion CAE");
        if (!texto(d, "CbteDesde").equals(String.valueOf(numero))
                || !texto(d, "CbteTipo").equals(String.valueOf(esperado.tipo()))
                || !texto(d, "PtoVta").equals(String.valueOf(esperado.puntoVenta()))
                || !texto(d, "DocNro").equals(esperado.documento())
                || !texto(d, "DocTipo").equals(String.valueOf(esperado.tipoDocumento()))
                || !texto(d, "MonId").equals(esperado.moneda())
                || !texto(d, "CbteFch").equals(esperado.fecha().replace("-", ""))
                || new java.math.BigDecimal(texto(d, "ImpTotal")).compareTo(esperado.total()) != 0)
            throw new java.io.IOException("El comprobante remoto no coincide con el intento guardado");
        return new Respuesta("A", cae, texto(d, "FchVto"), "Recuperada mediante FECompConsultar");
    }

}
