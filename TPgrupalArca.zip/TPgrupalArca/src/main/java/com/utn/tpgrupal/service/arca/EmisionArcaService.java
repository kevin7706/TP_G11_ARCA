package com.utn.tpgrupal.service.arca;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.utn.tpgrupal.entities.*;
import com.utn.tpgrupal.exception.*;
import jakarta.persistence.*;
import java.math.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.Supplier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;
import static com.utn.tpgrupal.service.arca.SoapArca.*;

@Service
public class EmisionArcaService {
    private final EntityManager em;
    private final TransactionTemplate tx;
    private final ArcaConfig config;
    private final WsfeService wsfe;
    private final ObjectMapper json;
    private static final ZoneId ZONA = ZoneId.of("America/Argentina/Mendoza");
    public EmisionArcaService(EntityManager em, PlatformTransactionManager tm, ArcaConfig config, WsfeService wsfe, ObjectMapper json) {
        this.em = em; this.tx = new TransactionTemplate(tm); this.config = config; this.wsfe = wsfe; this.json = json;
    }
    private <T> T transaccion(Supplier<T> trabajo) { return tx.execute(status -> trabajo.get()); }
    private FacturaVenta factura(Long id) {
        FacturaVenta f = em.find(FacturaVenta.class, id, LockModeType.PESSIMISTIC_WRITE);
        if (f == null) throw new RecursoNoEncontradoException("Factura no encontrada");
        return f;
    }
    /** Una instancia de aplicacion: serializa la serie durante consulta y envio. */
    public synchronized void informar(Long id) {
        config.validar();
        Comprobante datos = transaccion(() -> {
            FacturaVenta f = factura(id);
            if (f.getCae() != null && !f.getCae().isBlank()) return null;
            if (f.getFechaBaja() != null || "ANULADA".equals(f.getEstado())) throw new DatosInvalidosException("La factura esta anulada o eliminada");
            if (List.of("ENVIANDO", "A_VERIFICAR").contains(f.getEstado())) return leer(f.getDatosImpresion());
            long inciertas = em.createQuery("SELECT COUNT(f) FROM FacturaVenta f WHERE f.estado IN ('ENVIANDO', 'A_VERIFICAR') AND f.id <> :id", Long.class)
                    .setParameter("id", id).getSingleResult();
            if (inciertas > 0) throw new DatosInvalidosException("Hay una autorizacion pendiente de verificar. Resuelvala antes de emitir otra factura");
            Comprobante c = capturar(f);
            Cliente cliente = f.getCliente();
            if (cliente != null && Boolean.TRUE.equals(cliente.getDatosEjemplo()) && List.of(80, 86, 87).contains(c.tipoDocumento())
                    && c.documento().equals(cliente.getCuitCuil().replaceAll("[ .-]", ""))) {
                throw new DatosInvalidosException("Este cliente de ejemplo tiene un CUIT ficticio, no habilitado para ARCA. Corrija sus datos fiscales o elija una persona con DNI de prueba o Consumidor Final sin identificar.");
            }
            validar(c);
            f.setTipoComprobante(config.tipoComprobante);
            f.setCuitEmisor(config.cuit);
            f.setDatosImpresion(escribir(c));
            f.setEstado("ENVIANDO");
            f.setNumeroTentativo(null);
            f.setSolicitudArca(null);
            f.setMotivoRechazo(null);
            f.setFechaModificacion(new Date());
            return c;
        });
        if (datos == null) return; // Repetir una factura autorizada es idempotente.
        String solicitudExistente = transaccion(() -> factura(id).getSolicitudArca());
        if (solicitudExistente != null) { verificar(id); return; }
        boolean puedeHaberSidoEnviada = false;
        try {
            long numero = wsfe.ultimo(datos.puntoVenta(), datos.tipo()) + 1;
            String solicitud = solicitud(datos, numero);
            transaccion(() -> {
                FacturaVenta f = factura(id);
                f.setNumeroTentativo(numero);
                f.setSolicitudArca(solicitud);
                return null;
            });
            puedeHaberSidoEnviada = true;
            guardarResultado(id, wsfe.autorizar(solicitud));
        } catch (Exception ex) {
            boolean incierta = puedeHaberSidoEnviada;
            transaccion(() -> {
                FacturaVenta f = factura(id);
                if (f.getCae() == null || f.getCae().isBlank()) {
                    f.setEstado(incierta ? "A_VERIFICAR" : "PENDIENTE");
                    f.setMotivoRechazo(incierta ? "Se perdio la respuesta. Use Verificar ARCA antes de reenviar." : "No fue posible conectar o consultar ARCA. Revise credenciales y conexion.");
                }
                return null;
            });
            throw new DatosInvalidosException(incierta ? "Respuesta incierta: la factura quedo bloqueada para verificar en ARCA" : "No se envio la factura. Revise credenciales, certificado y conexion a homologacion");
        }
    }
    public synchronized void verificar(Long id) {
        config.validar();
        record Intento(long numero, Comprobante datos) {}
        Intento intento = transaccion(() -> {
            FacturaVenta f = factura(id);
            if (f.getCae() != null && !f.getCae().isBlank()) return null;
            if (f.getNumeroTentativo() == null || f.getSolicitudArca() == null) throw new DatosInvalidosException("La factura no tiene un envio para consultar; puede informar nuevamente");
            if (!config.cuit.equals(f.getCuitEmisor())) throw new DatosInvalidosException("El CUIT configurado no coincide con el del envio original");
            return new Intento(f.getNumeroTentativo(), leer(f.getDatosImpresion()));
        });
        if (intento == null) return;
        try { guardarResultado(id, wsfe.consultarVerificada(intento.datos(), intento.numero())); }
        catch (Exception ex) { throw new DatosInvalidosException("ARCA aun no confirma el comprobante. Se mantiene bloqueado; vuelva a verificar o revise el intento con el docente"); }
    }
    private void guardarResultado(Long id, WsfeService.Respuesta r) {
        Date vto = "A".equals(r.resultado()) ? Date.from(LocalDate.parse(r.vencimiento(), DateTimeFormatter.BASIC_ISO_DATE).atStartOfDay(ZONA).toInstant()) : null;
        if ("A".equals(r.resultado()) && !r.cae().matches("[0-9]{14}")) throw new DatosInvalidosException("CAE invalido; verificar en ARCA");
        transaccion(() -> {
            FacturaVenta f = factura(id);
            f.setResultadoAfip(r.resultado());
            f.setMotivoRechazo(r.mensaje() == null ? null : r.mensaje().substring(0, Math.min(2000, r.mensaje().length())));
            if ("A".equals(r.resultado())) {
                f.setNumero(f.getNumeroTentativo()); f.setCae(r.cae()); f.setCaeFechaVencimiento(vto); f.setEstado("AUTORIZADA");
            } else { f.setEstado("RECHAZADA"); f.setSolicitudArca(null); }
            f.setFechaModificacion(new Date());
            return null;
        });
    }
    public Comprobante datosImpresion(Long id) {
        return transaccion(() -> {
            FacturaVenta f = em.find(FacturaVenta.class, id);
            if (f == null) throw new RecursoNoEncontradoException("Factura no encontrada");
            return f.getDatosImpresion() != null && f.getCae() != null ? leer(f.getDatosImpresion()) : capturar(f);
        });
    }
    private String escribir(Comprobante c) {
        try { return json.writeValueAsString(c); } catch (Exception e) { throw new IllegalStateException("No se pudo guardar la instantanea", e); }
    }
    private Comprobante leer(String s) {
        try { return json.readValue(s, Comprobante.class); } catch (Exception e) { throw new DatosInvalidosException("No se pudo recuperar la instantanea del intento ARCA"); }
    }
    private static BigDecimal dinero(double n) { return BigDecimal.valueOf(n).setScale(2, RoundingMode.HALF_UP); }
    private Comprobante capturar(FacturaVenta f) {
        Cliente c = f.getCliente();
        int tipoDocumento = c == null ? 99 : c.getTipoDocumento() == null ? 80 : c.getTipoDocumento();
        String documento = c == null ? "0" : c.getNumeroDocumento() == null ? c.getCuitCuil().replaceAll("[ .-]", "") : c.getNumeroDocumento();
        List<Comprobante.Item> items = f.getDetalles().stream().map(d -> new Comprobante.Item(d.getDescripcion(), d.getCantidad(), dinero(d.getPrecioUnitario()), d.getPorcentajeBonificacion(),
                d.getPorcentajeIva() != null ? d.getPorcentajeIva() : (d.getImporteNeto() == 0 ? 0 : Math.round(d.getImporteIva() / d.getImporteNeto() * 10000) / 100.0),
                dinero(d.getImporteNeto()), dinero(d.getImporteIva()), dinero(d.getImporteSubtotal()))).toList();
        BigDecimal neto = items.stream().map(Comprobante.Item::neto).reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal iva = items.stream().map(Comprobante.Item::iva).reduce(BigDecimal.ZERO, BigDecimal::add);
        Domicilio dom = c == null ? null : c.getDomicilio();
        return new Comprobante(config.razonSocial, config.cuit, config.domicilio, config.condicionIva, config.iibb, config.inicioActividades,
                c == null ? "Consumidor Final" : c.getDenominacion(), documento, tipoDocumento,
                dom == null ? "" : dom.getNombreCalle() + " " + dom.getNumeroCalle(), f.getCondicionIva().getCodigoAfip(),
                new java.text.SimpleDateFormat("yyyy-MM-dd").format(f.getFechaEmision()), f.getPuntoVenta().getNumero(), config.tipoComprobante,
                f.getTipoMoneda().getCodigoAfip(), dinero(f.getImporteTotal()), neto, iva, items);
    }
    private void validar(Comprobante c) {
        if (!"PES".equals(c.moneda())) throw new DatosInvalidosException("La integracion inicial admite moneda PES (pesos argentinos)");
        com.utn.tpgrupal.validation.DocumentoFiscal.validar(c.tipoDocumento(), c.documento());
        if (c.tipoDocumento() == 96 && c.condicionIvaReceptor() != 5) throw new DatosInvalidosException("Para este TP un receptor con DNI debe tener condicion IVA Consumidor Final");
        if (c.tipo() == 1 && (c.tipoDocumento() != 80 || !List.of(1, 6).contains(c.condicionIvaReceptor()))) throw new DatosInvalidosException("Revise CUIT y condicion IVA del receptor para Factura A");
        if (c.tipoDocumento() == 99 && c.condicionIvaReceptor() != 5) throw new DatosInvalidosException("Sin identificar requiere condicion IVA Consumidor Final");
        if (c.tipoDocumento() == 99 && c.total().compareTo(config.limiteSinIdentificar) >= 0)
            throw new DatosInvalidosException("Por este importe debe identificar al receptor mediante DNI, CUIT, CUIL o CDI; no puede enviar sin identificar");
        if (c.total().signum() <= 0 || c.items().isEmpty()) throw new DatosInvalidosException("La factura debe tener detalles e importe positivo");
        if (c.tipo() == 11 && c.items().stream().anyMatch(i -> i.alicuota() != 0 || i.iva().signum() != 0)) throw new DatosInvalidosException("Factura C requiere IVA cero; ajuste los renglones antes de informar");
        for (var i : c.items()) if (!List.of(0.0, 10.5, 21.0, 27.0).contains(i.alicuota())) throw new DatosInvalidosException("Alicuota no soportada por este TP");
    }
    static String solicitud(Comprobante c, long numero) {
        StringBuilder s = new StringBuilder("<FeCAEReq><FeCabReq>" + tag("CantReg", 1) + tag("PtoVta", c.puntoVenta()) + tag("CbteTipo", c.tipo()) + "</FeCabReq><FeDetReq><FECAEDetRequest>");
        s.append(tag("Concepto", 1)).append(tag("DocTipo", c.tipoDocumento())).append(tag("DocNro", c.documento())).append(tag("CbteDesde", numero)).append(tag("CbteHasta", numero))
                .append(tag("CbteFch", c.fecha().replace("-", ""))).append(tag("ImpTotal", c.total())).append(tag("ImpTotConc", "0.00"))
                .append(tag("ImpNeto", c.neto())).append(tag("ImpOpEx", "0.00")).append(tag("ImpTrib", "0.00")).append(tag("ImpIVA", c.iva()))
                .append(tag("MonId", c.moneda())).append(tag("MonCotiz", 1)).append(tag("CondicionIVAReceptorId", c.condicionIvaReceptor()));
        if (c.tipo() != 11) {
            s.append("<Iva>");
            Map<Double, List<Comprobante.Item>> grupos = new TreeMap<>();
            c.items().forEach(i -> grupos.computeIfAbsent(i.alicuota(), k -> new ArrayList<>()).add(i));
            Map<Double, Integer> ids = Map.of(0.0, 3, 10.5, 4, 21.0, 5, 27.0, 6);
            grupos.forEach((ali, items) -> s.append("<AlicIva>").append(tag("Id", ids.get(ali)))
                    .append(tag("BaseImp", items.stream().map(Comprobante.Item::neto).reduce(BigDecimal.ZERO, BigDecimal::add)))
                    .append(tag("Importe", items.stream().map(Comprobante.Item::iva).reduce(BigDecimal.ZERO, BigDecimal::add))).append("</AlicIva>"));
            s.append("</Iva>");
        }
        return s.append("</FECAEDetRequest></FeDetReq></FeCAEReq>").toString();
    }
}
