package com.utn.tpgrupal.rest;

import com.utn.tpgrupal.service.arca.*;
import com.utn.tpgrupal.exception.DatosInvalidosException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import java.time.Instant;

@RestController
@RequestMapping("/api/arca")
public class ArcaEstadoController {
    private final WsaaService wsaa;
    private final WsfeService wsfe;
    private final ArcaConfig config;
    private final int puntoVenta;
    public record Estado(String ambiente, boolean autenticado, Instant ticketVencimiento, int puntoVenta, int tipoComprobante, long ultimoAutorizado) {}
    public ArcaEstadoController(WsaaService wsaa, WsfeService wsfe, ArcaConfig config, @Value("${arca.punto-venta:1}") int puntoVenta) {
        this.wsaa = wsaa; this.wsfe = wsfe; this.config = config; this.puntoVenta = puntoVenta;
    }
    @GetMapping("/estado")
    public Estado estado() {
        config.validar();
        try {
            var ticket = wsaa.obtener();
            long ultimo = wsfe.ultimo(puntoVenta, config.tipoComprobante);
            return new Estado("HOMOLOGACION", true, ticket.vencimiento(), puntoVenta, config.tipoComprobante, ultimo);
        } catch (Exception e) {
            throw new DatosInvalidosException("No se pudo completar el diagnostico de homologacion: " + e.getClass().getSimpleName()
                    + ". Revise certificado, autorizacion wsfe y conectividad.");
        }
    }
}
