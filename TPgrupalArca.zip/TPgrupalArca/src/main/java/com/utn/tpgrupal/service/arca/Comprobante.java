package com.utn.tpgrupal.service.arca;

import java.util.List;
import java.math.BigDecimal;

/** Instantanea fiscal independiente de cambios posteriores en los catalogos. */
public record Comprobante(String emisor, String cuit, String domicilioEmisor, String ivaEmisor,
        String iibb, String inicioActividades, String receptor, String documento, int tipoDocumento,
        String domicilioReceptor, int condicionIvaReceptor, String fecha, int puntoVenta, int tipo,
        String moneda, BigDecimal total, BigDecimal neto, BigDecimal iva, List<Item> items) {
    public record Item(String descripcion, double cantidad, BigDecimal precio, double descuento,
            double alicuota, BigDecimal neto, BigDecimal iva, BigDecimal subtotal) {}
}
