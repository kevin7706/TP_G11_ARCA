package com.utn.tpgrupal.dto.catalogo;

public record ListaPrecioResumenDTO(Long id, String codigo, String denominacion) {
}
