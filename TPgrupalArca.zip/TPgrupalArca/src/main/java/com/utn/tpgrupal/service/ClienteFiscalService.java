package com.utn.tpgrupal.service;

import com.utn.tpgrupal.entities.Cliente;
import com.utn.tpgrupal.dto.catalogo.ClienteResumenDTO;
import com.utn.tpgrupal.exception.*;
import com.utn.tpgrupal.validation.DocumentoFiscal;
import jakarta.persistence.EntityManager;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.Date;
import java.util.Set;

@Service
public class ClienteFiscalService {
    private final EntityManager em;
    public record Solicitud(Integer tipoDocumento, String numeroDocumento, Integer codigoCondicionIva) {}
    public ClienteFiscalService(EntityManager em) { this.em = em; }
    @Transactional
    public ClienteResumenDTO actualizar(Long id, Solicitud solicitud) {
        Cliente c = em.find(Cliente.class, id);
        if (c == null || c.getFechaBaja() != null) throw new RecursoNoEncontradoException("Cliente no encontrado");
        if (solicitud == null || solicitud.codigoCondicionIva() == null || !Set.of(1,4,5,6,7).contains(solicitud.codigoCondicionIva()))
            throw new DatosInvalidosException("Seleccione una condicion IVA valida");
        var doc = DocumentoFiscal.validar(solicitud.tipoDocumento(), solicitud.numeroDocumento());
        if ((doc.tipo() == 99 || doc.tipo() == 96) && solicitud.codigoCondicionIva() != 5)
            throw new DatosInvalidosException("DNI y sin identificar requieren condicion IVA Consumidor Final en este TP");
        if (Boolean.TRUE.equals(c.getDatosEjemplo()) && Set.of(80,86,87).contains(doc.tipo())
                && doc.numero().equals(c.getCuitCuil().replaceAll("[ .-]", "")))
            throw new DatosInvalidosException("El CUIT original de la semilla es ficticio y no sirve para facturar");
        c.setTipoDocumento(doc.tipo()); c.setNumeroDocumento(doc.numero()); c.setCodigoCondicionIva(solicitud.codigoCondicionIva());
        c.setFechaModificacion(new Date());
        return new ClienteResumenDTO(c.getId(), c.getDenominacion(), c.getCuitCuil(), c.getTipoDocumento(), c.getNumeroDocumento(), c.getCodigoCondicionIva(), c.getDatosEjemplo());
    }
}
