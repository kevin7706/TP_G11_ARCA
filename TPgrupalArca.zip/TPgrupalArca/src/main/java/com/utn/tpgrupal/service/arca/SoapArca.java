package com.utn.tpgrupal.service.arca;

import java.io.StringReader;
import java.net.URI;
import java.net.http.*;
import java.time.Duration;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.*;
import org.xml.sax.InputSource;
import org.springframework.stereotype.Component;

@Component
public class SoapArca {
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(15)).build();
    public Document enviar(String url, String accion, String cuerpo) throws Exception {
        String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\"><s:Body>" + cuerpo + "</s:Body></s:Envelope>";
        HttpRequest request = HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(45))
                .header("Content-Type", "text/xml; charset=utf-8").header("SOAPAction", "\"" + accion + "\"")
                .POST(HttpRequest.BodyPublishers.ofString(xml)).build();
        HttpResponse<String> response = http.send(request, HttpResponse.BodyHandlers.ofString());
        Document doc = parsear(response.body());
        if (!texto(doc, "faultstring").isBlank()) throw new java.io.IOException("ARCA devolvio un SOAP Fault");
        if (response.statusCode() != 200) throw new java.io.IOException("ARCA respondio HTTP " + response.statusCode());
        return doc;
    }
    public static Document parsear(String xml) throws Exception {
        DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
        f.setNamespaceAware(true);
        f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
        f.setFeature("http://xml.org/sax/features/external-general-entities", false);
        f.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
        f.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
        f.setAttribute(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
        return f.newDocumentBuilder().parse(new InputSource(new StringReader(xml)));
    }
    public static String texto(Node node, String nombre) {
        NodeList nodes = node instanceof Document d ? d.getElementsByTagNameNS("*", nombre) : ((Element) node).getElementsByTagNameNS("*", nombre);
        return nodes.getLength() == 0 ? "" : nodes.item(0).getTextContent().trim();
    }
    public static String mensajes(Node nodo, String contenedor) {
        NodeList cajas = nodo instanceof Document d ? d.getElementsByTagNameNS("*", contenedor) : ((Element) nodo).getElementsByTagNameNS("*", contenedor);
        java.util.List<String> mensajes = new java.util.ArrayList<>();
        for (int i = 0; i < cajas.getLength(); i++) {
            NodeList hijos = cajas.item(i).getChildNodes();
            for (int j = 0; j < hijos.getLength(); j++) {
                Node hijo = hijos.item(j);
                if (hijo instanceof Element) {
                    String codigo = texto(hijo, "Code"), mensaje = texto(hijo, "Msg");
                    if (!mensaje.isBlank()) mensajes.add((codigo.isBlank() ? "" : "[" + codigo + "] ") + mensaje);
                }
            }
        }
        return mensajes.isEmpty() ? texto(nodo, contenedor) : String.join("; ", mensajes);
    }
    public static String tag(String nombre, Object valor) {
        String s = String.valueOf(valor).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&apos;");
        return "<" + nombre + ">" + s + "</" + nombre + ">";
    }
}
