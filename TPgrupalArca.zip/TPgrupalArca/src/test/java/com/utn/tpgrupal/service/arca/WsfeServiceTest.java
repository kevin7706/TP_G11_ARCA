package com.utn.tpgrupal.service.arca;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class WsfeServiceTest {
    SoapArca soap;
    WsfeService service;
    @BeforeEach void preparar() throws Exception {
        ArcaConfig config = new ArcaConfig(); config.cuit = "20111111112";
        WsaaService wsaa = mock(WsaaService.class);
        when(wsaa.obtener()).thenReturn(new WsaaService.Ticket("TOKEN_TEST", "SIGN_TEST", Instant.now().plusSeconds(600)));
        soap = mock(SoapArca.class); service = new WsfeService(config, wsaa, soap);
    }
    void respuesta(String cuerpo) throws Exception {
        when(soap.enviar(anyString(), anyString(), anyString())).thenReturn(SoapArca.parsear("<Envelope xmlns=\"urn:test\"><Body>" + cuerpo + "</Body></Envelope>"));
    }
    @Test void procesaAprobacionDeCabeceraYDetalle() throws Exception {
        respuesta("<FeCabResp><Resultado>A</Resultado></FeCabResp><FeDetResp><FECAEDetResponse><Resultado>A</Resultado><CAE>12345678901234</CAE><CAEFchVto>20261231</CAEFchVto></FECAEDetResponse></FeDetResp>");
        assertEquals("12345678901234", service.autorizar("<FeCAEReq/>").cae());
        verify(soap).enviar(eq("https://wswhomo.afip.gov.ar/wsfev1/service.asmx"), endsWith("/FECAESolicitar"), contains("<Cuit>20111111112</Cuit>"));
    }
    @Test void rechazoConservaObservacion() throws Exception {
        respuesta("<FeCabResp><Resultado>R</Resultado></FeCabResp><FECAEDetResponse><Resultado>R</Resultado><Observaciones><Obs><Msg>Documento invalido</Msg></Obs></Observaciones></FECAEDetResponse>");
        var r = service.autorizar("<FeCAEReq/>"); assertEquals("R", r.resultado()); assertTrue(r.mensaje().contains("Documento invalido"));
    }
    @Test void noInterpretaRespuestaIncompletaComoRechazoSeguro() throws Exception {
        respuesta("<FeDetResp/>");
        assertThrows(java.io.IOException.class, () -> service.autorizar("<FeCAEReq/>"));
    }
    @Test void erroresGeneralesExplicitosNoDejanUnEnvioIncierto() throws Exception {
        respuesta("<Errors><Err><Code>10001</Code><Msg>CUIT no autorizado</Msg></Err></Errors>");
        var r = service.autorizar("<FeCAEReq/>"); assertEquals("R", r.resultado()); assertTrue(r.mensaje().contains("CUIT no autorizado"));
    }
    @Test void noRecuperaCAEDeUnComprobanteConDatosDiferentes() throws Exception {
        respuesta("<Resultado>A</Resultado><EmisionTipo>CAE</EmisionTipo><CodAutorizacion>12345678901234</CodAutorizacion><CbteDesde>41</CbteDesde><CbteTipo>6</CbteTipo><PtoVta>1</PtoVta><DocNro>0</DocNro><CbteFch>20261104</CbteFch><ImpTotal>999.00</ImpTotal>");
        assertThrows(java.io.IOException.class, () -> service.consultarVerificada(comprobante(), 41));
    }
    @Test void armaSolicitudConImportesYCondicionIVA() throws Exception {
        String xml = EmisionArcaService.solicitud(comprobante(), 41);
        var d = SoapArca.parsear(xml);
        assertEquals("242.00", SoapArca.texto(d, "ImpTotal")); assertEquals("5", SoapArca.texto(d, "CondicionIVAReceptorId"));
        assertEquals("41", SoapArca.texto(d, "CbteDesde")); assertEquals("5", SoapArca.texto(d, "Id"));
    }
    @Test void parserRechazaEntidadesExternas() {
        assertThrows(Exception.class, () -> SoapArca.parsear("<!DOCTYPE test [<!ENTITY archivo SYSTEM 'file:///no-leer'>]><test>&archivo;</test>"));
    }
    Comprobante comprobante() {
        return new Comprobante("TEST", "20111111112", "Mendoza", "RI", "", "", "Consumidor Final", "0", 99, "", 5,
                "2026-11-04", 1, 6, "PES", new BigDecimal("242.00"), new BigDecimal("200.00"), new BigDecimal("42.00"),
                List.of(new Comprobante.Item("Articulo", 2, new BigDecimal("100.00"), 0, 21, new BigDecimal("200.00"), new BigDecimal("42.00"), new BigDecimal("242.00"))));
    }
}
