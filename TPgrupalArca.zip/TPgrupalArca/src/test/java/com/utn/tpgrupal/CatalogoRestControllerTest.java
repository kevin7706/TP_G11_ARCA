package com.utn.tpgrupal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.utn.tpgrupal.dto.catalogo.ArticuloPrecioResumenDTO;
import com.utn.tpgrupal.dto.catalogo.ClienteResumenDTO;
import com.utn.tpgrupal.dto.catalogo.ListaPrecioResumenDTO;
import com.utn.tpgrupal.entities.ListaPrecio;
import jakarta.persistence.EntityManager;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

/**
 * Endpoints de catalogos por HTTP: lo que consume el frontend (los
 * exploradores de cliente, lista de precio y articulo).
 */
@SpringBootTest(
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
        properties = "spring.datasource.url=jdbc:h2:mem:facturacion_catalogos;MODE=MariaDB;DB_CLOSE_DELAY=-1")
class CatalogoRestControllerTest {

    @Autowired
    private TestRestTemplate rest;

    @Autowired
    private EntityManager entityManager;

    @Test
    void devuelveElListadoDeListasDePrecio() {
        ResponseEntity<List<ListaPrecioResumenDTO>> respuesta = rest.exchange(
                "/api/catalogos/listas-precio", HttpMethod.GET, null,
                new ParameterizedTypeReference<List<ListaPrecioResumenDTO>>() { });

        assertEquals(HttpStatus.OK, respuesta.getStatusCode());
        assertNotNull(respuesta.getBody());
        assertFalse(respuesta.getBody().isEmpty());
        assertNotNull(respuesta.getBody().get(0).id());
        assertNotNull(respuesta.getBody().get(0).codigo());
        assertNotNull(respuesta.getBody().get(0).denominacion());
    }

    @Test
    void filtraLasListasDePrecioConElParametroDeBusqueda() {
        ResponseEntity<List<ListaPrecioResumenDTO>> respuesta = rest.exchange(
                "/api/catalogos/listas-precio?q=LP-01", HttpMethod.GET, null,
                new ParameterizedTypeReference<List<ListaPrecioResumenDTO>>() { });

        assertEquals(HttpStatus.OK, respuesta.getStatusCode());
        assertNotNull(respuesta.getBody());
        assertEquals(1, respuesta.getBody().size());
        assertEquals("Lista General", respuesta.getBody().get(0).denominacion());
    }

    @Test
    void filtraLosClientesConElParametroDeBusqueda() {
        ResponseEntity<List<ClienteResumenDTO>> respuesta = rest.exchange(
                "/api/catalogos/clientes?q=UTN", HttpMethod.GET, null,
                new ParameterizedTypeReference<List<ClienteResumenDTO>>() { });

        assertEquals(HttpStatus.OK, respuesta.getStatusCode());
        assertNotNull(respuesta.getBody());
        assertFalse(respuesta.getBody().isEmpty());
        assertTrue(respuesta.getBody().stream()
                .allMatch(c -> c.denominacion().toLowerCase().contains("utn")));
    }

    @Test
    void filtraLosArticulosPorListaDePrecio() {
        ListaPrecio lista = entityManager.createQuery(
                        "SELECT lp FROM ListaPrecio lp WHERE lp.codigo = 'LP-01'", ListaPrecio.class)
                .setMaxResults(1)
                .getResultList()
                .get(0);

        ResponseEntity<List<ArticuloPrecioResumenDTO>> respuesta = rest.exchange(
                "/api/catalogos/articulos?listaPrecioId=" + lista.getId(), HttpMethod.GET, null,
                new ParameterizedTypeReference<List<ArticuloPrecioResumenDTO>>() { });

        assertEquals(HttpStatus.OK, respuesta.getStatusCode());
        assertNotNull(respuesta.getBody());
        assertFalse(respuesta.getBody().isEmpty());
        assertTrue(respuesta.getBody().stream()
                .allMatch(a -> a.listaPrecioId().equals(lista.getId())));
    }

    @Test
    void filtraLosArticulosConElParametroDeBusqueda() {
        ResponseEntity<List<ArticuloPrecioResumenDTO>> respuesta = rest.exchange(
                "/api/catalogos/articulos?q=ART-001", HttpMethod.GET, null,
                new ParameterizedTypeReference<List<ArticuloPrecioResumenDTO>>() { });

        assertEquals(HttpStatus.OK, respuesta.getStatusCode());
        assertNotNull(respuesta.getBody());
        assertFalse(respuesta.getBody().isEmpty());
        assertTrue(respuesta.getBody().stream().allMatch(a -> a.codigo().equals("ART-001")));
    }
}
