package com.utn.tpgrupal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.utn.tpgrupal.dto.catalogo.ArticuloPrecioResumenDTO;
import com.utn.tpgrupal.dto.catalogo.ClienteResumenDTO;
import com.utn.tpgrupal.dto.catalogo.ListaPrecioResumenDTO;
import com.utn.tpgrupal.entities.Articulo;
import com.utn.tpgrupal.entities.Cliente;
import com.utn.tpgrupal.entities.ListaPrecio;
import com.utn.tpgrupal.entities.ListaPrecioArticulo;
import com.utn.tpgrupal.entities.Usuario;
import com.utn.tpgrupal.service.CatalogoService;
import jakarta.persistence.EntityManager;
import java.util.Date;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

/**
 * Catálogos de la API: las listas de precio, los clientes y los artículos con
 * su precio de venta (que es lo que vive en la lista precio articulo).
 */
@SpringBootTest
@Transactional
class CatalogoServiceTest {

    @Autowired
    private CatalogoService catalogoService;

    @Autowired
    private EntityManager entityManager;

    @Test
    void listaLasListasDePrecioConCodigoYDenominacion() {
        List<ListaPrecioResumenDTO> listas = catalogoService.listarListasPrecio(null);

        assertFalse(listas.isEmpty());
        ListaPrecioResumenDTO primera = listas.get(0);
        assertNotNull(primera.id());
        assertNotNull(primera.codigo());
        assertNotNull(primera.denominacion());
    }

    @Test
    void filtraLasListasDePrecioPorCodigoODenominacion() {
        List<ListaPrecioResumenDTO> porCodigo = catalogoService.listarListasPrecio("LP-01");
        assertEquals(1, porCodigo.size());
        assertEquals("Lista General", porCodigo.get(0).denominacion());

        List<ListaPrecioResumenDTO> porDenominacion = catalogoService.listarListasPrecio("general");
        assertEquals(1, porDenominacion.size());
        assertEquals("LP-01", porDenominacion.get(0).codigo());

        assertTrue(catalogoService.listarListasPrecio("no existe ninguna").isEmpty());
    }

    @Test
    void filtraLosClientesPorDenominacionOCuitCuil() {
        Cliente cliente = primero(Cliente.class);
        String denominacion = cliente.getDenominacion();

        List<ClienteResumenDTO> porDenominacion = catalogoService.listarClientes(denominacion);
        assertFalse(porDenominacion.isEmpty());
        assertTrue(porDenominacion.stream()
                .allMatch(c -> c.denominacion().toLowerCase().contains(denominacion.toLowerCase())));

        List<ClienteResumenDTO> porCuit = catalogoService.listarClientes(cliente.getCuitCuil());
        assertEquals(1, porCuit.size());
        assertEquals(cliente.getId(), porCuit.get(0).id());

        assertTrue(catalogoService.listarClientes("zzz-no-existe-zzz").isEmpty());
    }

    @Test
    void sinFiltroDevuelveTodosLosClientes() {
        long enBase = entityManager.createQuery("SELECT COUNT(c) FROM Cliente c", Long.class)
                .getSingleResult();

        assertEquals(enBase, catalogoService.listarClientes(null).size());
        assertEquals(enBase, catalogoService.listarClientes("").size());
    }

    @Test
    void filtraLosArticulosPorListaDePrecio() {
        ListaPrecio listaGeneral = primeroPorCodigo("LP-01");
        ListaPrecio listaTest = crearLista("LP-TEST", "Lista de Prueba");
        Articulo articulo = primero(Articulo.class);
        ListaPrecioArticulo precioGeneral = crearPrecio(listaGeneral, articulo, 1000);
        ListaPrecioArticulo precioTest = crearPrecio(listaTest, articulo, 2000);
        entityManager.flush();

        List<ArticuloPrecioResumenDTO> soloGeneral = catalogoService.listarArticulos(listaGeneral.getId(), null);
        assertFalse(soloGeneral.isEmpty());
        assertTrue(soloGeneral.stream().allMatch(a -> a.listaPrecioId().equals(listaGeneral.getId())));
        assertTrue(soloGeneral.stream().anyMatch(a -> a.listaPrecioArticuloId().equals(precioGeneral.getId())));

        List<ArticuloPrecioResumenDTO> soloTest = catalogoService.listarArticulos(listaTest.getId(), null);
        assertEquals(1, soloTest.size());
        assertEquals(precioTest.getId(), soloTest.get(0).listaPrecioArticuloId());
        assertEquals(2000.0, soloTest.get(0).precioVenta());
    }

    @Test
    void sinFiltroDeListaDevuelveTodosLosArticulos() {
        long enBase = entityManager.createQuery(
                "SELECT COUNT(lpa) FROM ListaPrecioArticulo lpa", Long.class).getSingleResult();

        assertEquals(enBase, catalogoService.listarArticulos(null, null).size());
    }

    @Test
    void filtraLosArticulosPorCodigoODenominacion() {
        Articulo articulo = primero(Articulo.class);

        List<ArticuloPrecioResumenDTO> porCodigo = catalogoService.listarArticulos(null, articulo.getCodigo());
        assertFalse(porCodigo.isEmpty());
        assertTrue(porCodigo.stream().allMatch(a -> a.codigo().equals(articulo.getCodigo())));

        List<ArticuloPrecioResumenDTO> porDenominacion = catalogoService.listarArticulos(null, "logitech");
        assertFalse(porDenominacion.isEmpty());
        assertTrue(porDenominacion.stream()
                .allMatch(a -> a.denominacion().toLowerCase().contains("logitech")));

        assertTrue(catalogoService.listarArticulos(null, "zzz-no-existe-zzz").isEmpty());
    }

    @Test
    void elArticuloExponeElPrecioDeVentaDeSuListaPrecio() {
        Articulo articulo = primero(Articulo.class);
        ListaPrecio listaGeneral = primeroPorCodigo("LP-01");

        List<ArticuloPrecioResumenDTO> articulos = catalogoService.listarArticulos(listaGeneral.getId(), null);

        assertFalse(articulos.isEmpty());
        ArticuloPrecioResumenDTO delArticulo = articulos.stream()
                .filter(a -> a.articuloId().equals(articulo.getId()))
                .findFirst()
                .orElseThrow();
        assertEquals(listaGeneral.getId(), delArticulo.listaPrecioId());
        assertEquals("Lista General", delArticulo.listaPrecioDenominacion());
        assertTrue(delArticulo.precioVenta() > 0);
    }

    // ------------------------------------------------------------------
    // Casos borde
    // ------------------------------------------------------------------

    @Test
    void laBusquedaNoDistingueMayusculasDeMinusculas() {
        Cliente cliente = primero(Cliente.class);
        String denominacion = cliente.getDenominacion();

        List<ClienteResumenDTO> enMinusculas = catalogoService.listarClientes(denominacion.toLowerCase());
        List<ClienteResumenDTO> enMayusculas = catalogoService.listarClientes(denominacion.toUpperCase());

        assertEquals(enMinusculas.size(), enMayusculas.size());
        assertFalse(enMinusculas.isEmpty());
    }

    @Test
    void unaBusquedaEnBlancoDevuelveTodosLosRegistros() {
        long clientes = entityManager.createQuery("SELECT COUNT(c) FROM Cliente c", Long.class)
                .getSingleResult();
        long listas = entityManager.createQuery("SELECT COUNT(lp) FROM ListaPrecio lp", Long.class)
                .getSingleResult();
        // El precio vive en la lista precio articulo: hay una fila por relacion.
        long precios = entityManager.createQuery(
                "SELECT COUNT(lpa) FROM ListaPrecioArticulo lpa", Long.class).getSingleResult();

        assertEquals(clientes, catalogoService.listarClientes("   ").size());
        assertEquals(listas, catalogoService.listarListasPrecio("   ").size());
        assertEquals(precios, catalogoService.listarArticulos(null, "   ").size());
    }

    @Test
    void losComodinesDelLikeNoSeTomanComoComodines() {
        // Un "%" tecleado por el usuario tiene que buscar un "%" literal,
        // no matchear todos los registros.
        assertTrue(catalogoService.listarClientes("%").isEmpty());
        assertTrue(catalogoService.listarListasPrecio("%").isEmpty());
        assertTrue(catalogoService.listarArticulos(null, "%").isEmpty());
        assertTrue(catalogoService.listarClientes("_").isEmpty());
    }

    @Test
    void unaListaDePrecioInexistenteNoDevuelveArticulos() {
        ListaPrecio listaTest = crearLista("LP-TEST-VACIA", "Lista de Prueba");

        assertTrue(catalogoService.listarArticulos(listaTest.getId(), null).isEmpty());
        assertTrue(catalogoService.listarArticulos(999999L, null).isEmpty());
    }

    // ------------------------------------------------------------------
    // Utilidades
    // ------------------------------------------------------------------

    private <T> T primero(Class<T> tipo) {
        return entityManager.createQuery("SELECT e FROM " + tipo.getSimpleName() + " e ORDER BY e.id", tipo)
                .setMaxResults(1)
                .getResultList()
                .get(0);
    }

    private ListaPrecio primeroPorCodigo(String codigo) {
        return entityManager.createQuery(
                        "SELECT lp FROM ListaPrecio lp WHERE lp.codigo = :codigo", ListaPrecio.class)
                .setParameter("codigo", codigo)
                .setMaxResults(1)
                .getResultList()
                .get(0);
    }

    private ListaPrecio crearLista(String codigo, String denominacion) {
        ListaPrecio lista = new ListaPrecio();
        lista.setCodigo(codigo);
        lista.setDenominacion(denominacion);
        completarAuditoria(lista);
        entityManager.persist(lista);
        return lista;
    }

    /** Las tablas de la base son NOT NULL en los campos de auditoria. */
    private void completarAuditoria(com.utn.tpgrupal.entities.AuditoriaApp entidad) {
        Usuario usuario = primero(Usuario.class);
        entidad.setFechaAlta(new Date());
        entidad.setFechaModificacion(new Date());
        entidad.setUsuarioCarga(usuario);
        entidad.setUsuarioModificacion(usuario);
    }

    private ListaPrecioArticulo crearPrecio(ListaPrecio lista, Articulo articulo, double precio) {
        ListaPrecioArticulo relacion = new ListaPrecioArticulo();
        relacion.setListaPrecio(lista);
        relacion.setArticulo(articulo);
        relacion.setPrecioVenta(precio);
        completarAuditoria(relacion);
        entityManager.persist(relacion);
        return relacion;
    }
}
