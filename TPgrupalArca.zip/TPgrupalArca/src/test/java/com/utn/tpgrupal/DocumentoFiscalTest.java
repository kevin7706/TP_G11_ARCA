package com.utn.tpgrupal;
import com.utn.tpgrupal.validation.DocumentoFiscal;
import com.utn.tpgrupal.exception.DatosInvalidosException;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class DocumentoFiscalTest {
    @Test void normalizaUnCuitConDigitoValido() { assertEquals("20111111112", DocumentoFiscal.validar(80,"20-11111111-2").numero()); }
    @Test void rechazaCuitConDigitoIncorrecto() { assertThrows(DatosInvalidosException.class, () -> DocumentoFiscal.validar(80,"20111111113")); }
    @Test void noConvierteDniEnCuit() { var d=DocumentoFiscal.validar(96,"10.000.001"); assertEquals(96,d.tipo()); assertEquals("10000001",d.numero()); }
    @Test void sinIdentificarSoloAdmiteCero() { assertEquals("0",DocumentoFiscal.validar(99,"0").numero()); assertThrows(DatosInvalidosException.class, () -> DocumentoFiscal.validar(99,"12345678")); }
    @Test void rechazaLetrasEnLugarDeBorrarlas() { assertThrows(DatosInvalidosException.class, () -> DocumentoFiscal.validar(96,"DNI10000001")); }
    @Test void rechazaNulosTiposNoSoportadosYDocumentoVacio() {
        assertThrows(DatosInvalidosException.class, () -> DocumentoFiscal.validar(null,"0"));
        assertThrows(DatosInvalidosException.class, () -> DocumentoFiscal.validar(1,"10000001"));
        assertThrows(DatosInvalidosException.class, () -> DocumentoFiscal.validar(96,null));
    }
    @Test void dniDebeTenerSieteUOchoDigitos() { for (String n : new String[]{"00000000","123456","123456789"}) assertThrows(DatosInvalidosException.class, () -> DocumentoFiscal.validar(96,n)); }
    @Test void cuilYCdiTienenTipoPropio() { assertEquals(86,DocumentoFiscal.validar(86,"20111111112").tipo()); assertEquals(87,DocumentoFiscal.validar(87,"20111111112").tipo()); }
}
