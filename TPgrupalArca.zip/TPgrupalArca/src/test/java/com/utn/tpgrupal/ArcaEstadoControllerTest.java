package com.utn.tpgrupal;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.utn.tpgrupal.rest.ArcaEstadoController;
import com.utn.tpgrupal.service.arca.*;
import com.utn.tpgrupal.exception.DatosInvalidosException;
import java.time.Instant;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ArcaEstadoControllerTest {
    @Test void diagnosticoNoExponeCredenciales() throws Exception {
        ArcaConfig c = configuracion();
        WsaaService wsaa = mock(WsaaService.class); WsfeService wsfe = mock(WsfeService.class);
        when(wsaa.obtener()).thenReturn(new WsaaService.Ticket("TOKEN_PRIVADO", "FIRMA_PRIVADA", Instant.parse("2026-11-04T15:00:00Z")));
        when(wsfe.ultimo(1, 6)).thenReturn(1L);
        var estado = new ArcaEstadoController(wsaa, wsfe, c, 1).estado();
        String resultado = new ObjectMapper().registerModule(new JavaTimeModule()).writeValueAsString(estado);
        assertEquals("HOMOLOGACION", estado.ambiente()); assertTrue(estado.autenticado()); assertEquals(1, estado.ultimoAutorizado());
        assertFalse(resultado.contains("TOKEN_PRIVADO")); assertFalse(resultado.contains("FIRMA_PRIVADA"));
    }
    @Test void fallosNoDevuelvenContenidoSensibleDeExcepciones() throws Exception {
        WsaaService wsaa = mock(WsaaService.class); WsfeService wsfe = mock(WsfeService.class);
        when(wsaa.obtener()).thenThrow(new java.io.IOException("TOKEN_PRIVADO"));
        var controller = new ArcaEstadoController(wsaa, wsfe, configuracion(), 1);
        var error = assertThrows(DatosInvalidosException.class, controller::estado);
        assertFalse(error.getMessage().contains("TOKEN_PRIVADO")); verifyNoInteractions(wsfe);
    }
    private ArcaConfig configuracion() {
        ArcaConfig c = new ArcaConfig(); c.habilitada = true; c.cuit = "20111111112"; c.clave = "test.key";
        c.certificado = "test.crt"; c.tipoComprobante = 6; c.razonSocial = "TEST"; c.domicilio = "TEST"; c.condicionIva = "TEST";
        return c;
    }
}
