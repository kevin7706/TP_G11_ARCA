package com.utn.tpgrupal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.utn.tpgrupal.dto.FacturaDetalleRequestDTO;
import com.utn.tpgrupal.dto.FacturaEdicionDTO;
import com.utn.tpgrupal.dto.FacturaReporteDTO;
import com.utn.tpgrupal.dto.FacturaRequestDTO;
import com.utn.tpgrupal.entities.Cliente;
import com.utn.tpgrupal.entities.CondicionIva;
import com.utn.tpgrupal.entities.ListaPrecioArticulo;
import com.utn.tpgrupal.entities.PuntoVenta;
import com.utn.tpgrupal.entities.TipoMoneda;
import jakarta.persistence.EntityManager;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

/**
 * Verifica los codigos HTTP y el cuerpo de error de las operaciones de
 * escritura, y comprueba que un error dentro de la transaccion no deja
 * cambios a medias en la base.
 */
@SpringBootTest(
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
        properties = "spring.datasource.url=jdbc:h2:mem:facturacion_escritura;MODE=MariaDB;DB_CLOSE_DELAY=-1")
class FacturaEscrituraTest {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    @Autowired
    private TestRestTemplate rest;

    @Autowired
    private EntityManager entityManager;

    @Test
    void creaFacturaDevuelve201ConLocationYCuerpoReporte() {
        ResponseEntity<String> respuesta = rest.postForEntity(
                "/api/facturas", nuevaFactura(), String.class);

        assertEquals(HttpStatus.CREATED, respuesta.getStatusCode());
        assertNotNull(respuesta.getHeaders().getFirst("Location"));

        JsonNode cuerpo = leer(respuesta.getBody());
        assertTrue(cuerpo.has("id"));
        assertTrue(cuerpo.has("numeroFactura"));
        assertTrue(cuerpo.has("fechaEmision"));
        assertTrue(cuerpo.has("importeTotal"));
        assertEquals("PENDIENTE", cuerpo.get("estado").asText());
    }

    @Test
    void creaFacturaConRelacionInexistenteDevuelve404() {
        FacturaRequestDTO request = nuevaFactura();
        request.setClienteId(999999L);

        ResponseEntity<String> respuesta = rest.postForEntity(
                "/api/facturas", request, String.class);

        assertEquals(HttpStatus.NOT_FOUND, respuesta.getStatusCode());
        assertFormatoError(respuesta.getBody(), 404);
    }

    @Test
    void creaFacturaSinDetallesDevuelve400() {
        FacturaRequestDTO request = nuevaFactura();
        request.setDetalles(List.of());

        ResponseEntity<String> respuesta = rest.postForEntity(
                "/api/facturas", request, String.class);

        assertEquals(HttpStatus.BAD_REQUEST, respuesta.getStatusCode());
        assertFormatoError(respuesta.getBody(), 400);
    }

    @Test
    void creaFacturaConCantidadInvalidaDevuelve400() {
        FacturaRequestDTO request = nuevaFactura();
        FacturaDetalleRequestDTO detalle = request.getDetalles().get(0);
        detalle.setCantidad(0.0);

        ResponseEntity<String> respuesta = rest.postForEntity(
                "/api/facturas", request, String.class);

        assertEquals(HttpStatus.BAD_REQUEST, respuesta.getStatusCode());
        assertFormatoError(respuesta.getBody(), 400);
    }

    @Test
    void revierteLosCambiosCuandoFallaUnDetalleDeLaActualizacion() {
        ResponseEntity<FacturaReporteDTO> creada = rest.postForEntity(
                "/api/facturas", nuevaFactura(), FacturaReporteDTO.class);
        assertEquals(HttpStatus.CREATED, creada.getStatusCode());
        Long id = creada.getBody().getId();

        ResponseEntity<FacturaEdicionDTO> antes = rest.getForEntity(
                "/api/facturas/" + id, FacturaEdicionDTO.class);
        assertEquals(1, antes.getBody().getDetalles().size());

        // La cabecera se valida bien, pero el renglon apunta a una lista de
        // precios inexistente: la transaccion debe revertirse por completo.
        FacturaDetalleRequestDTO detalleInvalido = new FacturaDetalleRequestDTO();
        detalleInvalido.setListaPrecioArticuloId(999999L);
        detalleInvalido.setCantidad(3.0);

        FacturaRequestDTO request = new FacturaRequestDTO();
        request.setObservaciones("No debe quedar guardado");
        request.setDetalles(List.of(detalleInvalido));

        ResponseEntity<String> respuesta = rest.exchange(
                "/api/facturas/" + id, HttpMethod.PUT, new HttpEntity<>(request), String.class);

        assertEquals(HttpStatus.NOT_FOUND, respuesta.getStatusCode());

        ResponseEntity<FacturaEdicionDTO> despues = rest.getForEntity(
                "/api/facturas/" + id, FacturaEdicionDTO.class);
        assertEquals(HttpStatus.OK, despues.getStatusCode());
        assertEquals(1, despues.getBody().getDetalles().size(),
                "Los detalles originales deben conservarse tras el rollback");
        assertFalse("No debe quedar guardado".equals(despues.getBody().getObservaciones()),
                "La cabecera tampoco debe quedar modificada tras el rollback");
    }

    @Test
    void actualizaFacturaInexistenteDevuelve404() {
        FacturaRequestDTO request = new FacturaRequestDTO();
        request.setObservaciones("No existe");

        ResponseEntity<String> respuesta = rest.exchange(
                "/api/facturas/999999", HttpMethod.PUT, new HttpEntity<>(request), String.class);

        assertEquals(HttpStatus.NOT_FOUND, respuesta.getStatusCode());
        assertFormatoError(respuesta.getBody(), 404);
    }

    @Test
    void anulaFacturaDevuelve204SinCuerpo() {
        ResponseEntity<FacturaReporteDTO> creada = rest.postForEntity(
                "/api/facturas", nuevaFactura(), FacturaReporteDTO.class);
        Long id = creada.getBody().getId();

        ResponseEntity<String> anulada = rest.exchange(
                "/api/facturas/" + id, HttpMethod.DELETE, null, String.class);

        assertEquals(HttpStatus.NO_CONTENT, anulada.getStatusCode());
        assertTrue(anulada.getBody() == null || anulada.getBody().isBlank(),
                "La respuesta 204 no debe llevar cuerpo");
    }

    @Test
    void anulaFacturaInexistenteDevuelve404() {
        ResponseEntity<String> respuesta = rest.exchange(
                "/api/facturas/999999", HttpMethod.DELETE, null, String.class);

        assertEquals(HttpStatus.NOT_FOUND, respuesta.getStatusCode());
        assertFormatoError(respuesta.getBody(), 404);
    }

    @Test
    void eliminaDefinitivamenteFacturaInexistenteDevuelve404() {
        ResponseEntity<String> respuesta = rest.exchange(
                "/api/facturas/999999/definitiva", HttpMethod.DELETE, null, String.class);

        assertEquals(HttpStatus.NOT_FOUND, respuesta.getStatusCode());
        assertFormatoError(respuesta.getBody(), 404);
    }

    @Test
    void consultaFacturaInexistenteDevuelve404() {
        ResponseEntity<String> respuesta = rest.getForEntity(
                "/api/facturas/999999", String.class);

        assertEquals(HttpStatus.NOT_FOUND, respuesta.getStatusCode());
        assertFormatoError(respuesta.getBody(), 404);
    }

    @Test
    void consultaConIdNoNumericoDevuelve400() {
        ResponseEntity<String> respuesta = rest.getForEntity(
                "/api/facturas/no-es-un-numero", String.class);

        assertEquals(HttpStatus.BAD_REQUEST, respuesta.getStatusCode());
        assertFormatoError(respuesta.getBody(), 400);
    }

    @Test
    void cuerpoDeErrorUsaElFormatoStatusMensajeFecha() {
        ResponseEntity<String> respuesta = rest.getForEntity(
                "/api/facturas/999999", String.class);

        JsonNode cuerpo = leer(respuesta.getBody());
        assertEquals(404, cuerpo.get("status").asInt());
        assertTrue(cuerpo.hasNonNull("mensaje"));
        assertFalse(cuerpo.get("mensaje").asText().isBlank());
        assertTrue(cuerpo.hasNonNull("fecha"));
    }

    /**
     * La fecha de emision es una fecha pura: no puede corrirse un dia por el
     * cambio de zona horaria entre JSON y la columna DATE.
     */
    @Test
    void laFechaDeEmisionSeConservaSinCorrimiento() {
        FacturaRequestDTO request = nuevaFactura();
        request.setFechaEmision(aFecha(2026, 10, 21));

        ResponseEntity<String> creada = rest.postForEntity(
                "/api/facturas", request, String.class);
        assertEquals(HttpStatus.CREATED, creada.getStatusCode());

        JsonNode cuerpo = leer(creada.getBody());
        assertEquals("2026-10-21", cuerpo.get("fechaEmision").asText());

        ResponseEntity<String> guardada = rest.getForEntity(
                "/api/facturas/" + cuerpo.get("id").asLong(), String.class);
        assertEquals(HttpStatus.OK, guardada.getStatusCode());
        assertEquals("2026-10-21", leer(guardada.getBody()).get("fechaEmision").asText());
    }

    /** Los filtros de fecha son inclusivos: el mismo dia debe encontrar la factura. */
    @Test
    void elFiltroPorFechaEsInclusivo() {
        FacturaRequestDTO request = nuevaFactura();
        request.setFechaEmision(aFecha(2026, 11, 5));

        rest.postForEntity("/api/facturas", request, FacturaReporteDTO.class);

        ResponseEntity<String> mismoDia = rest.getForEntity(
                "/api/facturas?fechaDesde=2026-11-05&fechaHasta=2026-11-05", String.class);
        assertEquals(HttpStatus.OK, mismoDia.getStatusCode());
        assertTrue(leer(mismoDia.getBody()).get("contenido").size() >= 1,
                "El filtro del mismo dia debe devolver la factura");

        ResponseEntity<String> siguienteDia = rest.getForEntity(
                "/api/facturas?fechaDesde=2026-11-06&fechaHasta=2026-11-30", String.class);
        assertEquals(0, leer(siguienteDia.getBody()).get("contenido").size(),
                "El filtro no debe traer facturas de otros dias");
    }

    private void assertFormatoError(String cuerpo, int statusEsperado) {
        JsonNode cuerpoJson = leer(cuerpo);
        assertEquals(statusEsperado, cuerpoJson.get("status").asInt());
        assertTrue(cuerpoJson.hasNonNull("mensaje"));
        assertTrue(cuerpoJson.hasNonNull("fecha"));
    }

    private JsonNode leer(String cuerpo) {
        try {
            return MAPPER.readTree(cuerpo);
        } catch (Exception e) {
            throw new IllegalStateException("Respuesta no es JSON valido: " + cuerpo, e);
        }
    }

    /** Instante de la medianoche local de un dia, como lo maneja la base. */
    private Date aFecha(int anio, int mes, int dia) {
        return Date.from(LocalDate.of(anio, mes, dia).atStartOfDay(ZoneId.systemDefault()).toInstant());
    }

    private FacturaRequestDTO nuevaFactura() {        PuntoVenta puntoVenta = primero(PuntoVenta.class);
        CondicionIva condicionIva = primero(CondicionIva.class);
        TipoMoneda tipoMoneda = primero(TipoMoneda.class);
        Cliente cliente = primero(Cliente.class);
        ListaPrecioArticulo precio = primero(ListaPrecioArticulo.class);

        FacturaDetalleRequestDTO detalle = new FacturaDetalleRequestDTO();
        detalle.setArticuloId(precio.getArticulo().getId());
        detalle.setListaPrecioArticuloId(precio.getId());
        detalle.setCantidad(2.0);
        detalle.setPorcentajeBonificacion(10.0);
        detalle.setPorcentajeIva(21.0);

        FacturaRequestDTO request = new FacturaRequestDTO();
        request.setFechaEmision(new Date());
        request.setClienteId(cliente.getId());
        request.setCondicionIvaId(condicionIva.getId());
        request.setPuntoVentaId(puntoVenta.getId());
        request.setTipoMonedaId(tipoMoneda.getId());
        request.setDetalles(List.of(detalle));
        return request;
    }

    private <T> T primero(Class<T> tipo) {
        return entityManager.createQuery("SELECT e FROM " + tipo.getSimpleName() + " e", tipo)
                .setMaxResults(1)
                .getResultList()
                .get(0);
    }
}
