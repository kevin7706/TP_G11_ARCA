package com.utn.tpgrupal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.utn.tpgrupal.dto.FacturaReporteDTO;
import com.utn.tpgrupal.service.FacturaService;
import java.util.Comparator;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FacturaServiceTest {
    @Autowired
    private FacturaService facturaService;

    @Test
    void devuelveReporteConCantidadDeItemsYConsumidorFinal() {
        List<FacturaReporteDTO> reporte = facturaService.buscarFacturasFiltradas(null, null, "PENDIENTE", null);

        assertEquals(2, reporte.size());
        assertTrue(reporte.stream().anyMatch(factura -> factura.getCantidadItems() == 2));
        assertTrue(reporte.stream().anyMatch(factura -> "Consumidor Final".equals(factura.getClienteDenominacion())));
    }

    @Test
    void filtraPorMontoMinimo() {
        List<FacturaReporteDTO> todas = facturaService.buscarFacturasFiltradas(null, null, null, null);
        assertFalse(todas.isEmpty());

        // El corte se hace justo por encima de la factura mas barata: tiene que
        // quedar afuera y el resto tiene que seguir entrando.
        FacturaReporteDTO masBarata = todas.stream()
                .min(Comparator.comparingDouble(FacturaReporteDTO::getImporteTotal))
                .orElseThrow();
        double umbral = masBarata.getImporteTotal() + 0.01;

        List<FacturaReporteDTO> reporte = facturaService.buscarFacturasFiltradas(null, null, null, umbral);
        long esperadas = todas.stream()
                .filter(f -> f.getImporteTotal() >= umbral).count();

        assertEquals(esperadas, reporte.size());
        assertTrue(reporte.stream().allMatch(f -> f.getImporteTotal() >= umbral));
        assertTrue(reporte.stream()
                .noneMatch(f -> f.getId().equals(masBarata.getId())));
    }
}
