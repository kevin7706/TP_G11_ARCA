package com.utn.tpgrupal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.utn.tpgrupal.dto.FacturaReporteDTO;
import com.utn.tpgrupal.service.FacturaService;
import java.io.ByteArrayInputStream;
import java.util.List;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * El reporte de Excel tiene que ser un .xlsx de verdad: un archivo que Excel
 * abre con celdas, no un texto con tabulaciones al que despues se le cambia
 * el nombre.
 */
@SpringBootTest
class FacturaReporteExcelTest {

    private static final String[] ENCABEZADOS = {
        "Numero", "Fecha", "Cliente", "Condicion IVA", "Punto de venta", "Estado",
        "Total", "Cantidad de items"
    };

    @Autowired
    private FacturaService facturaService;

    @Test
    void elArchivoTieneLaFirmaDeUnOfficeOpenXml() {
        byte[] contenido = facturaService.generarReporteExcel(null, null, null, null);

        assertTrue(contenido.length > 0);
        // La firma de un .xlsx es un zip: "PK".
        assertEquals('P', contenido[0]);
        assertEquals('K', contenido[1]);
    }

    @Test
    void elArchivoSeAbreComoLibroDeExcel() throws Exception {
        byte[] contenido = facturaService.generarReporteExcel(null, null, null, null);

        try (Workbook libro = WorkbookFactory.create(new ByteArrayInputStream(contenido))) {
            assertNotNull(libro);
            assertEquals(1, libro.getNumberOfSheets());
            assertTrue(libro.getSheetAt(0).getRow(0).getPhysicalNumberOfCells() > 0);
        }
    }

    @Test
    void tieneLosEncabezadosEnNegrita() throws Exception {
        byte[] contenido = facturaService.generarReporteExcel(null, null, null, null);

        try (Workbook libro = WorkbookFactory.create(new ByteArrayInputStream(contenido))) {
            Row encabezado = libro.getSheetAt(0).getRow(0);

            for (int columna = 0; columna < ENCABEZADOS.length; columna++) {
                Cell celda = encabezado.getCell(columna);
                assertNotNull(celda, "falta la celda del encabezado " + columna);
                assertEquals(ENCABEZADOS[columna], celda.getStringCellValue());
                boolean enNegrita = libro.getFontAt(celda.getCellStyle().getFontIndex()).getBold();
                assertTrue(enNegrita, "el encabezado " + columna + " deberia estar en negrita");
            }
        }
    }

    @Test
    void traeUnaFilaPorFactura() throws Exception {
        List<FacturaReporteDTO> esperadas = facturaService.buscarFacturasFiltradas(null, null, null, null);
        assertFalse(esperadas.isEmpty());

        byte[] contenido = facturaService.generarReporteExcel(null, null, null, null);

        try (Workbook libro = WorkbookFactory.create(new ByteArrayInputStream(contenido))) {
            Sheet hoja = libro.getSheetAt(0);
            assertEquals(esperadas.size() + 1, hoja.getLastRowNum() + 1);
        }
    }

    @Test
    void laFechaEsUnaCeldaDeFecha() throws Exception {
        byte[] contenido = facturaService.generarReporteExcel(null, null, null, null);

        try (Workbook libro = WorkbookFactory.create(new ByteArrayInputStream(contenido))) {
            Row primeraFila = libro.getSheetAt(0).getRow(1);
            Cell celdaFecha = primeraFila.getCell(1);

            assertEquals(CellType.NUMERIC, celdaFecha.getCellType());
            assertTrue(org.apache.poi.ss.usermodel.DateUtil.isCellDateFormatted(celdaFecha));
        }
    }

    @Test
    void elTotalEsUnNumeroSumable() throws Exception {
        List<FacturaReporteDTO> esperadas = facturaService.buscarFacturasFiltradas(null, null, null, null);

        byte[] contenido = facturaService.generarReporteExcel(null, null, null, null);

        try (Workbook libro = WorkbookFactory.create(new ByteArrayInputStream(contenido))) {
            Sheet hoja = libro.getSheetAt(0);
            double suma = 0;
            for (int indice = 0; indice < esperadas.size(); indice++) {
                Cell celdaTotal = hoja.getRow(indice + 1).getCell(6);
                assertEquals(CellType.NUMERIC, celdaTotal.getCellType());
                suma += celdaTotal.getNumericCellValue();
            }
            double sumaEsperada = esperadas.stream()
                    .mapToDouble(FacturaReporteDTO::getImporteTotal).sum();
            assertEquals(sumaEsperada, suma, 0.01);
        }
    }

    @Test
    void elNumeroDeFacturaEsUnNumero() throws Exception {
        List<FacturaReporteDTO> esperadas = facturaService.buscarFacturasFiltradas(null, null, null, null);

        byte[] contenido = facturaService.generarReporteExcel(null, null, null, null);

        try (Workbook libro = WorkbookFactory.create(new ByteArrayInputStream(contenido))) {
            Sheet hoja = libro.getSheetAt(0);
            for (int indice = 0; indice < esperadas.size(); indice++) {
                Cell celdaNumero = hoja.getRow(indice + 1).getCell(0);
                if (esperadas.get(indice).getNumeroFactura() == null) {
                    assertEquals("Pendiente", celdaNumero.getStringCellValue());
                } else {
                    assertEquals(CellType.NUMERIC, celdaNumero.getCellType());
                    assertEquals(esperadas.get(indice).getNumeroFactura().doubleValue(), celdaNumero.getNumericCellValue(), 0.001);
                }
            }
        }
    }

    @Test
    void congelaLaFilaDeEncabezadosYAplicaAutofiltro() throws Exception {
        byte[] contenido = facturaService.generarReporteExcel(null, null, null, null);

        try (Workbook libro = WorkbookFactory.create(new ByteArrayInputStream(contenido))) {
            Sheet hoja = libro.getSheetAt(0);
            assertNotNull(hoja.getPaneInformation(), "deberia tener panel congelado");
            assertTrue(hoja.getPaneInformation().isFreezePane(), "el panel deberia ser freeze pane");
            assertEquals(1, hoja.getPaneInformation().getHorizontalSplitPosition());
        }
    }
}
