package com.utn.tpgrupal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.utn.tpgrupal.dto.FacturaDetalleRequestDTO;
import com.utn.tpgrupal.dto.FacturaEdicionDTO;
import com.utn.tpgrupal.dto.FacturaReporteDTO;
import com.utn.tpgrupal.dto.FacturaRequestDTO;
import com.utn.tpgrupal.entities.Cliente;
import com.utn.tpgrupal.entities.CondicionIva;
import com.utn.tpgrupal.entities.ListaPrecioArticulo;
import com.utn.tpgrupal.entities.PuntoVenta;
import com.utn.tpgrupal.entities.TipoMoneda;
import jakarta.persistence.EntityManager;
import java.util.Date;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@SpringBootTest(
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
        properties = "spring.datasource.url=jdbc:h2:mem:facturacion_web;MODE=MariaDB;DB_CLOSE_DELAY=-1")
class FacturaRestControllerTest {

    @Autowired
    private TestRestTemplate rest;

    @Autowired
    private EntityManager entityManager;

    @Test
    void ejecutaFlujoCompletoDeCrudPorRest() {
        FacturaRequestDTO request = nuevaFactura();

        ResponseEntity<FacturaReporteDTO> creada = rest.postForEntity(
                "/api/facturas", request, FacturaReporteDTO.class);
        assertEquals(HttpStatus.CREATED, creada.getStatusCode());
        assertNotNull(creada.getBody());
        Long id = creada.getBody().getId();
        assertNotNull(id);
        assertEquals("/api/facturas/" + id, creada.getHeaders().getFirst(HttpHeaders.LOCATION));

        ResponseEntity<FacturaEdicionDTO> detalle = rest.getForEntity(
                "/api/facturas/" + id, FacturaEdicionDTO.class);
        assertEquals(HttpStatus.OK, detalle.getStatusCode());
        assertNotNull(detalle.getBody());
        assertEquals(1, detalle.getBody().getDetalles().size());

        FacturaRequestDTO anulacion = new FacturaRequestDTO();
        anulacion.setEstado("ANULADA");
        ResponseEntity<FacturaReporteDTO> anulada = rest.exchange(
                "/api/facturas/" + id,
                HttpMethod.PUT,
                new HttpEntity<>(anulacion),
                FacturaReporteDTO.class);
        assertEquals(HttpStatus.OK, anulada.getStatusCode());
        assertNotNull(anulada.getBody());
        assertEquals("ANULADA", anulada.getBody().getEstado());

        ResponseEntity<Void> eliminada = rest.exchange(
                "/api/facturas/" + id + "/definitiva", HttpMethod.DELETE, null, Void.class);
        assertEquals(HttpStatus.NO_CONTENT, eliminada.getStatusCode());
        assertNull(eliminada.getBody());

        ResponseEntity<String> inexistente = rest.getForEntity(
                "/api/facturas/" + id, String.class);
        assertEquals(HttpStatus.NOT_FOUND, inexistente.getStatusCode());
    }

    @Test
    void eliminarSinDefinitivaRealizaLaAnulacionLogica() {
        ResponseEntity<FacturaReporteDTO> creada = rest.postForEntity(
                "/api/facturas", nuevaFactura(), FacturaReporteDTO.class);
        assertEquals(HttpStatus.CREATED, creada.getStatusCode());
        Long id = creada.getBody().getId();

        ResponseEntity<Void> anulada = rest.exchange(
                "/api/facturas/" + id, HttpMethod.DELETE, null, Void.class);
        assertEquals(HttpStatus.NO_CONTENT, anulada.getStatusCode());
        assertNull(anulada.getBody());

        ResponseEntity<FacturaReporteDTO> factura = rest.getForEntity(
                "/api/facturas/" + id, FacturaReporteDTO.class);
        assertEquals(HttpStatus.OK, factura.getStatusCode());
        assertEquals("ANULADA", factura.getBody().getEstado());
    }

    @Test
    void devuelveCatalogoDeClientes() {
        ResponseEntity<String> respuesta = rest.getForEntity(
                "/api/catalogos/clientes", String.class);

        assertEquals(HttpStatus.OK, respuesta.getStatusCode());
        assertNotNull(respuesta.getBody());
        assertTrue(respuesta.getBody().startsWith("["));
    }

    private FacturaRequestDTO nuevaFactura() {
        PuntoVenta puntoVenta = primero(PuntoVenta.class);
        CondicionIva condicionIva = primero(CondicionIva.class);
        TipoMoneda tipoMoneda = primero(TipoMoneda.class);
        Cliente cliente = primero(Cliente.class);
        ListaPrecioArticulo precio = primero(ListaPrecioArticulo.class);

        FacturaDetalleRequestDTO detalle = new FacturaDetalleRequestDTO();
        detalle.setArticuloId(precio.getArticulo().getId());
        detalle.setListaPrecioArticuloId(precio.getId());
        detalle.setCantidad(2.0);
        detalle.setPorcentajeBonificacion(10.0);
        detalle.setPorcentajeIva(21.0);

        FacturaRequestDTO request = new FacturaRequestDTO();
        request.setFechaEmision(new Date());
        request.setClienteId(cliente.getId());
        request.setCondicionIvaId(condicionIva.getId());
        request.setPuntoVentaId(puntoVenta.getId());
        request.setTipoMonedaId(tipoMoneda.getId());
        request.setDetalles(List.of(detalle));
        return request;
    }

    private <T> T primero(Class<T> tipo) {
        return entityManager.createQuery("SELECT e FROM " + tipo.getSimpleName() + " e", tipo)
                .setMaxResults(1)
                .getResultList()
                .get(0);
    }
}
