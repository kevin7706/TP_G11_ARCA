package com.utn.tpgrupal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.utn.tpgrupal.dto.FacturaDetalleRequestDTO;
import com.utn.tpgrupal.dto.FacturaReporteDTO;
import com.utn.tpgrupal.dto.FacturaRequestDTO;
import com.utn.tpgrupal.entities.Cliente;
import com.utn.tpgrupal.entities.CondicionIva;
import com.utn.tpgrupal.entities.FacturaVenta;
import com.utn.tpgrupal.entities.FacturaVentaDetalle;
import com.utn.tpgrupal.entities.ListaPrecioArticulo;
import com.utn.tpgrupal.entities.PuntoVenta;
import com.utn.tpgrupal.entities.TipoMoneda;
import com.utn.tpgrupal.exception.DatosInvalidosException;
import com.utn.tpgrupal.exception.RecursoNoEncontradoException;
import com.utn.tpgrupal.service.FacturaService;
import jakarta.persistence.EntityManager;
import java.util.Date;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

@SpringBootTest
@Transactional
class FacturaCrudServiceTest {

    @Autowired
    private FacturaService facturaService;

    @Autowired
    private EntityManager entityManager;

    @Test
    void creaFacturaConDetallesYCalculaImportes() {
        PuntoVenta puntoVenta = primero(PuntoVenta.class);
        CondicionIva condicionIva = primero(CondicionIva.class);
        TipoMoneda tipoMoneda = primero(TipoMoneda.class);
        Cliente cliente = primero(Cliente.class);
        ListaPrecioArticulo precio = primero(ListaPrecioArticulo.class);

        FacturaDetalleRequestDTO detalle = new FacturaDetalleRequestDTO();
        detalle.setArticuloId(precio.getArticulo().getId());
        detalle.setListaPrecioArticuloId(precio.getId());
        detalle.setCantidad(2.0);
        detalle.setPorcentajeBonificacion(10.0);
        detalle.setPorcentajeIva(21.0);

        FacturaRequestDTO request = new FacturaRequestDTO();
        request.setFechaEmision(new Date());
        request.setClienteId(cliente.getId());
        request.setCondicionIvaId(condicionIva.getId());
        request.setPuntoVentaId(puntoVenta.getId());
        request.setTipoMonedaId(tipoMoneda.getId());
        request.setDetalles(List.of(detalle));

        FacturaReporteDTO reporte = facturaService.crear(request);

        assertNotNull(reporte.getId());
        assertEquals(1, reporte.getCantidadItems());
        assertEquals("PENDIENTE", reporte.getEstado());
        assertTrue(reporte.getImporteTotal() > 0);

        FacturaVenta factura = entityManager.find(FacturaVenta.class, reporte.getId());
        assertNotNull(factura);
        assertEquals(1, factura.getDetalles().size());

        // 2 x precio con 10% de bonificacion, mas 21% de IVA.
        double neto = Math.round(precio.getPrecioVenta() * 2 * 0.9 * 100.0) / 100.0;
        double iva = Math.round(neto * 21.0) / 100.0;
        FacturaVentaDetalle persistido = factura.getDetalles().get(0);
        assertEquals(neto, persistido.getImporteNeto(), 0.001);
        assertEquals(iva, persistido.getImporteIva(), 0.001);
        assertEquals(neto + iva, persistido.getImporteSubtotal(), 0.001);
        assertEquals(factura.getImporteTotal(), factura.getDetalles().get(0).getImporteSubtotal(), 0.001);
    }

    @Test
    void anulaFacturaYAsignaFechaAnulacion() {
        FacturaVenta factura = facturaEmitida();

        FacturaRequestDTO request = new FacturaRequestDTO();
        request.setEstado("ANULADA");
        request.setObservaciones("Anulada en test");

        FacturaReporteDTO reporte = facturaService.actualizar(factura.getId(), request);

        assertEquals("ANULADA", reporte.getEstado());
        FacturaVenta actualizada = entityManager.find(FacturaVenta.class, factura.getId());
        assertEquals("ANULADA", actualizada.getEstado());
        assertNotNull(actualizada.getFechaAnulacion());
        assertEquals("Anulada en test", actualizada.getObservaciones());
    }

    @Test
    void eliminarRealizaAnulacionLogicaYConservaLaFactura() {
        FacturaVenta factura = facturaEmitida();
        Long facturaId = factura.getId();
        Long detalleId = factura.getDetalles().get(0).getId();

        facturaService.eliminar(facturaId);

        FacturaVenta anulada = entityManager.find(FacturaVenta.class, facturaId);
        assertNotNull(anulada, "La factura no debe borrarse fisicamente: se anula logicamente");
        assertEquals("ANULADA", anulada.getEstado());
        assertNotNull(anulada.getFechaAnulacion());
        assertNotNull(entityManager.find(FacturaVentaDetalle.class, detalleId));
    }

    @Test
    void eliminarFisicamenteBorraFacturaYDetalles() {
        FacturaVenta factura = facturaEmitida();
        Long facturaId = factura.getId();
        Long detalleId = factura.getDetalles().get(0).getId();

        facturaService.eliminarFisicamente(facturaId);

        assertNull(entityManager.find(FacturaVenta.class, facturaId));
        assertNull(entityManager.find(FacturaVentaDetalle.class, detalleId));
    }

    @Test
    void noPermiteAnularDosVecesLaMismaFactura() {
        FacturaVenta factura = facturaEmitida();

        facturaService.eliminar(factura.getId());

        assertThrows(DatosInvalidosException.class, () -> facturaService.eliminar(factura.getId()));
    }

    @Test
    void lanzaExcepcionCuandoLaFacturaNoExiste() {
        assertThrows(RecursoNoEncontradoException.class, () -> facturaService.eliminar(-1L));
        assertThrows(RecursoNoEncontradoException.class, () -> facturaService.eliminarFisicamente(-1L));
        assertThrows(RecursoNoEncontradoException.class, () -> facturaService.actualizar(-1L, new FacturaRequestDTO()));
    }

    @Test
    void noPermiteModificarUnaFacturaAnulada() {
        FacturaVenta factura = facturaEmitida();
        facturaService.eliminar(factura.getId());

        FacturaRequestDTO request = new FacturaRequestDTO();
        request.setObservaciones("Intento de edicion sobre factura anulada");

        assertThrows(DatosInvalidosException.class,
                () -> facturaService.actualizar(factura.getId(), request));
    }

    @Test
    void noPermiteDesanularUnaFactura() {
        FacturaVenta factura = facturaEmitida();
        facturaService.eliminar(factura.getId());

        FacturaRequestDTO request = new FacturaRequestDTO();
        request.setEstado("PENDIENTE");

        assertThrows(DatosInvalidosException.class,
                () -> facturaService.actualizar(factura.getId(), request));
    }

    @Test
    void obtieneFacturaConDetallesParaEdicion() {
        FacturaVenta factura = facturaEmitida();

        var edicion = facturaService.obtener(factura.getId());

        assertEquals(factura.getId(), edicion.getId());
        assertEquals(factura.getDetalles().size(), edicion.getDetalles().size());
        assertNotNull(edicion.getDetalles().get(0).getListaPrecioArticuloId());
        assertNotNull(edicion.getDetalles().get(0).getArticuloId());
    }

    @Test
    void actualizaCabeceraYReconciliaDetalles() {
        FacturaVenta factura = facturaEmitida();
        ListaPrecioArticulo precio = primero(ListaPrecioArticulo.class);

        FacturaDetalleRequestDTO primero = new FacturaDetalleRequestDTO();
        primero.setListaPrecioArticuloId(precio.getId());
        primero.setCantidad(1.0);
        primero.setPorcentajeIva(21.0);

        FacturaDetalleRequestDTO segundo = new FacturaDetalleRequestDTO();
        segundo.setListaPrecioArticuloId(precio.getId());
        segundo.setCantidad(3.0);
        segundo.setPorcentajeIva(10.5);
        segundo.setPorcentajeBonificacion(5.0);

        FacturaRequestDTO request = new FacturaRequestDTO();
        request.setObservaciones("Factura actualizada en test");
        request.setDetalles(List.of(primero, segundo));

        FacturaReporteDTO reporte = facturaService.actualizar(factura.getId(), request);

        assertEquals(2, reporte.getCantidadItems());
        FacturaVenta actualizada = entityManager.find(FacturaVenta.class, factura.getId());
        assertEquals("Factura actualizada en test", actualizada.getObservaciones());
        assertEquals(2, actualizada.getDetalles().size());
        assertEquals(reporte.getImporteTotal(), actualizada.getImporteTotal(), 0.001);
    }

    @Test
    void conservaLaIdentidadDeLosDetallesQueSeModifican() {
        FacturaVenta factura = facturaEmitidaConDosDetalles();
        List<FacturaVentaDetalle> originales = List.copyOf(factura.getDetalles());
        Long detalleIdModificado = originales.get(0).getId();
        Long detalleIdReemplazado = originales.get(originales.size() - 1).getId();

        FacturaDetalleRequestDTO modificado = new FacturaDetalleRequestDTO();
        modificado.setDetalleId(detalleIdModificado);
        modificado.setListaPrecioArticuloId(originales.get(0).getListaPrecioArticulo().getId());
        modificado.setCantidad(5.0);
        modificado.setPorcentajeIva(21.0);

        FacturaDetalleRequestDTO nuevo = new FacturaDetalleRequestDTO();
        nuevo.setListaPrecioArticuloId(primero(ListaPrecioArticulo.class).getId());
        nuevo.setCantidad(2.0);
        nuevo.setPorcentajeIva(21.0);

        FacturaRequestDTO request = new FacturaRequestDTO();
        request.setDetalles(List.of(modificado, nuevo));

        facturaService.actualizar(factura.getId(), request);
        entityManager.flush();

        FacturaVenta actualizada = entityManager.find(FacturaVenta.class, factura.getId());
        assertEquals(2, actualizada.getDetalles().size());

        boolean conservaId = actualizada.getDetalles().stream()
                .anyMatch(detalle -> detalleIdModificado.equals(detalle.getId()));
        assertTrue(conservaId, "El detalle modificado debe conservar su identificador");

        boolean eliminoElResto = actualizada.getDetalles().stream()
                .noneMatch(detalle -> detalleIdReemplazado.equals(detalle.getId()));
        assertTrue(eliminoElResto, "El detalle que no fue enviado debe eliminarse");
    }

    @Test
    void eliminaLosDetallesQueNoSeEnvianEnLaActualizacion() {
        FacturaVenta factura = facturaEmitidaConDosDetalles();
        List<FacturaVentaDetalle> originales = List.copyOf(factura.getDetalles());
        Long detalleQueSeElimina = originales.get(originales.size() - 1).getId();

        FacturaDetalleRequestDTO conservado = new FacturaDetalleRequestDTO();
        conservado.setDetalleId(originales.get(0).getId());
        conservado.setListaPrecioArticuloId(originales.get(0).getListaPrecioArticulo().getId());
        conservado.setCantidad(1.0);
        conservado.setPorcentajeIva(21.0);

        FacturaRequestDTO request = new FacturaRequestDTO();
        request.setDetalles(List.of(conservado));

        facturaService.actualizar(factura.getId(), request);
        entityManager.flush();

        FacturaVenta actualizada = entityManager.find(FacturaVenta.class, factura.getId());
        assertEquals(1, actualizada.getDetalles().size());
        assertNull(entityManager.find(FacturaVentaDetalle.class, detalleQueSeElimina));
    }

    @Test
    void noDejaFacturasParcialesCuandoUnDetalleNoExiste() {
        long facturasAntes = entityManager
                .createQuery("SELECT COUNT(f) FROM FacturaVenta f", Long.class)
                .getSingleResult();

        ListaPrecioArticulo precio = primero(ListaPrecioArticulo.class);
        FacturaDetalleRequestDTO detalleInvalido = new FacturaDetalleRequestDTO();
        detalleInvalido.setListaPrecioArticuloId(999999L);
        detalleInvalido.setCantidad(1.0);

        FacturaRequestDTO request = new FacturaRequestDTO();
        request.setFechaEmision(new Date());
        request.setCondicionIvaId(primero(CondicionIva.class).getId());
        request.setPuntoVentaId(primero(PuntoVenta.class).getId());
        request.setTipoMonedaId(primero(TipoMoneda.class).getId());
        request.setDetalles(List.of(detalleInvalido));

        assertThrows(RecursoNoEncontradoException.class, () -> facturaService.crear(request));

        long facturasDespues = entityManager
                .createQuery("SELECT COUNT(f) FROM FacturaVenta f", Long.class)
                .getSingleResult();
        assertEquals(facturasAntes, facturasDespues, "No debe quedar ninguna factura persistida");
        assertNotNull(precio);
    }

    private FacturaVenta facturaEmitida() {
        return entityManager.createQuery(
                        "SELECT f FROM FacturaVenta f WHERE f.estado = 'PENDIENTE'", FacturaVenta.class)
                .setMaxResults(1)
                .getSingleResult();
    }

    private FacturaVenta facturaEmitidaConDosDetalles() {
        return entityManager.createQuery(
                        "SELECT f FROM FacturaVenta f WHERE f.estado = 'PENDIENTE' AND size(f.detalles) > 1",
                        FacturaVenta.class)
                .setMaxResults(1)
                .getSingleResult();
    }

    private <T> T primero(Class<T> tipo) {
        return entityManager.createQuery("SELECT e FROM " + tipo.getSimpleName() + " e", tipo)
                .setMaxResults(1)
                .getResultList()
                .get(0);
    }
}
