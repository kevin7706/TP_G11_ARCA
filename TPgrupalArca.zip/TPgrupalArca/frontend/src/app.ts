import './styles.css';
import type {
  ArticuloPrecio,
  Cliente,
  CondicionIva,
  ListaPrecio,
  PuntoVenta,
  TipoMoneda,
} from './models/catalogo.dto';
import type {
  FacturaEdicionDTO,
  FacturaFiltrosDTO,
  FacturaReporteDTO,
  FacturaRequestDTO,
} from './models/factura.dto';
import {
  calcularLinea,
  calcularTotales,
  validarLinea,
  type LineaDetalle,
} from './logica/importes';
import { CatalogoService } from './services/CatalogoService';
import { FacturaService } from './services/FacturaService';
import { API_BASE_URL, HttpError } from './services/http';
import { crearExplorador, type ExploradorElementos } from './ui/explorador';

function el<T extends HTMLElement>(id: string): T {
  const node = document.getElementById(id);
  if (!node) {
    throw new Error(`No se encontró el elemento #${id}`);
  }
  return node as T;
}

const apiStatus = el<HTMLDivElement>('api-status');
const apiStatusText = el<HTMLSpanElement>('api-status-text');

const filtrosForm = el<HTMLFormElement>('filtros-form');
const filtroDesde = el<HTMLInputElement>('filtro-desde');
const filtroHasta = el<HTMLInputElement>('filtro-hasta');
const filtroEstado = el<HTMLSelectElement>('filtro-estado');
const filtroMonto = el<HTMLInputElement>('filtro-monto');
const btnLimpiar = el<HTMLButtonElement>('btn-limpiar');
const exportExcel = el<HTMLAnchorElement>('export-excel');
const exportPdf = el<HTMLAnchorElement>('export-pdf');

const facturasBody = el<HTMLTableSectionElement>('facturas-body');
const facturasCount = el<HTMLParagraphElement>('facturas-count');

const btnNuevaFactura = el<HTMLButtonElement>('btn-nueva-factura');
const modalFactura = el<HTMLElement>('modal-factura');
const formTitle = el<HTMLHeadingElement>('form-title');
const formSubtitle = el<HTMLParagraphElement>('form-subtitle');
const facturaForm = el<HTMLFormElement>('factura-form');
const facturaFecha = el<HTMLInputElement>('factura-fecha');
const facturaListaPrecioTexto = el<HTMLInputElement>('factura-lista-precio-texto');
const btnBuscarListaPrecio = el<HTMLButtonElement>('btn-buscar-lista-precio');
const facturaClienteTexto = el<HTMLInputElement>('factura-cliente-texto');
const btnBuscarCliente = el<HTMLButtonElement>('btn-buscar-cliente');
const btnLimpiarCliente = el<HTMLButtonElement>('btn-limpiar-cliente');
const facturaCondicionIva = el<HTMLSelectElement>('factura-condicion-iva');
const facturaPuntoVenta = el<HTMLSelectElement>('factura-punto-venta');
const facturaTipoMoneda = el<HTMLSelectElement>('factura-tipo-moneda');
const facturaEstado = el<HTMLSelectElement>('factura-estado');
const facturaObservaciones = el<HTMLTextAreaElement>('factura-observaciones');
const btnCancelarEdicion = el<HTMLButtonElement>('btn-cancelar-edicion');
const btnAgregarLinea = el<HTMLButtonElement>('btn-agregar-linea');
const detallesBody = el<HTMLTableSectionElement>('detalles-body');
const totalesNeto = el<HTMLElement>('totales-neto');
const totalesIva = el<HTMLElement>('totales-iva');
const totalesTotal = el<HTMLElement>('totales-total');
const btnGuardar = el<HTMLButtonElement>('btn-guardar');
const btnReset = el<HTMLButtonElement>('btn-reset');
const toastContainer = el<HTMLDivElement>('toast-container');

const ICONO_LUPA = `
              <svg class="icono-lupa" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                <circle cx="11" cy="11" r="7"></circle>
                <line x1="16.5" y1="16.5" x2="21" y2="21"></line>
              </svg>`;

let condicionesIva: CondicionIva[] = [];
let puntosVenta: PuntoVenta[] = [];
let tiposMoneda: TipoMoneda[] = [];
let listasPrecio: ListaPrecio[] = [];
let facturas: FacturaReporteDTO[] = [];
let lineas: LineaDetalle[] = [];
let filtrosActuales: FacturaFiltrosDTO = {};
let pagina = 0;
let totalPaginas = 0;
let totalElementos = 0;
let editandoId: number | null = null;
let proximaLinea = 1;

/** Lista de precio elegida: define los precios de los artículos. */
let listaPrecioSeleccionada: ListaPrecio | null = null;
/** Cliente elegido en el formulario (null = consumidor final). */
let clienteSeleccionado: Cliente | null = null;
/** Renglón que está eligiendo artículo en el explorador. */
let renglonEnEdicion: number | null = null;

const moneyFormatter = new Intl.NumberFormat('es-AR', {
  style: 'currency',
  currency: 'ARS',
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});

function formatMoney(value: number): string {
  return moneyFormatter.format(Number.isFinite(value) ? value : 0);
}

function formatearFecha(value: string): string {
  const [anio, mes, dia] = value.split('-');
  return anio && mes && dia ? `${dia}/${mes}/${anio}` : value;
}

function hoyISO(): string {
  const ahora = new Date();
  const anio = ahora.getFullYear();
  const mes = String(ahora.getMonth() + 1).padStart(2, '0');
  const dia = String(ahora.getDate()).padStart(2, '0');
  return `${anio}-${mes}-${dia}`;
}

function escapeHtml(value: string): string {
  return value.replace(/[&<>"']/g, (character) => {
    switch (character) {
      case '&':
        return '&amp;';
      case '<':
        return '&lt;';
      case '>':
        return '&gt;';
      case '"':
        return '&quot;';
      default:
        return '&#39;';
    }
  });
}

function mostrarToast(
  mensaje: string,
  tipo: 'success' | 'error' | 'info' = 'info',
): void {
  const toast = document.createElement('div');
  toast.className = `toast toast--${tipo}`;

  const texto = document.createElement('span');
  texto.textContent = mensaje;

  const cerrar = document.createElement('button');
  cerrar.type = 'button';
  cerrar.className = 'toast__close';
  cerrar.textContent = '×';
  cerrar.setAttribute('aria-label', 'Cerrar notificación');
  cerrar.addEventListener('click', () => toast.remove());

  toast.append(texto, cerrar);
  toastContainer.append(toast);
  window.setTimeout(() => toast.remove(), 5000);
}

function mensajeError(error: unknown): string {
  if (error instanceof HttpError) {
    return error.message;
  }
  if (error instanceof Error) {
    return error.message;
  }
  return 'Ocurrió un error inesperado';
}

function marcarConectado(conectado: boolean): void {
  apiStatus.classList.toggle('api-status--online', conectado);
  apiStatus.classList.toggle('api-status--offline', !conectado);
  apiStatusText.textContent = conectado ? 'API conectada' : 'API sin conexión';
}

function crearOpcion(valor: string, texto: string): HTMLOptionElement {
  const opcion = document.createElement('option');
  opcion.value = valor;
  opcion.textContent = texto;
  return opcion;
}

function llenarSelect(select: HTMLSelectElement, opciones: Array<[string, string]>): void {
  select.replaceChildren(crearOpcion('', 'Seleccione...'));
  for (const [valor, texto] of opciones) {
    select.append(crearOpcion(valor, texto));
  }
}

function poblarSelects(): void {
  llenarSelect(
    facturaCondicionIva,
    condicionesIva.map((condicion) => [String(condicion.id), condicion.denominacion]),
  );
  llenarSelect(
    facturaPuntoVenta,
    puntosVenta.map((punto) => [String(punto.id), `${punto.numero} - ${punto.descripcion}`]),
  );
  llenarSelect(
    facturaTipoMoneda,
    tiposMoneda.map((moneda) => [String(moneda.id), `${moneda.denominacion} (${moneda.simbolo})`]),
  );
}

async function cargarCatalogos(): Promise<void> {
  const [condicionesData, puntosData, monedasData, listasData] = await Promise.all([
    CatalogoService.listarCondicionesIva(),
    CatalogoService.listarPuntosVenta(),
    CatalogoService.listarTiposMoneda(),
    CatalogoService.listarListasPrecio(),
  ]);

  condicionesIva = condicionesData;
  puntosVenta = puntosData;
  tiposMoneda = monedasData;
  listasPrecio = listasData;

  poblarSelects();
}

/* ------------------------------------------------------------------ */
/* Exploradores: cliente, lista de precio y artículo.                 */
/* ------------------------------------------------------------------ */

const elementosExplorador: ExploradorElementos = {
  modal: el<HTMLElement>('explorador'),
  titulo: el<HTMLElement>('explorador-titulo'),
  formulario: el<HTMLFormElement>('explorador-busqueda'),
  texto: el<HTMLInputElement>('explorador-texto'),
  encabezados: el<HTMLTableRowElement>('explorador-encabezados'),
  filas: el<HTMLTableSectionElement>('explorador-filas'),
};

function etiquetaCliente(cliente: Cliente): string {
  const tipo = ({80: 'CUIT', 86: 'CUIL', 87: 'CDI', 96: 'DNI', 99: 'Sin identificar'} as Record<number, string>)[cliente.tipoDocumento ?? 80];
  const numero = cliente.numeroDocumento ?? cliente.cuitCuil ?? '';
  return `${cliente.denominacion} (${tipo}${cliente.tipoDocumento === 99 ? '' : ' ' + numero}${cliente.datosEjemplo ? ' · ejemplo' : ''})`;
}

function mostrarDatosCliente(cliente: Cliente | null, aplicarCondicion = false): void {
  el('cliente-fiscal').hidden = cliente === null;
  if (!cliente) return;
  el<HTMLSelectElement>('cliente-documento-tipo').value = String(cliente.tipoDocumento ?? 80);
  el<HTMLInputElement>('cliente-documento-numero').value = cliente.numeroDocumento ?? cliente.cuitCuil ?? '';
  const documentoOriginal = (cliente.cuitCuil ?? '').replace(/[ .-]/g, '');
  const cuitFicticioOriginal = cliente.datosEjemplo && [80, 86, 87].includes(cliente.tipoDocumento ?? 80)
    && (cliente.numeroDocumento ?? documentoOriginal) === documentoOriginal;
  el('cliente-fiscal-info').textContent = cuitFicticioOriginal
    ? 'Ejemplo de CRUD con CUIT ficticio. Para informar a ARCA, configurá un documento válido o elegí explícitamente consumidor final sin identificar cuando corresponda.'
    : cliente.datosEjemplo ? 'Cliente de ejemplo para homologación. Verificá el documento configurado; las semillas no representan identidades reales.'
    : 'Revisá el tipo de documento y la condición IVA antes de informar.';
  if (aplicarCondicion && cliente.codigoCondicionIva != null) {
    const condicion = condicionesIva.find(c => c.codigoAfip === cliente.codigoCondicionIva);
    if (condicion) facturaCondicionIva.value = String(condicion.id);
  }
}

async function guardarDatosCliente(): Promise<void> {
  if (!clienteSeleccionado) return;
  const boton = el<HTMLButtonElement>('guardar-cliente-fiscal'); boton.disabled = true;
  try {
    const condicion = condicionesIva.find(c => c.id === Number(facturaCondicionIva.value));
    if (!condicion?.codigoAfip) throw new Error('Elegí la condición IVA del cliente.');
    clienteSeleccionado = await CatalogoService.actualizarDatosFiscales(clienteSeleccionado.id, {
      tipoDocumento: Number(el<HTMLSelectElement>('cliente-documento-tipo').value),
      numeroDocumento: el<HTMLInputElement>('cliente-documento-numero').value,
      codigoCondicionIva: condicion.codigoAfip,
    });
    facturaClienteTexto.value = etiquetaCliente(clienteSeleccionado);
    mostrarDatosCliente(clienteSeleccionado);
    mostrarToast('Datos fiscales del cliente guardados.', 'success');
  } catch (error) { mostrarToast(mensajeError(error), 'error'); }
  finally { boton.disabled = false; }
}

function etiquetaListaPrecio(lista: ListaPrecio): string {
  return `${lista.codigo} - ${lista.denominacion}`;
}

const exploradorCliente = crearExplorador<Cliente>(elementosExplorador, {
  titulo: 'Buscar cliente',
  placeholder: 'Buscar por nombre, DNI o CUIT',
  columnas: [
    { etiqueta: 'Denominación', valor: (cliente) => cliente.denominacion },
    { etiqueta: 'Documento', valor: (cliente) => etiquetaCliente(cliente).split('(').slice(1).join('(').replace(/\)$/, '') },
  ],
  buscar: (texto) => CatalogoService.listarClientes(texto),
  alElegir: (cliente) => {
    clienteSeleccionado = cliente;
    mostrarDatosCliente(cliente, true);
    facturaClienteTexto.value = etiquetaCliente(cliente);
    btnLimpiarCliente.hidden = false;
  },
});

const exploradorListaPrecio = crearExplorador<ListaPrecio>(elementosExplorador, {
  titulo: 'Buscar lista de precio',
  placeholder: 'Buscar por código o nombre',
  columnas: [
    { etiqueta: 'Código', valor: (lista) => lista.codigo },
    { etiqueta: 'Denominación', valor: (lista) => lista.denominacion },
  ],
  buscar: (texto) => CatalogoService.listarListasPrecio(texto),
  alElegir: (lista) => aplicarListaPrecio(lista),
});

const exploradorArticulo = crearExplorador<ArticuloPrecio>(elementosExplorador, {
  titulo: 'Buscar artículo',
  placeholder: 'Buscar por código o nombre',
  columnas: [
    { etiqueta: 'Código', valor: (articulo) => articulo.codigo },
    { etiqueta: 'Artículo', valor: (articulo) => articulo.denominacion },
    { etiqueta: 'Precio', valor: (articulo) => formatMoney(articulo.precioVenta) },
  ],
  buscar: (texto) =>
    CatalogoService.listarArticulos(listaPrecioSeleccionada?.id, texto),
  alElegir: (articulo) => {
    const key = renglonEnEdicion;
    renglonEnEdicion = null;

    if (key === null) {
      return;
    }

    const linea = lineas.find((item) => item.key === key);
    if (!linea) {
      return;
    }

    linea.listaPrecioArticuloId = articulo.listaPrecioArticuloId;
    linea.articuloId = articulo.articuloId;
    linea.articuloEtiqueta = `${articulo.codigo} - ${articulo.denominacion}`;
    linea.precioUnitario = articulo.precioVenta;
    if (!linea.descripcion.trim()) {
      linea.descripcion = articulo.denominacion;
    }

    renderLineas();
  },
});

/**
 * Cambia la lista de precio del formulario. Como el precio vive en el
 * ListaPrecioArticulo, al cambiar de lista hay que volver a elegir los
 * artículos.
 */
function aplicarListaPrecio(lista: ListaPrecio): void {
  if (listaPrecioSeleccionada?.id === lista.id) {
    return;
  }

  if (lineas.some((linea) => linea.listaPrecioArticuloId)) {
    const respuesta = window.confirm(
      'Cambiar la lista de precio borra los artículos ya elegidos. ¿Continuá?',
    );
    if (!respuesta) {
      return;
    }

    for (const linea of lineas) {
      linea.listaPrecioArticuloId = null;
      linea.articuloId = null;
      linea.articuloEtiqueta = '';
      linea.precioUnitario = 0;
    }
    renderLineas();
  }

  listaPrecioSeleccionada = lista;
  facturaListaPrecioTexto.value = etiquetaListaPrecio(lista);
}

function abrirExploradorArticulo(key: number): void {
  if (!listaPrecioSeleccionada) {
    mostrarToast('Elegí primero la lista de precio de los artículos.', 'error');
    return;
  }

  renglonEnEdicion = key;
  void exploradorArticulo.abrir();
}

/* ------------------------------------------------------------------ */
/* Modal del formulario                                                */
/* ------------------------------------------------------------------ */

function abrirFormulario(): void {
  modalFactura.hidden = false;
  modalFactura.setAttribute('aria-hidden', 'false');
  document.body.classList.add('modal-abierto');
}

function cerrarFormulario(): void {
  modalFactura.hidden = true;
  modalFactura.setAttribute('aria-hidden', 'true');
  document.body.classList.remove('modal-abierto');
}

/* ------------------------------------------------------------------ */
/* Detalles de la factura                                              */
/* ------------------------------------------------------------------ */

function renderLineas(): void {
  if (lineas.length === 0) {
    detallesBody.innerHTML = `
      <tr>
        <td colspan="8" class="empty-cell">Agregá al menos un artículo para comenzar.</td>
      </tr>`;
    renderTotales();
    return;
  }

  detallesBody.innerHTML = lineas
    .map((linea) => {
      const importes = calcularLinea(linea);

      return `
        <tr data-key="${linea.key}">
          <td class="cell-articulo">
            <div class="input-lupa">
              <input
                class="input"
                type="text"
                readonly
                data-field="articuloEtiqueta"
                data-key="${linea.key}"
                value="${escapeHtml(linea.articuloEtiqueta ?? '')}"
                placeholder="Elegí un artículo"
                title="${escapeHtml(linea.articuloEtiqueta ?? '')}"
              />
              <button
                type="button"
                class="btn-lupa"
                data-action="buscar-articulo"
                data-key="${linea.key}"
                title="Buscar artículo"
                aria-label="Buscar artículo"
              >
                ${ICONO_LUPA}
              </button>
            </div>
          </td>
          <td>
            <input
              class="input"
              data-field="descripcion"
              data-key="${linea.key}"
              value="${escapeHtml(linea.descripcion)}"
              placeholder="Descripción"
            />
          </td>
          <td>
            <input
              type="number"
              min="1"
              step="1"
              class="input input--number"
              data-field="cantidad"
              data-key="${linea.key}"
              value="${linea.cantidad}"
            />
          </td>
          <td>
            <input
              type="number"
              min="0"
              step="0.01"
              class="input input--number"
              data-field="precioUnitario"
              data-key="${linea.key}"
              value="${linea.precioUnitario}"
            />
          </td>
          <td>
            <input
              type="number"
              min="0"
              max="100"
              step="0.01"
              class="input input--number"
              data-field="porcentajeBonificacion"
              data-key="${linea.key}"
              value="${linea.porcentajeBonificacion}"
            />
          </td>
          <td>
            <input
              type="number"
              min="0"
              step="0.01"
              class="input input--number"
              data-field="porcentajeIva"
              data-key="${linea.key}"
              value="${linea.porcentajeIva}"
            />
          </td>
          <td class="text-right subtotal-cell" id="subtotal-${linea.key}">
            ${formatMoney(importes.subtotal)}
          </td>
          <td class="text-center">
            <button
              type="button"
              class="btn-icon btn-icon--danger"
              data-action="eliminar-linea"
              data-key="${linea.key}"
              title="Quitar artículo"
              aria-label="Quitar artículo"
            >
              ×
            </button>
          </td>
        </tr>`;
    })
    .join('');

  renderTotales();
}

function renderTotales(): void {
  const totales = calcularTotales(lineas);

  totalesNeto.textContent = formatMoney(totales.neto);
  totalesIva.textContent = formatMoney(totales.iva);
  totalesTotal.textContent = formatMoney(totales.subtotal);
}

function agregarLinea(render = true): void {
  lineas.push({
    key: proximaLinea++,
    detalleId: null,
    listaPrecioArticuloId: null,
    articuloId: null,
    descripcion: '',
    cantidad: 1,
    precioUnitario: 0,
    porcentajeBonificacion: 0,
    porcentajeIva: 21,
    articuloEtiqueta: '',
  });

  if (render) {
    renderLineas();
  }
}

function actualizarLinea(
  key: number,
  field: string,
  target: HTMLInputElement,
): void {
  const linea = lineas.find((item) => item.key === key);
  if (!linea) {
    return;
  }

  if (field === 'descripcion') {
    linea.descripcion = target.value;
    return;
  }

  const value = Number(target.value);
  if (!Number.isFinite(value)) {
    return;
  }

  switch (field) {
    case 'cantidad':
      linea.cantidad = value;
      break;
    case 'precioUnitario':
      linea.precioUnitario = value;
      break;
    case 'porcentajeBonificacion':
      linea.porcentajeBonificacion = value;
      break;
    case 'porcentajeIva':
      linea.porcentajeIva = value;
      break;
    default:
      return;
  }

  const subtotalCell = document.getElementById(`subtotal-${key}`);
  if (subtotalCell) {
    subtotalCell.textContent = formatMoney(calcularLinea(linea).subtotal);
  }
  renderTotales();
}

/* ------------------------------------------------------------------ */
/* Listado de facturas                                                 */
/* ------------------------------------------------------------------ */

function renderFacturas(): void {
  facturasCount.textContent = `${totalElementos} factura(s) encontrada(s)`;

  if (facturas.length === 0) {
    facturasBody.innerHTML = `
      <tr>
        <td colspan="9" class="empty-cell">No hay facturas para los filtros seleccionados.</td>
      </tr>`;
    return;
  }

  facturasBody.innerHTML = facturas
    .map((factura) => {
      const anulada = factura.estado === 'ANULADA';
      const bloqueada = anulada || Boolean(factura.cae) || ['AUTORIZADA', 'ENVIANDO', 'A_VERIFICAR'].includes(factura.estado);
      return `
        <tr>
          <td class="cell-numero">${factura.numeroFactura ?? 'Pendiente'}</td>
          <td>${formatearFecha(factura.fechaEmision)}</td>
          <td>${escapeHtml(factura.clienteDenominacion)}</td>
          <td>${escapeHtml(factura.condicionIva)}</td>
          <td>${escapeHtml(factura.puntoVentaDescripcion)}</td>
          <td>
            <span class="badge ${anulada || factura.estado === 'RECHAZADA' || factura.estado === 'A_VERIFICAR' ? 'badge--danger' : factura.estado === 'AUTORIZADA' ? 'badge--success' : ''}">
              ${escapeHtml(factura.estado)}
            </span>
          </td>
          <td class="text-right">${formatMoney(factura.importeTotal)}</td>
          <td class="text-center">${factura.cantidadItems}</td>
          <td class="actions">
            <a class="btn btn-small btn-ghost" href="${API_BASE_URL}/api/facturas/${factura.id}/pdf" target="_blank" rel="noopener">PDF</a>
            <button type="button" class="btn btn-small btn-primary" data-action="informar" data-id="${factura.id}" ${bloqueada ? 'disabled' : ''}>Informar a ARCA</button>
            ${['A_VERIFICAR', 'ENVIANDO'].includes(factura.estado) ? `<button type="button" class="btn btn-small btn-secondary" data-action="verificar" data-id="${factura.id}">Verificar ARCA</button>` : ''}
            ${factura.cae ? `<span>CAE: ${escapeHtml(factura.cae)} · Vto: ${factura.caeFechaVencimiento ?? ''}</span>` : ''}
            ${factura.motivoRechazo ? `<details class="arca-motivo"><summary>Ver ${factura.estado === 'RECHAZADA' ? 'motivo del rechazo' : 'observaciones ARCA'}</summary><p>${escapeHtml(factura.motivoRechazo)}</p></details>` : ''}
            <button
              type="button"
              class="btn btn-small btn-ghost"
              data-action="editar"
              data-id="${factura.id}"
              ${bloqueada ? 'disabled title="La factura no admite modificaciones"' : ''}
            >
              Editar
            </button>
            ${
              bloqueada
                ? ''
                : `<button
                    type="button"
                    class="btn btn-small btn-secondary"
                    data-action="anular"
                    data-id="${factura.id}"
                  >
                    Anular
                  </button>`
            }
            <button
              type="button"
              class="btn btn-small btn-danger"
              ${factura.cae || ['AUTORIZADA', 'ENVIANDO', 'A_VERIFICAR'].includes(factura.estado) ? 'disabled' : ''}
              data-action="eliminar"
              data-id="${factura.id}"
            >
              Eliminar
            </button>
          </td>
        </tr>`;
    })
    .join('');
}

function actualizarExportLinks(): void {
  const params = new URLSearchParams();
  for (const key of ['numero', 'clienteId', 'informada'] as const) {
    if (filtrosActuales[key] !== undefined) params.set(key, String(filtrosActuales[key]));
  }

  if (filtrosActuales.fechaDesde) {
    params.set('fechaDesde', filtrosActuales.fechaDesde);
  }
  if (filtrosActuales.fechaHasta) {
    params.set('fechaHasta', filtrosActuales.fechaHasta);
  }
  if (filtrosActuales.estado) {
    params.set('estado', filtrosActuales.estado);
  }
  if (
    filtrosActuales.montoMinimo !== undefined &&
    Number.isFinite(filtrosActuales.montoMinimo)
  ) {
    params.set('montoMinimo', String(filtrosActuales.montoMinimo));
  }

  const queryString = params.toString();
  const sufijo = queryString ? `?${queryString}` : '';
  exportExcel.href = `${API_BASE_URL}/api/facturas/exportar/excel${sufijo}`;
  exportPdf.href = `${API_BASE_URL}/api/facturas/exportar/pdf${sufijo}`;
}

async function cargarFacturas(): Promise<void> {
  try {
    const resultado = await FacturaService.obtenerFacturas({...filtrosActuales, page: pagina, size: Number(el<HTMLSelectElement>('pagina-tamanio').value)});
    facturas = resultado.contenido;
    totalElementos = resultado.totalElementos;
    totalPaginas = resultado.totalPaginas;
    if (pagina > 0 && pagina >= totalPaginas) { pagina = Math.max(0, totalPaginas - 1); return cargarFacturas(); }
    el('pagina-info').textContent = totalPaginas ? `Página ${pagina + 1} de ${totalPaginas}` : 'Sin resultados';
    el<HTMLButtonElement>('pagina-anterior').disabled = pagina === 0;
    el<HTMLButtonElement>('pagina-siguiente').disabled = pagina + 1 >= totalPaginas;
    marcarConectado(true);
    renderFacturas();
  } catch (error) {
    facturas = [];
    renderFacturas();
    marcarConectado(false);
    mostrarToast(`No se pudieron cargar las facturas: ${mensajeError(error)}`, 'error');
  } finally {
    actualizarExportLinks();
  }
}

/* ------------------------------------------------------------------ */
/* Alta y edición                                                     */
/* ------------------------------------------------------------------ */

function resetFormulario(): void {
  facturaForm.reset();
  editandoId = null;
  formTitle.textContent = 'Nueva factura';
  formSubtitle.textContent =
    'Completá los datos de la cabecera y agregá al menos un artículo.';
  btnCancelarEdicion.hidden = true;
  btnGuardar.textContent = 'Guardar factura';

  facturaFecha.value = hoyISO();
  listaPrecioSeleccionada = null;
  facturaListaPrecioTexto.value = '';
  clienteSeleccionado = null;
  mostrarDatosCliente(null);
  facturaClienteTexto.value = '';
  btnLimpiarCliente.hidden = true;
  const consumidorFinal = condicionesIva.find(c => c.codigoAfip === 5);
  if (consumidorFinal) facturaCondicionIva.value = String(consumidorFinal.id);
  if (puntosVenta[0]) {
    facturaPuntoVenta.value = String(puntosVenta[0].id);
  }
  if (tiposMoneda[0]) {
    facturaTipoMoneda.value = String(tiposMoneda[0].id);
  }
  facturaEstado.value = 'PENDIENTE';
  facturaObservaciones.value = '';

  lineas = [];
  agregarLinea(false);
  renderLineas();
}

/**
 * Resuelve contra los catálogos el cliente y la lista de precio de una
 * factura: el detalle de la API trae ids pero no nombres.
 */
async function resolverClienteYListaPrecio(factura: FacturaEdicionDTO): Promise<void> {
  clienteSeleccionado = null;
  mostrarDatosCliente(null);
  facturaClienteTexto.value = '';
  btnLimpiarCliente.hidden = true;

  if (factura.clienteId) {
    try {
      const clientes = await CatalogoService.listarClientes();
      const cliente = clientes.find((item) => item.id === factura.clienteId);
      if (cliente) {
        clienteSeleccionado = cliente;
        mostrarDatosCliente(cliente);
        facturaClienteTexto.value = etiquetaCliente(cliente);
        btnLimpiarCliente.hidden = false;
      }
    } catch (error) {
      mostrarToast(
        `No se pudo resolver el cliente de la factura: ${mensajeError(error)}`,
        'error',
      );
    }
  } else {
    facturaClienteTexto.value = 'Consumidor Final';
  }

  listaPrecioSeleccionada = null;
  facturaListaPrecioTexto.value = '';

  try {
    const articulos = await CatalogoService.listarArticulos();
    const porListaPrecioArticulo = new Map(
      articulos.map((articulo) => [articulo.listaPrecioArticuloId, articulo]),
    );

    for (const linea of lineas) {
      const articulo = porListaPrecioArticulo.get(linea.listaPrecioArticuloId ?? -1);
      linea.articuloEtiqueta = articulo
        ? `${articulo.codigo} - ${articulo.denominacion}`
        : '';
    }

    const primerArticulo = porListaPrecioArticulo.get(
      lineas[0]?.listaPrecioArticuloId ?? -1,
    );
    const lista = listasPrecio.find((item) => item.id === primerArticulo?.listaPrecioId);

    if (lista) {
      listaPrecioSeleccionada = lista;
      facturaListaPrecioTexto.value = etiquetaListaPrecio(lista);
    } else if (lineas.length > 0) {
      mostrarToast(
        'La factura usa una lista de precio que ya no está cargada. Elegí la lista antes de buscar artículos.',
        'error',
      );
    }
  } catch (error) {
    mostrarToast(
      `No se pudieron resolver los artículos de la factura: ${mensajeError(error)}`,
      'error',
    );
  }
}

async function aplicarEdicion(factura: FacturaEdicionDTO): Promise<void> {
  editandoId = factura.id;
  formTitle.textContent = `Editar factura ${factura.numero ?? '#' + factura.id}`;
  formSubtitle.textContent = 'Modificá la cabecera o los detalles y guardá los cambios.';
  btnCancelarEdicion.hidden = false;
  btnGuardar.textContent = 'Guardar cambios';

  facturaFecha.value = factura.fechaEmision;
  facturaCondicionIva.value = String(factura.condicionIvaId);
  facturaPuntoVenta.value = String(factura.puntoVentaId);
  facturaTipoMoneda.value = String(factura.tipoMonedaId);
  facturaEstado.value = factura.estado === 'ANULADA' ? 'ANULADA' : 'PENDIENTE';
  facturaObservaciones.value = factura.observaciones ?? '';

  lineas = factura.detalles.map((detalle) => ({
    key: proximaLinea++,
    detalleId: detalle.id,
    listaPrecioArticuloId: detalle.listaPrecioArticuloId,
    articuloId: detalle.articuloId,
    descripcion: detalle.descripcion ?? '',
    cantidad: detalle.cantidad,
    precioUnitario: detalle.precioUnitario,
    porcentajeBonificacion: detalle.porcentajeBonificacion,
    porcentajeIva: detalle.porcentajeIva,
    articuloEtiqueta: '',
  }));

  await resolverClienteYListaPrecio(factura);


  if (lineas.length === 0) {
    agregarLinea(false);
  }

  renderLineas();
}

async function editarFactura(id: number): Promise<void> {
  try {
    const factura = await FacturaService.obtenerFactura(id);
    await aplicarEdicion(factura);
    abrirFormulario();
  } catch (error) {
    mostrarToast(`No se pudo cargar la factura: ${mensajeError(error)}`, 'error');
  }
}

async function guardarFactura(): Promise<void> {
  if (
    !facturaFecha.value ||
    !facturaCondicionIva.value ||
    !facturaPuntoVenta.value ||
    !facturaTipoMoneda.value
  ) {
    mostrarToast('Completá los datos obligatorios de la factura.', 'error');
    return;
  }

  if (!listaPrecioSeleccionada) {
    mostrarToast('Elegí la lista de precio de los artículos.', 'error');
    return;
  }

  if (lineas.length === 0) {
    mostrarToast('La factura debe tener al menos un artículo.', 'error');
    return;
  }

  const problema = lineas.map(validarLinea).find((mensaje) => mensaje !== null);
  if (problema) {
    mostrarToast(`Revisá los artículos: ${problema}.`, 'error');
    return;
  }

  if (clienteSeleccionado && (String(clienteSeleccionado.tipoDocumento ?? 80) !== el<HTMLSelectElement>('cliente-documento-tipo').value
      || (clienteSeleccionado.numeroDocumento ?? clienteSeleccionado.cuitCuil ?? '') !== el<HTMLInputElement>('cliente-documento-numero').value)) {
    mostrarToast('Guardá primero los cambios del documento fiscal del cliente.', 'error'); return;
  }
  const dto: FacturaRequestDTO = {
    fechaEmision: facturaFecha.value,
    clienteId: clienteSeleccionado?.id,
    consumidorFinal: clienteSeleccionado === null,
    condicionIvaId: Number(facturaCondicionIva.value),
    puntoVentaId: Number(facturaPuntoVenta.value),
    tipoMonedaId: Number(facturaTipoMoneda.value),
    estado: facturaEstado.value,
    observaciones: facturaObservaciones.value.trim(),
    detalles: lineas.map((linea) => ({
      detalleId: linea.detalleId ?? undefined,
      articuloId: linea.articuloId ?? undefined,
      listaPrecioArticuloId: linea.listaPrecioArticuloId ?? undefined,
      descripcion: linea.descripcion.trim() || undefined,
      cantidad: linea.cantidad,
      precioUnitario: linea.precioUnitario,
      porcentajeBonificacion: linea.porcentajeBonificacion,
      porcentajeIva: linea.porcentajeIva,
    })),
  };

  btnGuardar.disabled = true;

  try {
    if (editandoId === null) {
      await FacturaService.crearFactura(dto);
      mostrarToast('Factura creada correctamente.', 'success');
    } else {
      await FacturaService.actualizarFactura(editandoId, dto);
      mostrarToast('Factura actualizada correctamente.', 'success');
    }

    cerrarFormulario();
    resetFormulario();
    await cargarFacturas();
  } catch (error) {
    mostrarToast(mensajeError(error), 'error');
  } finally {
    btnGuardar.disabled = false;
  }
}

async function anularFactura(id: number): Promise<void> {
  const factura = facturas.find((item) => item.id === id);
  if (!factura) {
    return;
  }

  if (factura.estado === 'ANULADA') {
    mostrarToast('La factura ya está anulada.', 'info');
    return;
  }

  if (!window.confirm(`¿Anular la factura N° ${factura.numeroFactura}?`)) {
    return;
  }

  try {
    // DELETE /api/facturas/{id} -> anulacion logica (estado ANULADA).
    await FacturaService.eliminarFactura(id);
    mostrarToast('Factura anulada correctamente.', 'success');
    if (editandoId === id) {
      cerrarFormulario();
      resetFormulario();
    }
    await cargarFacturas();
  } catch (error) {
    mostrarToast(mensajeError(error), 'error');
  }
}

async function eliminarFactura(id: number): Promise<void> {
  const factura = facturas.find((item) => item.id === id);
  const numero = factura ? ` N° ${factura.numeroFactura}` : '';

  if (
    !window.confirm(
      `¿Eliminar definitivamente la factura${numero}? Se borra de la base junto con sus items. Esta acción no se puede deshacer.`,
    )
  ) {
    return;
  }

  try {
    // DELETE /api/facturas/{id}/definitiva -> eliminacion fisica en cascada.
    await FacturaService.eliminarFacturaDefinitivamente(id);
    mostrarToast('Factura eliminada definitivamente.', 'success');
    if (editandoId === id) {
      cerrarFormulario();
      resetFormulario();
    }
    await cargarFacturas();
  } catch (error) {
    mostrarToast(mensajeError(error), 'error');
  }
}

/* ------------------------------------------------------------------ */
/* Eventos                                                            */
/* ------------------------------------------------------------------ */

function manejarCambioDetalle(event: Event): void {
  const target = event.target;
  if (!(target instanceof HTMLInputElement)) {
    return;
  }

  const key = Number(target.dataset.key);
  const field = target.dataset.field;
  if (!field || !Number.isFinite(key)) {
    return;
  }

  actualizarLinea(key, field, target);
}

function configurarEventos(): void {
  el('guardar-cliente-fiscal').addEventListener('click', () => { void guardarDatosCliente(); });
  el('cliente-documento-tipo').addEventListener('change', () => {
    if (el<HTMLSelectElement>('cliente-documento-tipo').value === '99') {
      el<HTMLInputElement>('cliente-documento-numero').value = '0';
      const cf = condicionesIva.find(c => c.codigoAfip === 5);
      if (cf) facturaCondicionIva.value = String(cf.id);
    }
  });
  el('pagina-anterior').addEventListener('click', () => { if (pagina > 0) { pagina--; void cargarFacturas(); } });
  el('pagina-siguiente').addEventListener('click', () => { if (pagina + 1 < totalPaginas) { pagina++; void cargarFacturas(); } });
  el('pagina-tamanio').addEventListener('change', () => { pagina = 0; void cargarFacturas(); });
  filtrosForm.addEventListener('submit', (event) => {
    event.preventDefault();
    pagina = 0;
    filtrosActuales = {
      numero: el<HTMLInputElement>('filtro-numero').value ? Number(el<HTMLInputElement>('filtro-numero').value) : undefined,
      clienteId: el<HTMLSelectElement>('filtro-cliente').value ? Number(el<HTMLSelectElement>('filtro-cliente').value) : undefined,
      informada: el<HTMLSelectElement>('filtro-informada').value === '' ? undefined : el<HTMLSelectElement>('filtro-informada').value === 'true',
      fechaDesde: filtroDesde.value || undefined,
      fechaHasta: filtroHasta.value || undefined,
      estado: filtroEstado.value || undefined,
      montoMinimo: filtroMonto.value === '' ? undefined : Number(filtroMonto.value),
    };
    void cargarFacturas();
  });

  btnLimpiar.addEventListener('click', () => {
    filtrosForm.reset();
    filtrosActuales = {};
    pagina = 0;
    void cargarFacturas();
  });

  btnNuevaFactura.addEventListener('click', () => {
    resetFormulario();
    abrirFormulario();
  });

  for (const boton of modalFactura.querySelectorAll('[data-cerrar-factura]')) {
    boton.addEventListener('click', () => {
      cerrarFormulario();
    });
  }

  facturaForm.addEventListener('submit', (event) => {
    event.preventDefault();
    void guardarFactura();
  });

  btnBuscarCliente.addEventListener('click', () => {
    void exploradorCliente.abrir();
  });

  // El campo es readonly: clickearlo tambien abre el explorador.
  facturaClienteTexto.addEventListener('click', () => {
    void exploradorCliente.abrir();
  });

  btnLimpiarCliente.addEventListener('click', () => {
    clienteSeleccionado = null;
    mostrarDatosCliente(null);
    facturaClienteTexto.value = '';
    btnLimpiarCliente.hidden = true;
    const cf = condicionesIva.find(c => c.codigoAfip === 5);
    if (cf) facturaCondicionIva.value = String(cf.id);
  });

  btnBuscarListaPrecio.addEventListener('click', () => {
    void exploradorListaPrecio.abrir();
  });

  facturaListaPrecioTexto.addEventListener('click', () => {
    void exploradorListaPrecio.abrir();
  });

  btnAgregarLinea.addEventListener('click', () => agregarLinea(true));
  btnReset.addEventListener('click', () => resetFormulario());
  btnCancelarEdicion.addEventListener('click', () => {
    cerrarFormulario();
    resetFormulario();
  });

  detallesBody.addEventListener('input', manejarCambioDetalle);
  detallesBody.addEventListener('change', manejarCambioDetalle);

  detallesBody.addEventListener('click', (event) => {
    const target = event.target as HTMLElement;

    const inputArticulo = target.closest('input[data-field="articuloEtiqueta"]');
    if (inputArticulo instanceof HTMLInputElement) {
      const key = Number(inputArticulo.dataset.key);
      if (Number.isFinite(key)) {
        abrirExploradorArticulo(key);
      }
      return;
    }

    const botonBuscar = target.closest('button[data-action="buscar-articulo"]');
    if (botonBuscar instanceof HTMLButtonElement) {
      const key = Number(botonBuscar.dataset.key);
      if (Number.isFinite(key)) {
        abrirExploradorArticulo(key);
      }
      return;
    }

    const boton = target.closest('button[data-action="eliminar-linea"]');
    if (!(boton instanceof HTMLButtonElement)) {
      return;
    }

    const key = Number(boton.dataset.key);
    if (!Number.isFinite(key)) {
      return;
    }

    lineas = lineas.filter((linea) => linea.key !== key);
    renderLineas();
  });

  facturasBody.addEventListener('click', (event) => {
    const target = event.target as HTMLElement;
    const button = target.closest('button[data-action]');
    if (!(button instanceof HTMLButtonElement) || button.disabled) {
      return;
    }

    const id = Number(button.dataset.id);
    if (!Number.isFinite(id)) {
      return;
    }

    // Se bloquea el boton mientras la operacion corre para no duplicar pedidos.
    button.disabled = true;

    switch (button.dataset.action) {
      case 'verificar':
        void FacturaService.verificarArca(id).catch((error: unknown) => mostrarToast(mensajeError(error), 'error')).finally(() => { void cargarFacturas(); button.disabled = false; });
        break;
      case 'informar':
        void FacturaService.informarArca(id).then(async () => {
          const resultado = await FacturaService.obtenerFactura(id);
          if (resultado.estado === 'AUTORIZADA') mostrarToast('Factura autorizada por ARCA.', 'success');
          else mostrarToast('ARCA rechazó la factura. Consultá el motivo y corregí los datos antes de reintentar.', 'error');
        }).catch((error: unknown) => mostrarToast(mensajeError(error), 'error')).finally(() => { void cargarFacturas(); button.disabled = false; });
        break;
      case 'editar':
        void editarFactura(id).finally(() => {
          button.disabled = false;
        });
        break;
      case 'anular':
        void anularFactura(id).finally(() => {
          button.disabled = false;
        });
        break;
      case 'eliminar':
        void eliminarFactura(id).finally(() => {
          button.disabled = false;
        });
        break;
      default:
        button.disabled = false;
        break;
    }
  });

  document.addEventListener('keydown', (event) => {
    if (event.key !== 'Escape') {
      return;
    }
    if (!modalFactura.hidden) {
      cerrarFormulario();
    }
  });
}

async function iniciar(): Promise<void> {
  configurarEventos();

  try {
    await cargarCatalogos();
    const clientesFiltro = await CatalogoService.listarClientes();
    el<HTMLSelectElement>('filtro-cliente').innerHTML = '<option value="">Todos</option>' + clientesFiltro.map(c => `<option value="${c.id}">${escapeHtml(c.denominacion)}</option>`).join('');
    marcarConectado(true);
  } catch (error) {
    marcarConectado(false);
    mostrarToast(
      `No se pudieron cargar los catálogos: ${mensajeError(error)}`,
      'error',
    );
  }

  await cargarFacturas();
  resetFormulario();
}

void iniciar();
