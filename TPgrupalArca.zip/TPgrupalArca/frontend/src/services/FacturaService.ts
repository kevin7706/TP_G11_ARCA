import type {
  FacturaEdicionDTO,
  FacturaPaginaDTO,
  FacturaEstadoUpdateDTO,
  FacturaFiltrosDTO,
  FacturaReporteDTO,
  FacturaRequestDTO,
  FacturaUpdateRequestDTO,
} from '../models/factura.dto';
import { API_BASE_URL, http } from './http';

/** Base de la API de facturas: http://localhost:8080/api/facturas */
const FACTURAS_URL = `${API_BASE_URL}/api/facturas`;

function construirQueryString(filtros: FacturaFiltrosDTO): string {
  const params = new URLSearchParams();
  for (const key of ['numero', 'clienteId', 'informada', 'page', 'size'] as const) {
    if (filtros[key] !== undefined) params.set(key, String(filtros[key]));
  }

  if (filtros.fechaDesde) {
    params.set('fechaDesde', filtros.fechaDesde);
  }
  if (filtros.fechaHasta) {
    params.set('fechaHasta', filtros.fechaHasta);
  }
  if (filtros.estado) {
    params.set('estado', filtros.estado);
  }
  if (filtros.montoMinimo !== undefined && Number.isFinite(filtros.montoMinimo)) {
    params.set('montoMinimo', String(filtros.montoMinimo));
  }

  const queryString = params.toString();
  return queryString ? `?${queryString}` : '';
}

export class FacturaService {
  static verificarArca(id: number): Promise<void> {
    return http.post<void>(`${FACTURAS_URL}/${id}/verificar-arca`, {});
  }
  static informarArca(id: number): Promise<void> {
    return http.post<void>(`${FACTURAS_URL}/${id}/informar-arca`, {});
  }

  /** GET /api/facturas: listado con filtros. */
  static obtenerFacturas(filtros: FacturaFiltrosDTO = {}): Promise<FacturaPaginaDTO> {
    return http.get<FacturaPaginaDTO>(`${FACTURAS_URL}${construirQueryString(filtros)}`);
  }

  /** GET /api/facturas/{id}: detalle editable de una factura. */
  static obtenerFactura(id: number): Promise<FacturaEdicionDTO> {
    return http.get<FacturaEdicionDTO>(`${FACTURAS_URL}/${id}`);
  }

  /** POST /api/facturas: alta de factura -> 201 Created. */
  static crearFactura(factura: FacturaRequestDTO): Promise<FacturaReporteDTO> {
    return http.post<FacturaReporteDTO>(FACTURAS_URL, factura);
  }

  /** PUT /api/facturas/{id}: actualizacion de cabecera e items -> 200 OK. */
  static actualizarFactura(
    id: number,
    factura: FacturaUpdateRequestDTO,
  ): Promise<FacturaReporteDTO> {
    return http.put<FacturaReporteDTO>(`${FACTURAS_URL}/${id}`, factura);
  }

  /**
   * PUT /api/facturas/{id}: actualiza solo el estado (y las observaciones).
   * Los campos que no viajan en el cuerpo no se tocan.
   */
  static actualizarEstado(
    id: number,
    estado: string,
    observaciones?: string,
  ): Promise<FacturaReporteDTO> {
    const body: FacturaEstadoUpdateDTO = { estado };
    if (observaciones !== undefined) {
      body.observaciones = observaciones;
    }
    return http.put<FacturaReporteDTO>(`${FACTURAS_URL}/${id}`, body);
  }

  /**
   * DELETE /api/facturas/{id}: anulacion logica de la factura.
   * El comprobante no se borra: cambia de estado a ANULADA y se le asigna la
   * fecha de anulacion. Responde 204 No Content.
   */
  static eliminarFactura(id: number): Promise<void> {
    return http.delete(`${FACTURAS_URL}/${id}`);
  }

  /**
   * DELETE /api/facturas/{id}/definitiva: eliminacion fisica de la factura
   * y de sus detalles. Responde 204 No Content.
   */
  static eliminarFacturaDefinitivamente(id: number): Promise<void> {
    return http.delete(`${FACTURAS_URL}/${id}/definitiva`);
  }
}
