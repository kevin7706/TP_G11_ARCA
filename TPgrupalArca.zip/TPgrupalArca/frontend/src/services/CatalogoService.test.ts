import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { CatalogoService } from './CatalogoService';

const URL_BASE = 'http://localhost:8080';

function respuestaVacia(): Response {
  return {
    ok: true,
    status: 200,
    headers: new Headers({ 'content-type': 'application/json' }),
    text: async () => '[]',
  } as unknown as Response;
}

function urlPedida(): string {
  return String(vi.mocked(fetch).mock.calls[0][0]);
}

describe('CatalogoService', () => {
  beforeEach(() => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async () => respuestaVacia()),
    );
  });

  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it('guarda el tipo y numero de documento separados de la condicion IVA', async () => {
    const datos = {tipoDocumento: 96, numeroDocumento: '10000036', codigoCondicionIva: 5};
    vi.mocked(fetch).mockResolvedValueOnce(new Response(JSON.stringify({id: 36, denominacion: 'Persona de prueba', ...datos}), {status: 200}));
    const resultado = await CatalogoService.actualizarDatosFiscales(36, datos);
    expect(urlPedida()).toBe(`${URL_BASE}/api/catalogos/clientes/36/datos-fiscales`);
    const opciones = vi.mocked(fetch).mock.calls[0][1];
    expect(opciones?.method).toBe('PUT');
    expect(JSON.parse(String(opciones?.body))).toEqual(datos);
    expect(resultado.tipoDocumento).toBe(96);
  });

  it('trae todas las listas de precio', async () => {
    await CatalogoService.listarListasPrecio();

    expect(urlPedida()).toBe(`${URL_BASE}/api/catalogos/listas-precio`);
  });

  it('trae las listas de precio filtradas por texto', async () => {
    await CatalogoService.listarListasPrecio('general');

    expect(urlPedida()).toBe(`${URL_BASE}/api/catalogos/listas-precio?q=general`);
  });

  it('omite el filtro cuando el texto viene en blanco', async () => {
    await CatalogoService.listarListasPrecio('   ');

    expect(urlPedida()).toBe(`${URL_BASE}/api/catalogos/listas-precio`);
  });

  it('trae los clientes filtrados por texto', async () => {
    await CatalogoService.listarClientes('utn');

    expect(urlPedida()).toBe(`${URL_BASE}/api/catalogos/clientes?q=utn`);
  });

  it('trae los clientes sin filtro', async () => {
    await CatalogoService.listarClientes();

    expect(urlPedida()).toBe(`${URL_BASE}/api/catalogos/clientes`);
  });

  it('trae los articulos de una lista de precio con un texto', async () => {
    await CatalogoService.listarArticulos(7, 'teclado');

    expect(urlPedida()).toBe(
      `${URL_BASE}/api/catalogos/articulos?listaPrecioId=7&q=teclado`,
    );
  });

  it('trae los articulos de una lista de precio sin texto', async () => {
    await CatalogoService.listarArticulos(7);

    expect(urlPedida()).toBe(`${URL_BASE}/api/catalogos/articulos?listaPrecioId=7`);
  });

  it('trae los articulos de todas las listas de precio', async () => {
    await CatalogoService.listarArticulos();

    expect(urlPedida()).toBe(`${URL_BASE}/api/catalogos/articulos`);
  });
});
