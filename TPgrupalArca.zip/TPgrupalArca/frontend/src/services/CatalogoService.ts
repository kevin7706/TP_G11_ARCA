import type {
  ArticuloPrecio,
  Cliente,
  CondicionIva,
  ListaPrecio,
  PuntoVenta,
  TipoMoneda,
} from '../models/catalogo.dto';
import { http } from './http';

type Parametro = string | number | undefined | null;

/**
 * Arma el query string ignorando los parametros vacios: si el buscador viene
 * en blanco no tiene sentido mandar el parametro.
 */
function conQuery(path: string, parametros: Record<string, Parametro>): string {
  const query = new URLSearchParams();

  for (const [clave, valor] of Object.entries(parametros)) {
    if (valor === undefined || valor === null) {
      continue;
    }
    const texto = String(valor).trim();
    if (!texto) {
      continue;
    }
    query.set(clave, texto);
  }

  const queryString = query.toString();
  return queryString ? `${path}?${queryString}` : path;
}

export const CatalogoService = {
  actualizarDatosFiscales: (id: number, datos: {tipoDocumento: number; numeroDocumento: string; codigoCondicionIva: number}): Promise<Cliente> =>
    http.put<Cliente>(`/api/catalogos/clientes/${id}/datos-fiscales`, datos),
  listarListasPrecio: (q?: string): Promise<ListaPrecio[]> =>
    http.get<ListaPrecio[]>(conQuery('/api/catalogos/listas-precio', { q })),

  listarClientes: (q?: string): Promise<Cliente[]> =>
    http.get<Cliente[]>(conQuery('/api/catalogos/clientes', { q })),

  listarCondicionesIva: (): Promise<CondicionIva[]> =>
    http.get<CondicionIva[]>('/api/catalogos/condiciones-iva'),

  listarPuntosVenta: (): Promise<PuntoVenta[]> =>
    http.get<PuntoVenta[]>('/api/catalogos/puntos-venta'),

  listarTiposMoneda: (): Promise<TipoMoneda[]> =>
    http.get<TipoMoneda[]>('/api/catalogos/tipos-moneda'),

  /**
   * Articulos con su precio de venta. El precio pertenece a la lista precio
   * articulo, asi que {@code listaPrecioId} define de que lista se toma.
   */
  listarArticulos: (listaPrecioId?: number, q?: string): Promise<ArticuloPrecio[]> =>
    http.get<ArticuloPrecio[]>(
      conQuery('/api/catalogos/articulos', { listaPrecioId, q }),
    ),
};
