import type { ApiErrorResponse } from '../models/factura.dto';

export const API_BASE_URL = (
  (import.meta.env.VITE_API_BASE_URL as string | undefined) ?? 'http://localhost:8080'
).replace(/\/$/, '');

export class HttpError extends Error {
  constructor(
    public readonly status: number,
    message: string,
  ) {
    super(message);
    this.name = 'HttpError';
  }
}

async function parseError(response: Response): Promise<string> {
  const contentType = response.headers.get('content-type') ?? '';

  if (contentType.includes('json')) {
    try {
      const body: unknown = await response.json();
      if (body && typeof body === 'object') {
        const error = body as Partial<ApiErrorResponse> & {
          detail?: unknown;
          message?: unknown;
        };
        // Formato del backend: { status, mensaje, fecha }.
        if (typeof error.mensaje === 'string' && error.mensaje.trim()) {
          return error.mensaje;
        }
        const detail = error.detail;
        if (typeof detail === 'string' && detail.trim()) {
          return detail;
        }
        const message = error.message;
        if (typeof message === 'string' && message.trim()) {
          return message;
        }
      }
    } catch {
      return `Error HTTP ${response.status}`;
    }
  }

  try {
    const text = await response.text();
    if (text.trim()) {
      return text.trim();
    }
  } catch {
    // Sin cuerpo de respuesta.
  }

  return `Error HTTP ${response.status}`;
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const headers = new Headers(init?.headers);
  headers.set('Accept', 'application/json');
  if (init?.body !== undefined && !headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json');
  }

  let response: Response;
  try {
    const url = path.startsWith('http') ? path : `${API_BASE_URL}${path}`;
    response = await fetch(url, { ...init, headers });
  } catch (error) {
    // Fallo de red: la API no respondio.
    throw new HttpError(0, `No se pudo conectar con la API: ${(error as Error).message}`);
  }

  if (!response.ok) {
    throw new HttpError(response.status, await parseError(response));
  }

  if (response.status === 204) {
    return undefined as T;
  }

  const texto = await response.text();
  if (!texto.trim()) {
    return undefined as T;
  }

  return JSON.parse(texto) as T;
}

export const http = {
  get: <T>(path: string): Promise<T> => request<T>(path),
  post: <T>(path: string, body: unknown): Promise<T> =>
    request<T>(path, { method: 'POST', body: JSON.stringify(body) }),
  put: <T>(path: string, body: unknown): Promise<T> =>
    request<T>(path, { method: 'PUT', body: JSON.stringify(body) }),
  delete: (path: string): Promise<void> => request<void>(path, { method: 'DELETE' }),
};
