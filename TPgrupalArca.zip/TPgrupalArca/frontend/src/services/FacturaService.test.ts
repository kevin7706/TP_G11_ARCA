import { describe, it, expect, vi } from 'vitest';
import { FacturaService } from './FacturaService';

describe('FacturaService paginado', () => {
  it('envía los filtros incluyendo informada=false y la página pedida', async () => {
    const pagina = { contenido: [], pagina: 2, tamanio: 5, totalElementos: 11, totalPaginas: 3 };
    const fetchMock = vi.spyOn(globalThis, 'fetch').mockResolvedValue(new Response(JSON.stringify(pagina), {status: 200}));
    const resultado = await FacturaService.obtenerFacturas({informada: false, page: 2, size: 5, numero: 41, clienteId: 7});
    expect(resultado).toEqual(pagina);
    const url = new URL(String(fetchMock.mock.calls[0][0]));
    expect(Object.fromEntries(url.searchParams)).toMatchObject({informada: 'false', page: '2', size: '5', numero: '41', clienteId: '7'});
  });
  it('utiliza una acción separada para verificar un envío incierto', async () => {
    const fetchMock = vi.spyOn(globalThis, 'fetch').mockResolvedValue(new Response(null, {status: 204}));
    await FacturaService.verificarArca(7);
    expect(String(fetchMock.mock.calls[0][0])).toMatch(/\/7\/verificar-arca$/);
    expect(fetchMock.mock.calls[0][1]?.method).toBe('POST');
  });
});
