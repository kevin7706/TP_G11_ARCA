import { describe, expect, it } from 'vitest';
import {
  calcularLinea,
  calcularTotales,
  firmaDetalles,
  redondear,
  validarLinea,
  type LineaDetalle,
} from './importes';

function linea(overrides: Partial<LineaDetalle> = {}): LineaDetalle {
  return {
    key: 1,
    detalleId: null,
    listaPrecioArticuloId: null,
    articuloId: null,
    descripcion: '',
    cantidad: 1,
    precioUnitario: 0,
    porcentajeBonificacion: 0,
    porcentajeIva: 21,
    ...overrides,
  };
}

describe('redondear', () => {
  it('deja dos decimales', () => {
    expect(redondear(10.005)).toBe(10.01);
    expect(redondear(10.004)).toBe(10);
  });

  it('no rompe con valores no numericos', () => {
    expect(redondear(Number.NaN)).toBe(0);
  });
});

describe('calcularLinea', () => {
  it('calcula el neto, el iva y el subtotal sin bonificacion', () => {
    const importes = calcularLinea(
      linea({ cantidad: 2, precioUnitario: 1000, porcentajeBonificacion: 0, porcentajeIva: 21 }),
    );

    expect(importes).toEqual({ neto: 2000, iva: 420, subtotal: 2420 });
  });

  it('aplica la bonificacion sobre el neto antes del iva', () => {
    const importes = calcularLinea(
      linea({ cantidad: 2, precioUnitario: 1000, porcentajeBonificacion: 10, porcentajeIva: 21 }),
    );

    expect(importes.neto).toBe(1800);
    expect(importes.iva).toBe(378);
    expect(importes.subtotal).toBe(2178);
  });

  it('redondea a dos decimales', () => {
    const importes = calcularLinea(
      linea({ cantidad: 3, precioUnitario: 33.333, porcentajeBonificacion: 0, porcentajeIva: 21 }),
    );

    expect(importes.neto).toBe(100);
    expect(importes.iva).toBe(21);
    expect(importes.subtotal).toBe(121);
  });

  it('deja el iva en cero cuando la alicuota es cero', () => {
    const importes = calcularLinea(
      linea({ cantidad: 1, precioUnitario: 500, porcentajeBonificacion: 0, porcentajeIva: 0 }),
    );

    expect(importes).toEqual({ neto: 500, iva: 0, subtotal: 500 });
  });
});

describe('calcularTotales', () => {
  it('suma los importes de todas las lineas', () => {
    const totales = calcularTotales([
      linea({ key: 1, cantidad: 2, precioUnitario: 1000 }),
      linea({ key: 2, cantidad: 1, precioUnitario: 500 }),
    ]);

    expect(totales.neto).toBe(2500);
    expect(totales.iva).toBe(525);
    expect(totales.subtotal).toBe(3025);
  });

  it('devuelve cero cuando no hay lineas', () => {
    expect(calcularTotales([])).toEqual({ neto: 0, iva: 0, subtotal: 0 });
  });
});

describe('validarLinea', () => {
  it('acepta una linea completa', () => {
    expect(validarLinea(linea({ listaPrecioArticuloId: 7, cantidad: 1, precioUnitario: 100 }))).toBeNull();
  });

  it('pide un articulo seleccionado', () => {
    expect(validarLinea(linea({ listaPrecioArticuloId: null, cantidad: 1, precioUnitario: 100 }))).toBe(
      'falta el artículo',
    );
  });

  it('pide una cantidad mayor a cero', () => {
    expect(validarLinea(linea({ listaPrecioArticuloId: 7, cantidad: 0, precioUnitario: 100 }))).toBe(
      'la cantidad tiene que ser mayor a cero',
    );
  });

  it('pide un precio que no sea negativo', () => {
    expect(validarLinea(linea({ listaPrecioArticuloId: 7, cantidad: 1, precioUnitario: -1 }))).toBe(
      'el precio no puede ser negativo',
    );
  });
});

describe('firmaDetalles', () => {
  it('devuelve la misma firma si no cambian los renglones', () => {
    const lineas = [
      linea({ key: 1, listaPrecioArticuloId: 7, descripcion: 'Teclado', cantidad: 2, precioUnitario: 100 }),
      linea({ key: 2, listaPrecioArticuloId: 8, descripcion: 'Mouse', cantidad: 1, precioUnitario: 50 }),
    ];

    expect(firmaDetalles(lineas)).toBe(firmaDetalles([...lineas]));
  });

  it('cambia si cambia el articulo de un renglon', () => {
    const original = [linea({ key: 1, listaPrecioArticuloId: 7, cantidad: 2, precioUnitario: 100 })];
    const modificado = [linea({ key: 1, listaPrecioArticuloId: 9, cantidad: 2, precioUnitario: 100 })];

    expect(firmaDetalles(original)).not.toBe(firmaDetalles(modificado));
  });

  it('cambia si cambia la cantidad', () => {
    const original = [linea({ key: 1, listaPrecioArticuloId: 7, cantidad: 2 })];
    const modificado = [linea({ key: 1, listaPrecioArticuloId: 7, cantidad: 3 })];

    expect(firmaDetalles(original)).not.toBe(firmaDetalles(modificado));
  });

  it('no cambia si solo cambia la clave interna del renglon', () => {
    const original = [linea({ key: 1, listaPrecioArticuloId: 7 })];
    const modificado = [linea({ key: 42, listaPrecioArticuloId: 7 })];

    expect(firmaDetalles(original)).toBe(firmaDetalles(modificado));
  });
});
