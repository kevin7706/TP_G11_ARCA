/**
 * Espejo en TypeScript de los DTOs de Spring Boot.
 *
 * Los nombres de los campos y los tipos tienen que coincidir exactamente con
 * los DTOs Java:
 *  - `java.util.Date` con `@JsonFormat(pattern = "yyyy-MM-dd")` -> string
 *  - `double` / `Double` -> number
 *  - `Long` -> number
 *  - `String` -> string
 */

export type EstadoFactura = 'PENDIENTE' | 'AUTORIZADA' | 'RECHAZADA' | 'A_VERIFICAR' | 'ANULADA';

export interface FacturaReporteDTO {
  id: number;
  numeroFactura: number | null;
  cae?: string | null;
  caeFechaVencimiento?: string | null;
  motivoRechazo?: string | null;
  fechaEmision: string;
  clienteDenominacion: string;
  condicionIva: string;
  puntoVentaDescripcion: string;
  estado: string;
  importeTotal: number;
  cantidadItems: number;
}

export interface FacturaDetalleRequestDTO {
  /** Id del detalle ya persistido: permite actualizarlo sin recrearlo. */
  detalleId?: number;
  articuloId?: number;
  listaPrecioArticuloId?: number;
  descripcion?: string;
  cantidad: number;
  precioUnitario?: number;
  porcentajeBonificacion?: number;
  porcentajeIva?: number;
}

export interface FacturaRequestDTO {
  numero?: number;
  fechaEmision: string;
  clienteId?: number;
  consumidorFinal?: boolean;
  condicionIvaId: number;
  puntoVentaId: number;
  tipoMonedaId: number;
  estado?: string;
  observaciones?: string;
  detalles: FacturaDetalleRequestDTO[];
}

/**
 * Cuerpo parcial para cambiar el estado (y las observaciones) de una factura.
 * El backend solo toca los campos que llegan informados.
 */
export interface FacturaEstadoUpdateDTO {
  estado: string;
  observaciones?: string;
}

export type FacturaUpdateRequestDTO = Partial<Omit<FacturaRequestDTO, 'detalles'>> & {
  detalles?: FacturaDetalleRequestDTO[];
};

export interface FacturaDetalleEdicionDTO {
  id: number;
  articuloId: number;
  listaPrecioArticuloId: number;
  descripcion: string | null;
  cantidad: number;
  precioUnitario: number;
  porcentajeBonificacion: number;
  porcentajeIva: number;
}

export interface FacturaEdicionDTO {
  id: number;
  numero: number | null;
  fechaEmision: string;
  clienteId: number | null;
  condicionIvaId: number;
  puntoVentaId: number;
  tipoMonedaId: number;
  estado: string;
  observaciones: string | null;
  detalles: FacturaDetalleEdicionDTO[];
}

export interface FacturaPaginaDTO {
  contenido: FacturaReporteDTO[];
  pagina: number;
  tamanio: number;
  totalElementos: number;
  totalPaginas: number;
}
export interface FacturaFiltrosDTO {
  numero?: number;
  clienteId?: number;
  informada?: boolean;
  page?: number;
  size?: number;
  fechaDesde?: string;
  fechaHasta?: string;
  estado?: string;
  montoMinimo?: number;
}

/** Cuerpo de error que devuelve el GlobalExceptionHandler del backend. */
export interface ApiErrorResponse {
  status: number;
  mensaje: string;
  fecha: string;
}
