export interface Cliente {
  id: number;
  denominacion: string;
  cuitCuil: string | null;
  tipoDocumento?: number | null;
  numeroDocumento?: string | null;
  codigoCondicionIva?: number | null;
  datosEjemplo?: boolean | null;
}

export interface CondicionIva {
  codigoAfip?: number;
  id: number;
  denominacion: string;
}

export interface ListaPrecio {
  id: number;
  codigo: string;
  denominacion: string;
}

export interface PuntoVenta {
  id: number;
  numero: number;
  descripcion: string;
}

export interface TipoMoneda {
  id: number;
  denominacion: string;
  simbolo: string;
}

export interface ArticuloPrecio {
  listaPrecioArticuloId: number;
  articuloId: number;
  codigo: string;
  denominacion: string;
  precioVenta: number;
  listaPrecioId: number;
  listaPrecioDenominacion: string;
}
