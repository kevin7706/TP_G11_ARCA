import { beforeEach, describe, expect, it, vi } from 'vitest';
import {
  crearExplorador,
  type ExploradorElementos,
} from './explorador';

interface Cliente {
  id: number;
  denominacion: string;
  cuitCuil: string | null;
}

const MARCA_HTML = `
  <div class="modal" id="explorador" hidden>
    <div class="modal__backdrop" data-cerrar></div>
    <div class="modal__dialog" role="dialog" aria-modal="true" aria-labelledby="explorador-titulo">
      <header class="modal__header">
        <h2 id="explorador-titulo"></h2>
        <button type="button" class="btn-icon" data-cerrar aria-label="Cerrar">×</button>
      </header>
      <div class="modal__body">
        <form class="explorer-search" id="explorador-busqueda">
          <input class="input" id="explorador-texto" type="search" />
          <button type="submit" class="btn btn-primary">Buscar</button>
        </form>
        <div class="table-wrap">
          <table class="data-table">
            <thead>
              <tr id="explorador-encabezados"></tr>
            </thead>
            <tbody id="explorador-filas"></tbody>
          </table>
        </div>
      </div>
    </div>
  </div>`;

function montar(): ExploradorElementos {
  document.body.innerHTML = MARCA_HTML;
  return {
    modal: document.getElementById('explorador') as HTMLElement,
    titulo: document.getElementById('explorador-titulo') as HTMLElement,
    formulario: document.getElementById('explorador-busqueda') as HTMLFormElement,
    texto: document.getElementById('explorador-texto') as HTMLInputElement,
    encabezados: document.getElementById('explorador-encabezados') as HTMLTableRowElement,
    filas: document.getElementById('explorador-filas') as HTMLTableSectionElement,
  };
}

const CLIENTES: Cliente[] = [
  { id: 1, denominacion: 'Cliente UTN', cuitCuil: '20-12345678-9' },
  { id: 2, denominacion: 'Juan Carlos Perez', cuitCuil: '20-11223344-5' },
];

function configuracion(alElegir: (item: Cliente) => void, buscar = vi.fn(async () => CLIENTES)) {
  return {
    titulo: 'Buscar cliente',
    placeholder: 'Buscar por nombre o CUIT',
    columnas: [
      { etiqueta: 'Denominación', valor: (cliente: Cliente) => cliente.denominacion },
      { etiqueta: 'CUIT', valor: (cliente: Cliente) => cliente.cuitCuil ?? '' },
    ],
    buscar,
    alElegir,
  };
}

describe('explorador', () => {
  let elementos: ExploradorElementos;

  beforeEach(() => {
    elementos = montar();
  });

  it('abre el modal con el titulo y las columnas configuradas', async () => {
    const explorador = crearExplorador(elementos, configuracion(() => undefined));

    await explorador.abrir();

    expect(elementos.modal.hidden).toBe(false);
    expect(elementos.titulo.textContent).toBe('Buscar cliente');
    expect(elementos.encabezados.querySelectorAll('th')).toHaveLength(3);
    expect(elementos.encabezados.querySelectorAll('th')[0].textContent).toBe('Denominación');
  });

  it('lista un renglon por resultado con su boton de seleccionar', async () => {
    const explorador = crearExplorador(elementos, configuracion(() => undefined));

    await explorador.abrir();

    const renglones = elementos.filas.querySelectorAll('tr');
    expect(renglones).toHaveLength(2);
    expect(renglones[0].textContent).toContain('Cliente UTN');
    expect(renglones[0].querySelector('button[data-action="seleccionar"]')).not.toBeNull();
  });

  it('entrega el elemento elegido y cierra el modal', async () => {
    const alElegir = vi.fn();
    const explorador = crearExplorador(elementos, configuracion(alElegir));

    await explorador.abrir();
    const boton = elementos.filas.querySelectorAll(
      'button[data-action="seleccionar"]',
    )[1] as HTMLButtonElement;
    boton.click();

    expect(alElegir).toHaveBeenCalledTimes(1);
    expect(alElegir).toHaveBeenCalledWith(CLIENTES[1]);
    expect(elementos.modal.hidden).toBe(true);
  });

  it('busca con el texto que se escribe en el buscador', async () => {
    const buscar = vi.fn(async (texto: string) =>
      texto === 'UTN' ? [CLIENTES[0]] : CLIENTES,
    );
    const explorador = crearExplorador(elementos, configuracion(() => undefined, buscar));

    await explorador.abrir();
    elementos.texto.value = 'UTN';
    elementos.formulario.dispatchEvent(new Event('submit', { cancelable: true }));
    await Promise.resolve();
    await Promise.resolve();

    expect(buscar).toHaveBeenLastCalledWith('UTN');
    expect(elementos.filas.querySelectorAll('tr')).toHaveLength(1);
  });

  it('avisa cuando la busqueda no trae resultados', async () => {
    const buscar = vi.fn(async () => []);
    const explorador = crearExplorador(elementos, configuracion(() => undefined, buscar));

    await explorador.abrir();

    expect(elementos.filas.querySelectorAll('tr')).toHaveLength(1);
    expect(elementos.filas.textContent).toContain('No se encontraron resultados');
  });

  it('cierra el modal sin elegir nada', async () => {
    const alElegir = vi.fn();
    const explorador = crearExplorador(elementos, configuracion(alElegir));

    await explorador.abrir();
    explorador.cerrar();

    expect(elementos.modal.hidden).toBe(true);
    expect(alElegir).not.toHaveBeenCalled();
  });

  it('no elige nada cuando el buscador falla', async () => {
    const alElegir = vi.fn();
    const buscar = vi.fn(async () => {
      throw new Error('la API no responde');
    });
    const explorador = crearExplorador(elementos, configuracion(alElegir, buscar));

    await explorador.abrir();

    expect(elementos.modal.hidden).toBe(false);
    expect(elementos.filas.textContent).toContain('No se pudieron cargar los datos');
    expect(alElegir).not.toHaveBeenCalled();
  });

  it('solo atiende el buscador el explorador que esta abierto', async () => {
    const buscarPrimero = vi.fn(async () => CLIENTES);
    const buscarSegundo = vi.fn(async () => CLIENTES);
    const primero = crearExplorador(elementos, configuracion(() => undefined, buscarPrimero));
    const segundo = crearExplorador(elementos, configuracion(() => undefined, buscarSegundo));

    await primero.abrir();
    await segundo.abrir();

    elementos.texto.value = 'UTN';
    elementos.formulario.dispatchEvent(new Event('submit', { cancelable: true }));
    await Promise.resolve();
    await Promise.resolve();

    expect(buscarSegundo).toHaveBeenLastCalledWith('UTN');
    expect(buscarPrimero).not.toHaveBeenLastCalledWith('UTN');
  });
});
