/**
 * Explorador de datos: un modal con un buscador y una grilla de resultados.
 *
 * <p>Es generico a proposito: el mismo componente sirve para elegir cliente,
 * lista de precio y articulo. Lo unico que cambia es la configuracion
 * (columnas, como se busca y que se hace con el elemento elegido).
 */

/** Una columna de la grilla de resultados. */
export interface ExploradorColumna<T> {
  etiqueta: string;
  valor: (item: T) => string;
}

/** Configuracion de un explorador. */
export interface ExploradorConfig<T> {
  titulo: string;
  placeholder?: string;
  columnas: ExploradorColumna<T>[];
  /** Busca los elementos que coinciden con el texto escrito. */
  buscar: (texto: string) => Promise<T[]>;
  /** Se llama con el elemento que el usuario eligio. */
  alElegir: (item: T) => void;
}

/** Piezas del DOM que usa el explorador. */
export interface ExploradorElementos {
  modal: HTMLElement;
  titulo: HTMLElement;
  formulario: HTMLFormElement;
  texto: HTMLInputElement;
  encabezados: HTMLTableRowElement;
  filas: HTMLTableSectionElement;
}

/** Explorador listo para usar. */
export interface Explorador {
  /** Abre el modal y carga los resultados iniciales. */
  abrir(): Promise<void>;
  /** Cierra el modal. */
  cerrar(): void;
  /** Vuelve a buscar con el texto que esta escrito. */
  refrescar(): Promise<void>;
}

const SIN_RESULTADOS = 'No se encontraron resultados';
const SIN_DATOS = 'No se pudieron cargar los datos';

/**
 * Explorador que esta abierto. Como los exploradores comparten el mismo
 * modal, solo el activo atiende el formulario de busqueda.
 */
let exploradorActivo: { cerrar: () => void } | null = null;

/**
 * Crea un explorador sobre los elementos indicados.
 *
 * <p>Un explorador por tipo de dato, pero todos comparten el mismo modal: solo
 * hay uno abierto a la vez.
 */
export function crearExplorador<T>(
  elementos: ExploradorElementos,
  config: ExploradorConfig<T>,
): Explorador {
  function renderEncabezados(): void {
    const celdas = config.columnas.map((columna) => {
      const th = document.createElement('th');
      th.textContent = columna.etiqueta;
      return th;
    });

    const thAccion = document.createElement('th');
    thAccion.className = 'text-center';
    thAccion.textContent = 'Acción';
    celdas.push(thAccion);

    elementos.encabezados.replaceChildren(...celdas);
  }

  function renderFila(item: T): HTMLTableRowElement {
    const fila = document.createElement('tr');

    for (const columna of config.columnas) {
      const celda = document.createElement('td');
      celda.textContent = columna.valor(item);
      fila.append(celda);
    }

    const celdaAccion = document.createElement('td');
    celdaAccion.className = 'text-center';

    const boton = document.createElement('button');
    boton.type = 'button';
    boton.className = 'btn btn-small btn-primary';
    boton.dataset.action = 'seleccionar';
    boton.textContent = 'Seleccionar';
    boton.addEventListener('click', () => {
      config.alElegir(item);
      cerrar();
    });

    celdaAccion.append(boton);
    fila.append(celdaAccion);
    return fila;
  }

  function renderMensaje(mensaje: string): void {
    const fila = document.createElement('tr');
    const celda = document.createElement('td');
    celda.colSpan = config.columnas.length + 1;
    celda.className = 'empty-cell';
    celda.textContent = mensaje;
    fila.append(celda);
    elementos.filas.replaceChildren(fila);
  }

  function render(items: T[]): void {
    if (items.length === 0) {
      renderMensaje(SIN_RESULTADOS);
      return;
    }
    elementos.filas.replaceChildren(...items.map(renderFila));
  }

  /** Busca y dibuja. Si la API falla, avisa en la grilla en vez de romper. */
  function buscarYRender(texto: string): Promise<void> {
    return config.buscar(texto).then(
      (items) => {
        render(items);
      },
      () => {
        renderMensaje(SIN_DATOS);
      },
    );
  }

  function cerrar(): void {
    elementos.modal.hidden = true;
    elementos.modal.setAttribute('aria-hidden', 'true');
    if (exploradorActivo === api) {
      exploradorActivo = null;
    }
  }

  function abrir(): Promise<void> {
    if (exploradorActivo && exploradorActivo !== api) {
      exploradorActivo.cerrar();
    }
    exploradorActivo = api;

    elementos.titulo.textContent = config.titulo;
    elementos.texto.value = '';
    if (config.placeholder) {
      elementos.texto.placeholder = config.placeholder;
    }
    renderEncabezados();
    elementos.modal.hidden = false;
    elementos.modal.setAttribute('aria-hidden', 'false');
    elementos.texto.focus();
    return buscarYRender('');
  }

  elementos.formulario.addEventListener('submit', (event) => {
    if (exploradorActivo !== api) {
      return;
    }
    event.preventDefault();
    void buscarYRender(elementos.texto.value);
  });

  for (const boton of elementos.modal.querySelectorAll('[data-cerrar]')) {
    boton.addEventListener('click', () => {
      if (exploradorActivo === api) {
        cerrar();
      }
    });
  }

  elementos.modal.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && exploradorActivo === api) {
      cerrar();
    }
  });

  const api: Explorador = {
    abrir,
    cerrar,
    refrescar: () => buscarYRender(elementos.texto.value),
  };

  return api;
}
