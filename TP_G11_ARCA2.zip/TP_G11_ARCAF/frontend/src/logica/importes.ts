/**
 * Calculos de importes de los renglones de una factura.
 *
 * <p>La logica esta aparte del DOM para poder probarla sola: los tests de
 * {@link ../logica/importes.test.ts} no necesitan levantar la pagina.
 */

/** Un renglon de la factura que se esta cargando en el formulario. */
export interface LineaDetalle {
  /** Identificador interno del renglon en la pantalla (no va a la API). */
  key: number;
  detalleId: number | null;
  listaPrecioArticuloId: number | null;
  articuloId: number | null;
  descripcion: string;
  cantidad: number;
  precioUnitario: number;
  porcentajeBonificacion: number;
  porcentajeIva: number;
  /** Codigo y nombre del articulo elegido, para mostrarlo en el renglon. */
  articuloEtiqueta?: string;
  listaPrecioEtiqueta?: string;
}

/** Importes de un renglon: neto, IVA y subtotal. */
export interface ImportesLinea {
  neto: number;
  iva: number;
  subtotal: number;
}

/** Redondea a dos decimales. Los valores no numericos se tratan como cero. */
export function redondear(value: number): number {
  if (!Number.isFinite(value)) {
    return 0;
  }
  return Math.round((value + Number.EPSILON) * 100) / 100;
}

/**
 * Calcula los importes de un renglon.
 *
 * <p>La bonificacion se aplica sobre el bruto antes de calcular el IVA, y el
 * subtotal es el neto mas el IVA (neto mas IVA es el total de la linea).
 */
export function calcularLinea(linea: LineaDetalle): ImportesLinea {
  const neto = redondear(
    linea.cantidad * linea.precioUnitario * (1 - linea.porcentajeBonificacion / 100),
  );
  const iva = redondear((neto * linea.porcentajeIva) / 100);
  return { neto, iva, subtotal: redondear(neto + iva) };
}

/** Suma los importes de todos los renglones. */
export function calcularTotales(lineas: LineaDetalle[]): ImportesLinea {
  let neto = 0;
  let iva = 0;
  let subtotal = 0;

  for (const linea of lineas) {
    const importes = calcularLinea(linea);
    neto += importes.neto;
    iva += importes.iva;
    subtotal += importes.subtotal;
  }

  return { neto: redondear(neto), iva: redondear(iva), subtotal: redondear(subtotal) };
}

/**
 * Revisa un renglon. Devuelve el mensaje del problema o {@code null} cuando
 * el renglon esta completo.
 */
export function validarLinea(linea: LineaDetalle): string | null {
  if (!linea.listaPrecioArticuloId) {
    return 'falta el artículo';
  }
  if (!Number.isFinite(linea.cantidad) || linea.cantidad <= 0) {
    return 'la cantidad tiene que ser mayor a cero';
  }
  if (!Number.isFinite(linea.precioUnitario) || linea.precioUnitario < 0) {
    return 'el precio no puede ser negativo';
  }
  return null;
}

/**
 * Firma de los renglones cargados en el formulario. Sirve para detectar si el
 * usuario toco los items de la factura que esta siendo editada: si no los toco
 * y solo cambio el estado, alcanza con la actualizacion de estado.
 */
export function firmaDetalles(lineas: LineaDetalle[]): string {
  return lineas
    .map((linea) =>
      [
        linea.detalleId ?? '',
        linea.listaPrecioArticuloId ?? '',
        linea.articuloId ?? '',
        linea.descripcion.trim(),
        linea.cantidad,
        linea.precioUnitario,
        linea.porcentajeBonificacion,
        linea.porcentajeIva,
      ].join('|'),
    )
    .join(';');
}
