package com.utn.tpgrupal.service;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.utn.tpgrupal.dto.FacturaDetalleEdicionDTO;
import com.utn.tpgrupal.dto.FacturaDetalleRequestDTO;
import com.utn.tpgrupal.dto.FacturaEdicionDTO;
import com.utn.tpgrupal.dto.FacturaReporteDTO;
import com.utn.tpgrupal.dto.FacturaRequestDTO;
import com.utn.tpgrupal.entities.Cliente;
import com.utn.tpgrupal.entities.CondicionIva;
import com.utn.tpgrupal.entities.FacturaVenta;
import com.utn.tpgrupal.entities.FacturaVentaDetalle;
import com.utn.tpgrupal.entities.ListaPrecioArticulo;
import com.utn.tpgrupal.entities.PuntoVenta;
import com.utn.tpgrupal.entities.TipoMoneda;
import com.utn.tpgrupal.entities.Usuario;
import com.utn.tpgrupal.exception.DatosInvalidosException;
import com.utn.tpgrupal.exception.RecursoNoEncontradoException;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class FacturaService {

    /**
     * Alícuota de IVA por defecto. El modelo de datos no guarda la alícuota
     * por artículo, así que se usa 21% cuando el cliente no la informa.
     */
    public static final double PORCENTAJE_IVA_DEFAULT = 21.0;

    private static final String ESTADO_EMITIDA = "EMITIDA";
    private static final String ESTADO_ANULADA = "ANULADA";
    private static final int ESCALA_IMPORTE = 2;

    /** Encabezados del reporte de Excel, en el orden de las columnas. */
    private static final String[] ENCABEZADOS_REPORTE = {
        "Numero", "Fecha", "Cliente", "Condicion IVA", "Punto de venta", "Estado",
        "Total", "Cantidad de items"
    };

    /** Anchos de respaldo, en caracteres, cuando el autoajuste no esta disponible. */
    private static final int[] ANCHOS_COLUMNAS = {10, 14, 34, 24, 20, 12, 16, 20};

    private final EntityManager entityManager;

    public FacturaService(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Transactional(readOnly = true)
    public List<FacturaReporteDTO> buscarFacturasFiltradas(
            Date fechaDesde, Date fechaHasta, String estado, Double montoMinimo) {
        Date desde = normalizarADiaLocal(fechaDesde);
        Date hasta = normalizarADiaLocal(fechaHasta);

        StringBuilder jpql = new StringBuilder("""
                SELECT new com.utn.tpgrupal.dto.FacturaReporteDTO(
                    f.id, f.numero, f.fechaEmision, COALESCE(c.denominacion, 'Consumidor Final'),
                    ci.denominacion, pv.descripcion, f.estado, f.importeTotal, COUNT(d)
                )
                FROM FacturaVenta f
                LEFT JOIN f.cliente c
                JOIN f.condicionIva ci
                JOIN f.puntoVenta pv
                LEFT JOIN f.detalles d
                WHERE 1 = 1
                """);
        Map<String, Object> parametros = new HashMap<>();

        if (desde != null) {
            jpql.append(" AND f.fechaEmision >= :fechaDesde");
            parametros.put("fechaDesde", desde);
        }
        if (hasta != null) {
            jpql.append(" AND f.fechaEmision <= :fechaHasta");
            parametros.put("fechaHasta", hasta);
        }
        if (estado != null && !estado.isBlank()) {
            jpql.append(" AND f.estado = :estado");
            parametros.put("estado", estado);
        }
        if (montoMinimo != null) {
            jpql.append(" AND f.importeTotal >= :montoMinimo");
            parametros.put("montoMinimo", montoMinimo);
        }

        jpql.append(" GROUP BY f.id, f.numero, f.fechaEmision, c.denominacion, "
                + "ci.denominacion, pv.descripcion, f.estado, f.importeTotal ORDER BY f.fechaEmision");

        TypedQuery<FacturaReporteDTO> query = entityManager.createQuery(
                jpql.toString(), FacturaReporteDTO.class);
        parametros.forEach(query::setParameter);
        return query.getResultList();
    }

    @Transactional(readOnly = true)
    public com.utn.tpgrupal.dto.FacturaPaginaDTO buscarPagina(
            Date desde, Date hasta, String estado, Double monto, Long numero, Long clienteId,
            Boolean informada, int page, int size) {
        if (page < 0 || size < 1 || size > 100 || page > Integer.MAX_VALUE / size) {
            throw new DatosInvalidosException("Pagina invalida; el tamaño debe estar entre 1 y 100");
        }
        if (desde != null && hasta != null && desde.after(hasta)) {
            throw new DatosInvalidosException("La fecha desde no puede ser posterior a hasta");
        }
        StringBuilder where = new StringBuilder(" WHERE f.fechaBaja IS NULL");
        Map<String, Object> params = new HashMap<>();
        if (desde != null) { where.append(" AND f.fechaEmision >= :desde"); params.put("desde", normalizarADiaLocal(desde)); }
        if (hasta != null) { where.append(" AND f.fechaEmision <= :hasta"); params.put("hasta", normalizarADiaLocal(hasta)); }
        if (estado != null && !estado.isBlank()) { where.append(" AND f.estado = :estado"); params.put("estado", estado); }
        if (monto != null) { where.append(" AND f.importeTotal >= :monto"); params.put("monto", monto); }
        if (numero != null) { where.append(" AND f.numero = :numero"); params.put("numero", numero); }
        if (clienteId != null) { where.append(" AND f.cliente.id = :cliente"); params.put("cliente", clienteId); }
        if (informada != null) { where.append(informada ? " AND f.cae IS NOT NULL AND f.cae <> ''" : " AND (f.cae IS NULL OR f.cae = '')"); }
        TypedQuery<Long> count = entityManager.createQuery("SELECT COUNT(f) FROM FacturaVenta f" + where, Long.class);
        params.forEach(count::setParameter);
        long total = count.getSingleResult();
        TypedQuery<FacturaVenta> query = entityManager.createQuery("SELECT f FROM FacturaVenta f" + where + " ORDER BY f.fechaEmision DESC, f.id DESC", FacturaVenta.class);
        params.forEach(query::setParameter);
        List<FacturaReporteDTO> contenido = query.setFirstResult(page * size).setMaxResults(size)
                .getResultList().stream().map(this::construirReporte).toList();
        return new com.utn.tpgrupal.dto.FacturaPaginaDTO(contenido, page, size, total, (int) Math.ceil((double) total / size));
    }

    @Transactional(readOnly = true)
    public FacturaEdicionDTO obtener(Long id) {
        FacturaVenta factura = buscarFactura(id);
        List<FacturaDetalleEdicionDTO> detalles = (factura.getDetalles() == null
                ? List.<FacturaVentaDetalle>of()
                : factura.getDetalles()).stream()
                .map(detalle -> new FacturaDetalleEdicionDTO(
                        detalle.getId(),
                        detalle.getListaPrecioArticulo().getArticulo().getId(),
                        detalle.getListaPrecioArticulo().getId(),
                        detalle.getDescripcion(),
                        detalle.getCantidad(),
                        detalle.getPrecioUnitario(),
                        detalle.getPorcentajeBonificacion(),
                        derivarPorcentajeIva(detalle)))
                .toList();

        return new FacturaEdicionDTO(
                factura.getId(),
                factura.getNumero(),
                factura.getFechaEmision(),
                factura.getCliente() == null ? null : factura.getCliente().getId(),
                factura.getCondicionIva().getId(),
                factura.getPuntoVenta().getId(),
                factura.getTipoMoneda().getId(),
                factura.getEstado(),
                factura.getObservaciones(),
                detalles);
    }

    private List<FacturaReporteDTO> todasFiltradas(Date desde, Date hasta, String estado, Double monto,
            Long numero, Long clienteId, Boolean informada) {
        List<FacturaReporteDTO> todas = new ArrayList<>();
        int pagina = 0;
        com.utn.tpgrupal.dto.FacturaPaginaDTO resultado;
        do {
            resultado = buscarPagina(desde, hasta, estado, monto, numero, clienteId, informada, pagina++, 100);
            todas.addAll(resultado.contenido());
        } while (pagina < resultado.totalPaginas());
        return todas;
    }

    @Transactional(readOnly = true)
    public byte[] generarReporteExcel(Date desde, Date hasta, String estado, Double monto, Long numero, Long clienteId, Boolean informada) {
        return excel(todasFiltradas(desde, hasta, estado, monto, numero, clienteId, informada));
    }
    @Transactional(readOnly = true)
    public byte[] generarReportePdf(Date desde, Date hasta, String estado, Double monto, Long numero, Long clienteId, Boolean informada) {
        return pdf(todasFiltradas(desde, hasta, estado, monto, numero, clienteId, informada));
    }

    @Transactional(readOnly = true)
    public byte[] generarReporteExcel(Date fechaDesde, Date fechaHasta, String estado, Double montoMinimo) {
        return excel(buscarFacturasFiltradas(fechaDesde, fechaHasta, estado, montoMinimo));
    }
    private byte[] excel(List<FacturaReporteDTO> facturas) {
        try (Workbook libro = new XSSFWorkbook(); ByteArrayOutputStream salida = new ByteArrayOutputStream()) {
            Sheet hoja = libro.createSheet("Facturas");

            CellStyle estiloEncabezado = libro.createCellStyle();
            Font fuenteEncabezado = libro.createFont();
            fuenteEncabezado.setBold(true);
            estiloEncabezado.setFont(fuenteEncabezado);

            CellStyle estiloFecha = libro.createCellStyle();
            estiloFecha.setDataFormat(libro.createDataFormat().getFormat("dd/mm/yyyy"));

            Row encabezado = hoja.createRow(0);
            for (int columna = 0; columna < ENCABEZADOS_REPORTE.length; columna++) {
                Cell celda = encabezado.createCell(columna);
                celda.setCellValue(ENCABEZADOS_REPORTE[columna]);
                celda.setCellStyle(estiloEncabezado);
            }

            int fila = 1;
            for (FacturaReporteDTO factura : facturas) {
                Row renglon = hoja.createRow(fila++);
                if (factura.getNumeroFactura() == null) renglon.createCell(0).setCellValue("Pendiente");
                else renglon.createCell(0).setCellValue(factura.getNumeroFactura().doubleValue());

                Cell celdaFecha = renglon.createCell(1);
                celdaFecha.setCellValue(factura.getFechaEmision());
                celdaFecha.setCellStyle(estiloFecha);

                renglon.createCell(2).setCellValue(factura.getClienteDenominacion());
                renglon.createCell(3).setCellValue(factura.getCondicionIva());
                renglon.createCell(4).setCellValue(factura.getPuntoVentaDescripcion());
                renglon.createCell(5).setCellValue(factura.getEstado());
                renglon.createCell(6).setCellValue(factura.getImporteTotal());
                renglon.createCell(7).setCellValue(factura.getCantidadItems());
            }

            hoja.createFreezePane(0, 1);
            hoja.setAutoFilter(new CellRangeAddress(
                    0, Math.max(fila - 1, 0), 0, ENCABEZADOS_REPORTE.length - 1));
            ajustarColumnas(hoja);

            libro.write(salida);
            return salida.toByteArray();
        } catch (IOException e) {
            throw new RuntimeException("Error al generar el Excel", e);
        }
    }

    /**
     * Ajusta el ancho de las columnas. El autoajuste de POI necesita las
     * fuentes del sistema: si no estan disponibles se usan anchos fijos.
     */
    private void ajustarColumnas(Sheet hoja) {
        try {
            for (int columna = 0; columna < ENCABEZADOS_REPORTE.length; columna++) {
                hoja.autoSizeColumn(columna);
            }
        } catch (Exception | InternalError e) {
            for (int columna = 0; columna < ANCHOS_COLUMNAS.length; columna++) {
                hoja.setColumnWidth(columna, ANCHOS_COLUMNAS[columna] * 256);
            }
        }
    }

    @Transactional(readOnly = true)
    public byte[] generarReportePdf(Date fechaDesde, Date fechaHasta, String estado, Double montoMinimo) {
        return pdf(buscarFacturasFiltradas(fechaDesde, fechaHasta, estado, montoMinimo));
    }
    private byte[] pdf(List<FacturaReporteDTO> facturas) {
        try (ByteArrayOutputStream salida = new ByteArrayOutputStream()) {
            Document documento = new Document();
            PdfWriter.getInstance(documento, salida);
            documento.open();
            documento.add(new Paragraph("Reporte de facturas"));
            PdfPTable tabla = new PdfPTable(8);
            for (String encabezado : new String[]{"Numero", "Fecha", "Cliente", "IVA", "Punto de venta", "Estado", "Total", "Items"}) {
                tabla.addCell(encabezado);
            }
            for (FacturaReporteDTO factura : facturas) {
                tabla.addCell(factura.getNumeroFactura() == null ? "Pendiente" : String.valueOf(factura.getNumeroFactura()));
                tabla.addCell(formatearFecha(factura.getFechaEmision()));
                tabla.addCell(factura.getClienteDenominacion());
                tabla.addCell(factura.getCondicionIva());
                tabla.addCell(factura.getPuntoVentaDescripcion());
                tabla.addCell(factura.getEstado());
                tabla.addCell(String.valueOf(factura.getImporteTotal()));
                tabla.addCell(String.valueOf(factura.getCantidadItems()));
            }
            documento.add(tabla);
            documento.close();
            return salida.toByteArray();
        } catch (DocumentException e) {
            throw new RuntimeException("Error al generar el PDF", e);
        } catch (Exception e) {
            throw new RuntimeException("Error inesperado al generar el PDF", e);
        }
    }

    // ------------------------------------------------------------------
    // Operaciones de escritura
    // ------------------------------------------------------------------

    /**
     * Alta de factura: busca las entidades relacionadas por id, mapea los
     * renglones, calcula los importes y persiste la cabecera con sus detalles
     * en cascada. Si algo falla, la transaccion se revierte completa.
     */
    @Transactional
    public FacturaReporteDTO crear(FacturaRequestDTO dto) {
        validarCreacion(dto);

        PuntoVenta puntoVenta = buscarObligatorio(PuntoVenta.class, dto.getPuntoVentaId(), "Punto de venta");
        CondicionIva condicionIva = buscarObligatorio(CondicionIva.class, dto.getCondicionIvaId(), "Condicion IVA");
        TipoMoneda tipoMoneda = buscarObligatorio(TipoMoneda.class, dto.getTipoMonedaId(), "Tipo de moneda");
        Cliente cliente = Boolean.TRUE.equals(dto.getConsumidorFinal()) || dto.getClienteId() == null
                ? null : buscarObligatorio(Cliente.class, dto.getClienteId(), "Cliente");
        Usuario usuario = obtenerUsuarioAuditoria();

        FacturaVenta factura = new FacturaVenta();
        if (dto.getNumero() == null) {
            factura.setNumero(null);
        } else {
            throw new DatosInvalidosException("El numero fiscal se asigna al autorizar en ARCA");
        }
        factura.setFechaEmision(dto.getFechaEmision());
        factura.setPuntoVenta(puntoVenta);
        factura.setCliente(cliente);
        factura.setCondicionIva(condicionIva);
        factura.setTipoMoneda(tipoMoneda);
        factura.setObservaciones(dto.getObservaciones());

        String estado = dto.getEstado() == null || dto.getEstado().isBlank()
                ? "PENDIENTE" : dto.getEstado().trim();
        if (!"PENDIENTE".equals(estado)) {
            throw new DatosInvalidosException("Una factura nueva debe estar PENDIENTE");
        }
        factura.setEstado(estado);
        if (ESTADO_ANULADA.equalsIgnoreCase(estado)) {
            factura.setFechaAnulacion(new Date());
        }

        auditarAlta(factura, usuario);

        List<FacturaVentaDetalle> detalles = new ArrayList<>();
        for (FacturaDetalleRequestDTO detalleDto : dto.getDetalles()) {
            detalles.add(crearDetalle(factura, detalleDto));
        }
        factura.setDetalles(detalles);
        factura.setImporteTotal(calcularTotal(detalles));
        factura.setImporteCobrado(factura.getImporteTotal());
        factura.setImporteSaldo(0);

        entityManager.persist(factura);
        entityManager.flush();

        return construirReporte(factura);
    }

    /**
     * Actualizacion de factura.
     *
     * <p>El cuerpo es una actualizacion parcial controlada: los campos que
     * llegan en null no se tocan. Si viene la lista de detalles, se reconcilia
     * con la existente: los renglones que traen {@code detalleId} se modifican
     * en el lugar (conservan su id y su relacion), los nuevos se agrega y los
     * que no llegan se eliminan. Asi no se pierde la identidad de los items.
     */
    @Transactional
    public FacturaReporteDTO actualizar(Long id, FacturaRequestDTO dto) {
        if (dto == null) {
            throw new DatosInvalidosException("Los datos de la factura son obligatorios");
        }

        FacturaVenta factura = buscarFactura(id);
        validarEscritura(factura);
        if (dto.getNumero() != null) {
            throw new DatosInvalidosException("El numero fiscal no es editable");
        }
        if (dto.getEstado() != null && !List.of("PENDIENTE", "ANULADA").contains(dto.getEstado())) {
            throw new DatosInvalidosException("El estado fiscal solo puede cambiar mediante ARCA");
        }
        Usuario usuario = obtenerUsuarioAuditoria();

        boolean facturaAnulada = ESTADO_ANULADA.equalsIgnoreCase(factura.getEstado());
        String estadoSolicitado = dto.getEstado() == null || dto.getEstado().isBlank()
                ? null : dto.getEstado().trim();
        boolean cabeceraModificada = isCabeceraModificada(dto);
        boolean detallesModificados = dto.getDetalles() != null;

        if (facturaAnulada) {
            // Una factura anulada es un comprobante cerrado: no admite cambios.
            // Solo se acepta reiterar la anulacion (operacion idempotente).
            boolean cambiaEstado = estadoSolicitado != null
                    && !ESTADO_ANULADA.equalsIgnoreCase(estadoSolicitado);
            boolean cambiaObservaciones = dto.getObservaciones() != null
                    && !dto.getObservaciones().equals(factura.getObservaciones());
            if (cambiaEstado || cambiaObservaciones || cabeceraModificada || detallesModificados) {
                throw new DatosInvalidosException(
                        "La factura " + factura.getNumero() + " esta anulada y no admite modificaciones");
            }
        }

        if (!facturaAnulada) {
            if (dto.getNumero() != null && !dto.getNumero().equals(factura.getNumero())) {
                validarNumeroUnico(dto.getNumero(), factura.getId());
                factura.setNumero(dto.getNumero());
            }
            if (dto.getFechaEmision() != null) {
                factura.setFechaEmision(dto.getFechaEmision());
            }
            if (Boolean.TRUE.equals(dto.getConsumidorFinal())) {
                factura.setCliente(null);
            } else if (dto.getClienteId() != null) {
                factura.setCliente(buscarObligatorio(Cliente.class, dto.getClienteId(), "Cliente"));
            }
            if (dto.getCondicionIvaId() != null) {
                factura.setCondicionIva(buscarObligatorio(CondicionIva.class, dto.getCondicionIvaId(), "Condicion IVA"));
            }
            if (dto.getPuntoVentaId() != null) {
                factura.setPuntoVenta(buscarObligatorio(PuntoVenta.class, dto.getPuntoVentaId(), "Punto de venta"));
            }
            if (dto.getTipoMonedaId() != null) {
                factura.setTipoMoneda(buscarObligatorio(TipoMoneda.class, dto.getTipoMonedaId(), "Tipo de moneda"));
            }
        }

        if (dto.getObservaciones() != null) {
            factura.setObservaciones(dto.getObservaciones());
        }

        if (detallesModificados) {
            if (dto.getDetalles().isEmpty()) {
                throw new DatosInvalidosException("La factura debe tener al menos un detalle");
            }
            reconciliarDetalles(factura, dto.getDetalles());
            factura.setImporteTotal(calcularTotal(factura.getDetalles()));
            factura.setImporteCobrado(factura.getImporteTotal());
            factura.setImporteSaldo(0);
        }

        if (estadoSolicitado != null && !facturaAnulada) {
            factura.setEstado(estadoSolicitado);
            if (ESTADO_ANULADA.equalsIgnoreCase(estadoSolicitado) && factura.getFechaAnulacion() == null) {
                factura.setFechaAnulacion(new Date());
            }
        }

        factura.setFechaModificacion(new Date());
        factura.setUsuarioModificacion(usuario);
        entityManager.flush();

        return construirReporte(factura);
    }

    /**
     * Anulacion local: cambia el estado a ANULADA y registra la fecha. La
     * factura, sus detalles y el CAE se conservan. No revoca el comprobante
     * autorizado en ARCA. Los envios de resultado incierto deben verificarse
     * antes de poder anularse.
     */
    @Transactional
    public void eliminar(Long id) {
        FacturaVenta factura = buscarFactura(id);
        if (List.of("ENVIANDO", "A_VERIFICAR").contains(factura.getEstado())) {
            throw new DatosInvalidosException(
                    "La factura tiene un envio pendiente de verificar en ARCA; verifiquela antes de anularla");
        }

        if (ESTADO_ANULADA.equalsIgnoreCase(factura.getEstado())) {
            throw new DatosInvalidosException(
                    "La factura " + factura.getNumero() + " ya se encuentra anulada");
        }

        factura.setEstado(ESTADO_ANULADA);
        factura.setFechaAnulacion(new Date());
        factura.setFechaModificacion(new Date());
        factura.setUsuarioModificacion(obtenerUsuarioAuditoria());
        entityManager.flush();
    }

    /**
     * Eliminacion fisica de la factura. Los detalles se borran en cascada
     * (cascade = CascadeType.ALL + orphanRemoval = true en la cabecera).
     */
    @Transactional
    public void eliminarFisicamente(Long id) {
        FacturaVenta factura = buscarFactura(id);
        validarEscritura(factura);
        entityManager.remove(factura);
        entityManager.flush();
    }

    // ------------------------------------------------------------------
    // Validaciones
    // ------------------------------------------------------------------

    private void validarCreacion(FacturaRequestDTO dto) {
        if (dto == null) {
            throw new DatosInvalidosException("Los datos de la factura son obligatorios");
        }
        if (dto.getFechaEmision() == null) {
            throw new DatosInvalidosException("La fecha de emision es obligatoria");
        }
        if (dto.getCondicionIvaId() == null) {
            throw new DatosInvalidosException("La condicion IVA es obligatoria");
        }
        if (dto.getPuntoVentaId() == null) {
            throw new DatosInvalidosException("El punto de venta es obligatorio");
        }
        if (dto.getTipoMonedaId() == null) {
            throw new DatosInvalidosException("El tipo de moneda es obligatorio");
        }
        if (dto.getDetalles() == null || dto.getDetalles().isEmpty()) {
            throw new DatosInvalidosException("La factura debe tener al menos un detalle");
        }
    }

    private void validarDetalle(FacturaDetalleRequestDTO dto) {
        if (dto == null) {
            throw new DatosInvalidosException("El detalle no puede ser nulo");
        }
        if (dto.getCantidad() == null || !Double.isFinite(dto.getCantidad()) || dto.getCantidad() <= 0) {
            throw new DatosInvalidosException("La cantidad debe ser mayor a cero");
        }
        if (dto.getPrecioUnitario() != null && (!Double.isFinite(dto.getPrecioUnitario()) || dto.getPrecioUnitario() < 0)) {
            throw new DatosInvalidosException("El precio unitario no puede ser negativo");
        }
        if (dto.getPorcentajeBonificacion() != null
                && (!Double.isFinite(dto.getPorcentajeBonificacion()) || dto.getPorcentajeBonificacion() < 0 || dto.getPorcentajeBonificacion() > 100)) {
            throw new DatosInvalidosException("El porcentaje de bonificacion debe estar entre 0 y 100");
        }
        if (dto.getPorcentajeIva() != null
                && (!Double.isFinite(dto.getPorcentajeIva()) || dto.getPorcentajeIva() < 0 || dto.getPorcentajeIva() > 100)) {
            throw new DatosInvalidosException("El porcentaje de IVA debe estar entre 0 y 100");
        }
        if (dto.getArticuloId() == null && dto.getListaPrecioArticuloId() == null) {
            throw new DatosInvalidosException("Cada detalle debe indicar articuloId o listaPrecioArticuloId");
        }
    }

    private boolean isCabeceraModificada(FacturaRequestDTO dto) {
        return dto.getNumero() != null
                || dto.getFechaEmision() != null
                || dto.getClienteId() != null
                || Boolean.TRUE.equals(dto.getConsumidorFinal())
                || dto.getCondicionIvaId() != null
                || dto.getPuntoVentaId() != null
                || dto.getTipoMonedaId() != null;
    }

    // ------------------------------------------------------------------
    // Mapeo de renglones y calculo de importes
    // ------------------------------------------------------------------

    private FacturaVentaDetalle crearDetalle(FacturaVenta factura, FacturaDetalleRequestDTO dto) {
        validarDetalle(dto);
        FacturaVentaDetalle detalle = new FacturaVentaDetalle();
        detalle.setFactura(factura);
        aplicarDatosDetalle(detalle, dto);
        return detalle;
    }

    /**
     * Sincroniza los renglones existentes con los que llegan en la peticion.
     *
     * <p>Un renglon con {@code detalleId} conocido se actualiza en el lugar
     * para conservar su identidad. Los renglones que no llegan se quitan de la
     * coleccion y, por {@code orphanRemoval}, se borran de la base.
     */
    private void reconciliarDetalles(FacturaVenta factura, List<FacturaDetalleRequestDTO> dtos) {
        List<FacturaVentaDetalle> coleccion = factura.getDetalles();
        if (coleccion == null) {
            coleccion = new ArrayList<>();
            factura.setDetalles(coleccion);
        }

        Map<Long, FacturaVentaDetalle> actualesPorId = new LinkedHashMap<>();
        for (FacturaVentaDetalle actual : coleccion) {
            actualesPorId.put(actual.getId(), actual);
        }

        Map<Long, FacturaVentaDetalle> resultadoPorId = new LinkedHashMap<>();
        List<FacturaVentaDetalle> nuevos = new ArrayList<>();

        for (FacturaDetalleRequestDTO dto : dtos) {
            validarDetalle(dto);
            FacturaVentaDetalle detalle = null;

            if (dto.getDetalleId() != null) {
                detalle = actualesPorId.get(dto.getDetalleId());
                if (detalle == null) {
                    throw new DatosInvalidosException(
                            "El detalle con id " + dto.getDetalleId() + " no pertenece a la factura");
                }
                if (resultadoPorId.containsKey(detalle.getId())) {
                    throw new DatosInvalidosException(
                            "El detalle con id " + dto.getDetalleId() + " fue enviado mas de una vez");
                }
                resultadoPorId.put(detalle.getId(), detalle);
            } else {
                detalle = new FacturaVentaDetalle();
                detalle.setFactura(factura);
                nuevos.add(detalle);
            }

            aplicarDatosDetalle(detalle, dto);
        }

        // Los renglones que no llegaron se retiran de la coleccion: el
        // orphanRemoval de la cabecera se encarga de borrarlos.
        for (FacturaVentaDetalle actual : new ArrayList<>(coleccion)) {
            if (!resultadoPorId.containsKey(actual.getId())) {
                coleccion.remove(actual);
            }
        }

        if (!nuevos.isEmpty()) {
            coleccion.addAll(nuevos);
        }
    }

    /**
     * Copia los datos del renglon recibido y recalcula sus importes.
     *
     * <p>El precio unitario, los importes netos, el IVA y el subtotal los
     * calcula el servidor: el cliente solo puede informar el precio de venta
     * cuando conoce uno distinto al de la lista de precios.
     */
    private void aplicarDatosDetalle(FacturaVentaDetalle detalle, FacturaDetalleRequestDTO dto) {
        ListaPrecioArticulo listaPrecioArticulo = resolverListaPrecioArticulo(dto);

        detalle.setListaPrecioArticulo(listaPrecioArticulo);
        detalle.setDescripcion(dto.getDescripcion() == null || dto.getDescripcion().isBlank()
                ? listaPrecioArticulo.getArticulo().getDenominacion()
                : dto.getDescripcion().trim());
        detalle.setCantidad(dto.getCantidad());

        double precioUnitario = dto.getPrecioUnitario() != null
                ? dto.getPrecioUnitario() : listaPrecioArticulo.getPrecioVenta();
        detalle.setPrecioUnitario(precioUnitario);

        double porcentajeBonificacion = dto.getPorcentajeBonificacion() != null
                ? dto.getPorcentajeBonificacion() : 0.0;
        detalle.setPorcentajeBonificacion(porcentajeBonificacion);

        // Si el cliente no manda la alicuota, se conserva la efectiva del
        // renglon ya persistido (o el valor por defecto en un renglon nuevo).
        double porcentajeIva = dto.getPorcentajeIva() != null
                ? dto.getPorcentajeIva()
                : (detalle.getId() == null ? PORCENTAJE_IVA_DEFAULT : derivarPorcentajeIva(detalle));

        double importeNeto = calcularImporteNeto(dto.getCantidad(), precioUnitario, porcentajeBonificacion);
        double importeIva = calcularImporteIva(importeNeto, porcentajeIva);
        double importeSubtotal = redondear(importeNeto + importeIva);

        detalle.setPorcentajeIva(porcentajeIva);
        detalle.setImporteNeto(importeNeto);
        detalle.setImporteIva(importeIva);
        detalle.setImporteSubtotal(importeSubtotal);
    }

    private ListaPrecioArticulo resolverListaPrecioArticulo(FacturaDetalleRequestDTO dto) {
        if (dto.getListaPrecioArticuloId() != null) {
            ListaPrecioArticulo listaPrecioArticulo = entityManager.find(
                    ListaPrecioArticulo.class, dto.getListaPrecioArticuloId());
            if (listaPrecioArticulo == null) {
                throw new RecursoNoEncontradoException(
                        "Lista de precio de articulo no encontrada con id " + dto.getListaPrecioArticuloId());
            }
            if (dto.getArticuloId() != null
                    && !listaPrecioArticulo.getArticulo().getId().equals(dto.getArticuloId())) {
                throw new DatosInvalidosException(
                        "El articulo indicado no coincide con la lista de precio seleccionada");
            }
            return listaPrecioArticulo;
        }

        if (dto.getArticuloId() != null) {
            List<ListaPrecioArticulo> resultados = entityManager.createQuery("""
                    SELECT lpa
                    FROM ListaPrecioArticulo lpa
                    WHERE lpa.articulo.id = :articuloId
                    ORDER BY lpa.id
                    """, ListaPrecioArticulo.class)
                    .setParameter("articuloId", dto.getArticuloId())
                    .setMaxResults(1)
                    .getResultList();
            if (resultados.isEmpty()) {
                throw new RecursoNoEncontradoException(
                        "No existe lista de precio para el articulo con id " + dto.getArticuloId());
            }
            return resultados.get(0);
        }

        throw new DatosInvalidosException("Cada detalle debe indicar articuloId o listaPrecioArticuloId");
    }

    // ------------------------------------------------------------------
    // Consultas auxiliares
    // ------------------------------------------------------------------

    private void validarEscritura(FacturaVenta factura) {
        if ((factura.getCae() != null && !factura.getCae().isBlank())
                || List.of("AUTORIZADA", "ENVIANDO", "A_VERIFICAR").contains(factura.getEstado())) {
            throw new DatosInvalidosException("La factura esta autorizada o tiene un envio pendiente de verificar; no admite cambios ni eliminacion");
        }
    }

    private FacturaVenta buscarFactura(Long id) {
        if (id == null) {
            throw new DatosInvalidosException("El id de la factura es obligatorio");
        }
        FacturaVenta factura = entityManager.find(FacturaVenta.class, id);
        if (factura == null) {
            throw new RecursoNoEncontradoException("Factura no encontrada con id " + id);
        }
        return factura;
    }

    private <T> T buscarObligatorio(Class<T> tipo, Long id, String nombre) {
        if (id == null) {
            throw new DatosInvalidosException(nombre + " es obligatorio");
        }
        T entidad = entityManager.find(tipo, id);
        if (entidad == null) {
            throw new RecursoNoEncontradoException(nombre + " no encontrado con id " + id);
        }
        return entidad;
    }

    private Usuario obtenerUsuarioAuditoria() {
        List<Usuario> usuarios = entityManager.createQuery(
                "SELECT u FROM Usuario u ORDER BY u.id", Usuario.class)
                .setMaxResults(1)
                .getResultList();
        if (usuarios.isEmpty()) {
            throw new DatosInvalidosException("No hay usuarios registrados para auditar la operacion");
        }
        return usuarios.get(0);
    }

    private void auditarAlta(FacturaVenta factura, Usuario usuario) {
        Date ahora = new Date();
        factura.setFechaAlta(ahora);
        factura.setFechaModificacion(ahora);
        factura.setUsuarioCarga(usuario);
        factura.setUsuarioModificacion(usuario);
    }

    private void validarNumeroUnico(Long numero, Long idExcluir) {
        StringBuilder jpql = new StringBuilder(
                "SELECT COUNT(f) FROM FacturaVenta f WHERE f.numero = :numero");
        if (idExcluir != null) {
            jpql.append(" AND f.id <> :idExcluir");
        }
        TypedQuery<Long> query = entityManager.createQuery(jpql.toString(), Long.class)
                .setParameter("numero", numero);
        if (idExcluir != null) {
            query.setParameter("idExcluir", idExcluir);
        }
        if (query.getSingleResult() > 0) {
            throw new DatosInvalidosException("Ya existe una factura con el numero " + numero);
        }
    }

    private Long siguienteNumero() {
        Object maximo = entityManager.createQuery(
                "SELECT COALESCE(MAX(f.numero), 0) FROM FacturaVenta f")
                .getSingleResult();
        return ((Number) maximo).longValue() + 1;
    }

    // ------------------------------------------------------------------
    // Calculo monetario
    // ------------------------------------------------------------------

    /**
     * Importe neto del renglon: cantidad x precio unitario menos la
     * bonificacion. Se calcula con BigDecimal para no arrastrar error de
     * punto flotante y se redondea a dos decimales (HALF_UP).
     */
    private double calcularImporteNeto(double cantidad, double precioUnitario, double porcentajeBonificacion) {
        BigDecimal bruto = BigDecimal.valueOf(cantidad).multiply(BigDecimal.valueOf(precioUnitario));
        BigDecimal descuento = bruto
                .multiply(BigDecimal.valueOf(porcentajeBonificacion))
                .divide(BigDecimal.valueOf(100), 10, RoundingMode.HALF_UP);
        return bruto.subtract(descuento).setScale(ESCALA_IMPORTE, RoundingMode.HALF_UP).doubleValue();
    }

    private double calcularImporteIva(double importeNeto, double porcentajeIva) {
        return BigDecimal.valueOf(importeNeto)
                .multiply(BigDecimal.valueOf(porcentajeIva))
                .divide(BigDecimal.valueOf(100), 10, RoundingMode.HALF_UP)
                .setScale(ESCALA_IMPORTE, RoundingMode.HALF_UP)
                .doubleValue();
    }

    private double calcularTotal(List<FacturaVentaDetalle> detalles) {
        if (detalles == null) {
            return 0;
        }
        BigDecimal total = BigDecimal.ZERO;
        for (FacturaVentaDetalle detalle : detalles) {
            total = total.add(BigDecimal.valueOf(detalle.getImporteSubtotal()));
        }
        return total.setScale(ESCALA_IMPORTE, RoundingMode.HALF_UP).doubleValue();
    }

    private double redondear(double valor) {
        return BigDecimal.valueOf(valor).setScale(ESCALA_IMPORTE, RoundingMode.HALF_UP).doubleValue();
    }

    /**
     * El modelo no guarda la alicuota de IVA aplicada, asi que se deduce de
     * los importes ya persistidos del renglon.
     */
    private double derivarPorcentajeIva(FacturaVentaDetalle detalle) {
        if (detalle.getPorcentajeIva() != null) return detalle.getPorcentajeIva();
        if (detalle.getImporteNeto() == 0) {
            return 0.0;
        }
        return redondear(detalle.getImporteIva() / detalle.getImporteNeto() * 100.0);
    }

    /**
     * Normaliza un instante a la medianoche del dia local.
     *
     * <p>Los filtros de fecha son por dia: sin esta normalizacion un
     * instante con hora deja fuera la factura de ese dia en el limite
     * superior, y buscar desde y hasta el mismo dia no devuelve nada.
     */
    private Date normalizarADiaLocal(Date fecha) {
        if (fecha == null) {
            return null;
        }
        LocalDate dia = fecha.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        return Date.from(dia.atStartOfDay(ZoneId.systemDefault()).toInstant());
    }

    private FacturaReporteDTO construirReporte(FacturaVenta factura) {
        String clienteDenominacion = factura.getCliente() == null
                ? "Consumidor Final" : factura.getCliente().getDenominacion();
        long cantidadItems = factura.getDetalles() == null ? 0 : factura.getDetalles().size();
        FacturaReporteDTO reporte = new FacturaReporteDTO(
                factura.getId(),
                factura.getNumero(),
                factura.getFechaEmision(),
                clienteDenominacion,
                factura.getCondicionIva().getDenominacion(),
                factura.getPuntoVenta().getDescripcion(),
                factura.getEstado(),
                factura.getImporteTotal(),
                cantidadItems);
        reporte.setCae(factura.getCae());
        reporte.setCaeFechaVencimiento(factura.getCaeFechaVencimiento());
        reporte.setMotivoRechazo(factura.getMotivoRechazo());
        return reporte;
    }

    private String formatearFecha(Date fecha) {
        return fecha == null ? "" : new SimpleDateFormat("yyyy-MM-dd").format(fecha);
    }
}
