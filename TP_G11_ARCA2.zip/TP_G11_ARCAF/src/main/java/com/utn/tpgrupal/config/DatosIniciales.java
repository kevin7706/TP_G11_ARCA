package com.utn.tpgrupal.config;

import com.utn.tpgrupal.entities.Articulo;
import com.utn.tpgrupal.entities.AuditoriaApp;
import com.utn.tpgrupal.entities.Cliente;
import com.utn.tpgrupal.entities.CondicionIva;
import com.utn.tpgrupal.entities.Contacto;
import com.utn.tpgrupal.entities.Domicilio;
import com.utn.tpgrupal.entities.FacturaVenta;
import com.utn.tpgrupal.entities.FacturaVentaDetalle;
import com.utn.tpgrupal.entities.ListaPrecio;
import com.utn.tpgrupal.entities.ListaPrecioArticulo;
import com.utn.tpgrupal.entities.Marca;
import com.utn.tpgrupal.entities.PuntoVenta;
import com.utn.tpgrupal.entities.Rubro;
import com.utn.tpgrupal.entities.TipoMoneda;
import com.utn.tpgrupal.entities.Usuario;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * Carga los datos iniciales de la base.
 *
 * <p>La siembra es <b>idempotente</b>: cada registro se busca por su clave
 * natural (codigo de articulo, cuit del cliente, numero de factura) y solo se
 * crea si todavia no existe. Asi se puede volver a correr contra una base ya
 * cargada sin duplicar nada.
 */
@Component
public class DatosIniciales implements CommandLineRunner {

    private static final int CANTIDAD_ARTICULOS = 100;
    private static final int CANTIDAD_CLIENTES = 100;
    private static final double PORCENTAJE_IVA = 21.0;
    private static final String CODIGO_LISTA_GENERAL = "LP-01";
    private static final String CODIGO_LISTA_MAYORISTA = "LP-02";

    private final EntityManager entityManager;

    public DatosIniciales(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @org.springframework.beans.factory.annotation.Value("${arca.punto-venta:1}")
    private int puntoVentaArca;

    @Override
    @Transactional
    public void run(String... args) {
        Usuario usuario = usuarioPorDefecto();
        PuntoVenta puntoVenta = puntoVentaPorDefecto(usuario);
        CondicionIva responsableInscripto = condicionIva(1, "Responsable Inscripto", usuario);
        CondicionIva consumidorFinal = condicionIva(5, "Consumidor Final", usuario);
        condicionIva(4, "Exento", usuario);
        condicionIva(6, "Monotributista", usuario);
        condicionIva(7, "No Categorizado", usuario);
        TipoMoneda moneda = tipoMonedaPorDefecto(usuario);
        Rubro rubro = rubroPorDefecto(usuario);
        ListaPrecio listaGeneral = listaGeneral(usuario);
        ListaPrecio listaMayorista = listaMayorista(usuario);

        Map<String, Marca> marcas = marcasPorDefecto(usuario);
        List<Articulo> articulos = sembrarArticulos(marcas, rubro, listaGeneral, listaMayorista, usuario);
        List<Cliente> clientes = sembrarClientes(usuario);
        sembrarFacturasDeEjemplo(puntoVenta, responsableInscripto, consumidorFinal, moneda,
                listaGeneral, articulos, clientes, usuario);
        // Corrige borradores legados de personas de ejemplo con condicion incompatible con DNI.
        List<FacturaVenta> borradores = entityManager.createQuery("""
            SELECT f FROM FacturaVenta f JOIN f.cliente c
            WHERE c.datosEjemplo = true AND c.tipoDocumento = 96
              AND f.estado IN ('PENDIENTE', 'RECHAZADA')
              AND (f.cae IS NULL OR f.cae = '') AND f.condicionIva.codigoAfip <> 5
            """, FacturaVenta.class).getResultList();
        for (FacturaVenta f : borradores) {
            f.setCondicionIva(consumidorFinal);
            f.setFechaModificacion(new Date());
        }
    }

    // ------------------------------------------------------------------
    // Catalogo base
    // ------------------------------------------------------------------

    private Usuario usuarioPorDefecto() {
        Usuario usuario = buscarUnico(
                "SELECT u FROM Usuario u WHERE u.usuario = :usuario", Map.of("usuario", "jperez"), Usuario.class);
        if (usuario != null) {
            return usuario;
        }
        usuario = new Usuario();
        usuario.setUsuario("jperez");
        usuario.setClave("123456");
        usuario.setNombre("Juan");
        usuario.setApellido("Perez");
        entityManager.persist(usuario);
        return usuario;
    }

    private PuntoVenta puntoVentaPorDefecto(Usuario usuario) {
        PuntoVenta puntoVenta = buscarUnico(
                "SELECT pv FROM PuntoVenta pv WHERE pv.numero = :numero", Map.of("numero", puntoVentaArca), PuntoVenta.class);
        if (puntoVenta != null) {
            return puntoVenta;
        }
        puntoVenta = new PuntoVenta();
        puntoVenta.setNumero(puntoVentaArca);
        puntoVenta.setDescripcion("Sucursal Central");
        puntoVenta.setTipoEmision("Factura Electronica");
        puntoVenta.setDomicilioComercial("Mendoza");
        guardarAuditado(puntoVenta, usuario);
        return puntoVenta;
    }

    private CondicionIva condicionIva(int codigoAfip, String denominacion, Usuario usuario) {
        CondicionIva condicion = buscarUnico(
                "SELECT ci FROM CondicionIva ci WHERE ci.denominacion = :denominacion",
                Map.of("denominacion", denominacion), CondicionIva.class);
        if (condicion != null) {
            return condicion;
        }
        condicion = new CondicionIva();
        condicion.setCodigoAfip(codigoAfip);
        condicion.setDenominacion(denominacion);
        guardarAuditado(condicion, usuario);
        return condicion;
    }

    private TipoMoneda tipoMonedaPorDefecto(Usuario usuario) {
        TipoMoneda moneda = buscarUnico(
                "SELECT tm FROM TipoMoneda tm WHERE tm.denominacion = 'Pesos Argentinos'",
                Map.of(), TipoMoneda.class);
        if (moneda != null) {
            return moneda;
        }
        moneda = new TipoMoneda();
        moneda.setCodigoAfip("PES");
        moneda.setDenominacion("Pesos Argentinos");
        moneda.setSimbolo("$");
        guardarAuditado(moneda, usuario);
        return moneda;
    }

    private Rubro rubroPorDefecto(Usuario usuario) {
        Rubro rubro = buscarUnico(
                "SELECT r FROM Rubro r WHERE r.denominacion = 'Informatica'", Map.of(), Rubro.class);
        if (rubro != null) {
            return rubro;
        }
        rubro = new Rubro();
        rubro.setCodigo(1);
        rubro.setDenominacion("Informatica");
        guardarAuditado(rubro, usuario);
        return rubro;
    }

    private Map<String, Marca> marcasPorDefecto(Usuario usuario) {
        Map<String, Marca> marcas = new HashMap<>();
        int codigo = 1;
        for (String denominacion : new String[]{"Logitech", "Samsung", "Philips", "HP",
                "Lenovo", "Epson", "Seagate", "Kingston"}) {
            Marca marca = buscarUnico(
                    "SELECT m FROM Marca m WHERE m.denominacion = :denominacion",
                    Map.of("denominacion", denominacion), Marca.class);
            if (marca == null) {
                marca = new Marca();
                marca.setCodigo(codigo);
                marca.setDenominacion(denominacion);
                guardarAuditado(marca, usuario);
            }
            marcas.put(denominacion, marca);
            codigo++;
        }
        return marcas;
    }

    private ListaPrecio listaGeneral(Usuario usuario) {
        ListaPrecio lista = buscarUnico(
                "SELECT lp FROM ListaPrecio lp WHERE lp.codigo = :codigo",
                Map.of("codigo", CODIGO_LISTA_GENERAL), ListaPrecio.class);
        if (lista != null) {
            return lista;
        }
        lista = new ListaPrecio();
        lista.setCodigo(CODIGO_LISTA_GENERAL);
        lista.setDenominacion("Lista General");
        guardarAuditado(lista, usuario);
        return lista;
    }

    private ListaPrecio listaMayorista(Usuario usuario) {
        ListaPrecio lista = buscarUnico(
                "SELECT lp FROM ListaPrecio lp WHERE lp.codigo = :codigo",
                Map.of("codigo", CODIGO_LISTA_MAYORISTA), ListaPrecio.class);
        if (lista != null) {
            return lista;
        }
        lista = new ListaPrecio();
        lista.setCodigo(CODIGO_LISTA_MAYORISTA);
        lista.setDenominacion("Lista Mayorista");
        guardarAuditado(lista, usuario);
        return lista;
    }

    // ------------------------------------------------------------------
    // Articulos
    // ------------------------------------------------------------------

    /**
     * Catalogo de productos: cada plantilla define un tipo de articulo, su
     * marca, su precio base y las variantes que se venden. Con las 20
     * plantillas y 5 variantes cada una se llega a los 100 articulos.
     */
    private static final List<Plantilla> PLANTILLAS = List.of(
            new Plantilla("Teclado", "Logitech", 15000, List.of(
                    "Logitech", "Mecanico", "Inalambrico", "Gamer RGB", "Ergonomico")),
            new Plantilla("Mouse", "Logitech", 10000, List.of(
                    "Logitech", "Optico", "Inalambrico", "Gamer", "Vertical")),
            new Plantilla("Monitor", "Samsung", 185000, List.of(
                    "24 Pulgadas", "27 Pulgadas", "Wide", "Curvo", "Gaming")),
            new Plantilla("Notebook", "Lenovo", 950000, List.of(
                    "14 Pulgadas", "15 Pulgadas", "17 Pulgadas", "Gaming", "Ultraliviana")),
            new Plantilla("Impresora", "HP", 235000, List.of(
                    "Laser Monocromatica", "Laser Color", "Multifuncion", "Formato A3", "De Etiquetas")),
            new Plantilla("Auriculares", "Logitech", 54000, List.of(
                    "In Ear", "Vincha", "Inalambricos", "Gamer 7.1", "Con Microfono")),
            new Plantilla("Webcam", "Logitech", 47000, List.of(
                    "HD 1080p", "4K", "Portatil", "Con Microfono", "Streaming")),
            new Plantilla("Router", "Samsung", 61000, List.of(
                    "WiFi 6", "WiFi 6E", "Mesh Doble Banda", "Portatil", "Industrial")),
            new Plantilla("Switch", "Samsung", 138000, List.of(
                    "8 Puertos", "16 Puertos", "24 Puertos", "Managed con PoE", "Gigabit")),
            new Plantilla("Disco Externo", "Seagate", 92000, List.of(
                    "1TB", "2TB", "4TB", "Portable", "Antishock")),
            new Plantilla("Disco SSD", "Samsung", 118000, List.of(
                    "240GB SATA", "500GB SATA", "1TB SATA", "500GB NVMe", "1TB NVMe")),
            new Plantilla("Pendrive", "Kingston", 14500, List.of(
                    "16GB", "32GB", "64GB", "128GB", "Doble Conector")),
            new Plantilla("Tablet", "Samsung", 315000, List.of(
                    "10 Pulgadas", "11 Pulgadas", "12.4 Pulgadas", "Con Teclado", "Con Lapiz")),
            new Plantilla("Cargador", "Samsung", 26000, List.of(
                    "25W Tipo C", "45W Tipo C", "65W Tipo C", "Inalambrico", "Para Notebook")),
            new Plantilla("Cable", "Philips", 8500, List.of(
                    "HDMI 2.1", "USB-C a USB-C", "USB-A a USB-C", "Red Ethernet Cat6", "Audio 3.5mm")),
            new Plantilla("Base Enfriadora", "Logitech", 43000, List.of(
                    "3 Ventiladores", "5 Ventiladores", "Para 15.6 Pulgadas", "Para 17 Pulgadas", "Silenciosa")),
            new Plantilla("Estabilizador", "Philips", 128000, List.of(
                    "650VA", "1000VA", "1500VA", "2200VA", "Para Rack")),
            new Plantilla("Proyector", "Epson", 415000, List.of(
                    "3000 Lumenes", "4000 Lumenes", "Full HD", "Portatil", "Interactivo")),
            new Plantilla("Impresora de Etiquetas", "Epson", 158000, List.of(
                    "100mm", "150mm", "Termica", "Industrial", "Para Zebra")),
            new Plantilla("Tableta Grafica", "Lenovo", 165000, List.of(
                    "Pequena", "Mediana", "Grande", "Con Lapiz", "Inalambrica")));

    private record Plantilla(String tipo, String marca, double precioBase, List<String> variantes) {
    }

    private List<Articulo> sembrarArticulos(Map<String, Marca> marcas, Rubro rubro,
            ListaPrecio listaGeneral, ListaPrecio listaMayorista, Usuario usuario) {
        List<Articulo> articulos = new ArrayList<>();
        int numero = 0;

        for (Plantilla plantilla : PLANTILLAS) {
            Marca marca = marcas.get(plantilla.marca());
            for (int variante = 0; variante < plantilla.variantes().size(); variante++) {
                numero++;
                String codigo = String.format("ART-%03d", numero);
                String denominacion = plantilla.tipo() + " " + plantilla.variantes().get(variante);
                double precio = Math.round(plantilla.precioBase() * (1 + 0.18 * variante) / 100.0) * 100.0;

                Articulo articulo = buscarUnico(
                        "SELECT a FROM Articulo a WHERE a.codigo = :codigo",
                        Map.of("codigo", codigo), Articulo.class);
                if (articulo == null) {
                    articulo = new Articulo();
                    articulo.setCodigo(codigo);
                    articulo.setDenominacion(denominacion);
                    articulo.setRubro(rubro);
                    articulo.setMarca(marca);
                    guardarAuditado(articulo, usuario);
                }
                articulos.add(articulo);

                // Cada articulo queda disponible en ambas listas, con precios
                // propios para que pueda agregarse varias veces a una factura.
                ListaPrecioArticulo precioGeneral = buscarPrecio(listaGeneral, articulo);
                if (precioGeneral == null) {
                    precioGeneral = crearPrecio(listaGeneral, articulo, precio, usuario);
                }
                if (buscarPrecio(listaMayorista, articulo) == null) {
                    double precioMayorista = Math.round(precioGeneral.getPrecioVenta() * 0.90 * 100.0) / 100.0;
                    crearPrecio(listaMayorista, articulo, precioMayorista, usuario);
                }
            }
        }
        return articulos;
    }

    private ListaPrecioArticulo buscarPrecio(ListaPrecio lista, Articulo articulo) {
        return buscarUnico("""
                SELECT lpa FROM ListaPrecioArticulo lpa
                JOIN lpa.listaPrecio lp
                JOIN lpa.articulo a
                WHERE lp.id = :listaId AND a.id = :articuloId
                """, Map.of("listaId", lista.getId(), "articuloId", articulo.getId()),
                ListaPrecioArticulo.class);
    }

    private ListaPrecioArticulo crearPrecio(ListaPrecio lista, Articulo articulo, double precio, Usuario usuario) {
        ListaPrecioArticulo relacion = new ListaPrecioArticulo();
        relacion.setListaPrecio(lista);
        relacion.setArticulo(articulo);
        relacion.setPrecioVenta(precio);
        guardarAuditado(relacion, usuario);
        return relacion;
    }

    // ------------------------------------------------------------------
    // Clientes
    // ------------------------------------------------------------------

    private static final List<String> NOMBRES = List.of(
            "Juan Carlos", "Maria Laura", "Ana Paula", "Carlos Alberto", "Martin Alejandro",
            "Florencia", "Diego Armando", "Esteban", "Silvia", "Roberto",
            "Natalia", "Javier", "Claudia", "Fernando", "Laura",
            "Diego", "Sofia", "Marcos", "Valeria", "Gonzalo");

    private static final List<String> APELLIDOS = List.of(
            "Perez", "Gomez", "Benitez", "Martinez", "Lopez",
            "Fernandez", "Sosa", "Gutierrez", "Romero", "Diaz");

    private static final List<String> EMPRESAS = List.of(
            "Electro Cuyo SA", "Informatica Andina SA", "TecnoMendoza SRL", "Distribuidora Norte SRL",
            "Mega Electronica SA", "Herramientas Pro SRL", "Comercial del Plata SA", "Servicios Globales SA",
            "Tecnologia Sur SA", "Grupo Delta SA", "Industrias Neuquen SA", "Logistica Patagonica SA",
            "Materiales Central SA", "Soluciones Digitales SA", "Casa Norte SA",
            "Alimentos del Sur SA", "Transportes Cuyo SA", "Inversiones Andes SA", "Distribuidora Sur SA",
            "Tecnologia Austral SA");

    private static final List<String> CALLEJEROS = List.of(
            "San Martin", "San Juan", "Sarmiento", "Mitre", "Belgrano",
            "Rivadavia", "Alsina", "Corrientes", "Entre Rios", "CORDoba");

    private List<Cliente> sembrarClientes(Usuario usuario) {
        List<Cliente> clientes = new ArrayList<>();

        for (int numero = 1; numero <= CANTIDAD_CLIENTES; numero++) {
            boolean empresa = numero % 5 == 0;
            String denominacion;
            if (numero == 1) {
                denominacion = "Cliente UTN";
            } else if (empresa) {
                denominacion = EMPRESAS.get((numero / 5 - 1) % EMPRESAS.size());
            } else {
                denominacion = NOMBRES.get(numero % NOMBRES.size())
                        + " " + APELLIDOS.get((numero / NOMBRES.size()) % APELLIDOS.size());
            }
            String cuit = cuitDe(numero, empresa);

            Cliente cliente = buscarUnico(
                    "SELECT c FROM Cliente c WHERE c.cuitCuil = :cuit", Map.of("cuit", cuit), Cliente.class);
            if (cliente == null) {
                cliente = new Cliente();
                cliente.setCuitCuil(cuit);
                cliente.setDenominacion(denominacion);
                cliente.setContacto(crearContacto(numero));
                cliente.setDomicilio(crearDomicilio(numero));
                guardarAuditado(cliente, usuario);
            }
            // Migracion idempotente solo de las semillas identificadas por su CUIT legado exacto.
            // No se reemplazan datos fiscales que el usuario ya haya configurado.
            if (cliente.getTipoDocumento() == null) {
                cliente.setDatosEjemplo(true);
                cliente.setTipoDocumento(empresa ? 80 : 96);
                cliente.setNumeroDocumento(empresa ? cuit.replace("-", "") : String.valueOf(10000000 + numero));
                cliente.setCodigoCondicionIva(empresa ? 1 : 5);
            }
            clientes.add(cliente);
        }
        return clientes;
    }

    /** Cuit sintetico y unico por cliente: personas fisicas 20/27, juridicas 30. */
    private String cuitDe(int numero, boolean empresa) {
        String prefijo = empresa ? "30" : (numero % 2 == 0 ? "20" : "27");
        String cuerpo = String.format("%08d", 10000000 + numero);
        String digito = String.valueOf((numero * 3 + 7) % 10);
        return prefijo + "-" + cuerpo + "-" + digito;
    }

    private Contacto crearContacto(int numero) {
        Contacto contacto = new Contacto();
        if (numero == 1) {
            contacto.setEmail("cliente@utn.edu.ar");
            contacto.setTelefono("261-4000000");
            contacto.setCelular("261-5000000");
        } else {
            contacto.setEmail("cliente" + numero + "@ejemplo.com.ar");
            contacto.setTelefono("261-" + (4000000 + numero));
            contacto.setCelular("261-" + (5000000 + numero));
        }
        entityManager.persist(contacto);
        return contacto;
    }

    private Domicilio crearDomicilio(int numero) {
        Domicilio domicilio = new Domicilio();
        if (numero == 1) {
            domicilio.setNombreCalle("San Martin");
            domicilio.setNumeroCalle("100");
        } else {
            domicilio.setNombreCalle(CALLEJEROS.get(numero % CALLEJEROS.size()));
            domicilio.setNumeroCalle(String.valueOf(100 + numero));
        }
        entityManager.persist(domicilio);
        return domicilio;
    }

    // ------------------------------------------------------------------
    // Facturas de ejemplo
    // ------------------------------------------------------------------

    private void sembrarFacturasDeEjemplo(PuntoVenta puntoVenta, CondicionIva responsableInscripto,
            CondicionIva consumidorFinal, TipoMoneda moneda, ListaPrecio listaGeneral,
            List<Articulo> articulos, List<Cliente> clientes, Usuario usuario) {
        if (articulos.size() < 4 || clientes.size() < 2) {
            return;
        }
        crearFactura(1001L, fecha(2026, 3, 15), "PENDIENTE", puntoVenta, clientes.get(0),
                responsableInscripto, moneda, listaGeneral, usuario,
                new DetalleEjemplo(articulos.get(0), 2), new DetalleEjemplo(articulos.get(1), 1));
        crearFactura(1002L, fecha(2026, 3, 20), "PENDIENTE", puntoVenta, null,
                consumidorFinal, moneda, listaGeneral, usuario,
                new DetalleEjemplo(articulos.get(2), 3));
        crearFactura(1003L, fecha(2026, 3, 25), "ANULADA", puntoVenta, clientes.get(1),
                responsableInscripto, moneda, listaGeneral, usuario,
                new DetalleEjemplo(articulos.get(3), 1));
    }

    private record DetalleEjemplo(Articulo articulo, double cantidad) {
    }

    private void crearFactura(Long numero, Date fecha, String estado, PuntoVenta puntoVenta, Cliente cliente,
            CondicionIva condicionIva, TipoMoneda moneda, ListaPrecio listaGeneral, Usuario usuario,
            DetalleEjemplo... detalles) {

        if (buscarUnico("SELECT f FROM FacturaVenta f WHERE f.observaciones = :marca",
                Map.of("marca", "Ejemplo local " + numero), FacturaVenta.class) != null) {
            return;
        }

        FacturaVenta factura = new FacturaVenta();
        factura.setNumero(null);
        factura.setObservaciones("Ejemplo local " + numero);
        factura.setFechaEmision(fecha);
        factura.setEstado(estado);
        factura.setPuntoVenta(puntoVenta);
        factura.setCliente(cliente);
        factura.setCondicionIva(condicionIva);
        factura.setTipoMoneda(moneda);
        auditar(factura, usuario);

        factura.setDetalles(new ArrayList<>());
        double total = 0;
        for (DetalleEjemplo ejemplo : detalles) {
            ListaPrecioArticulo precio = buscarPrecio(listaGeneral, ejemplo.articulo());
            double precioUnitario = precio == null ? 0 : precio.getPrecioVenta();
            double neto = redondear(ejemplo.cantidad() * precioUnitario);
            double iva = redondear(neto * PORCENTAJE_IVA / 100.0);
            double subtotal = redondear(neto + iva);

            FacturaVentaDetalle detalle = new FacturaVentaDetalle();
            detalle.setFactura(factura);
            detalle.setListaPrecioArticulo(precio);
            detalle.setDescripcion(ejemplo.articulo().getDenominacion());
            detalle.setCantidad(ejemplo.cantidad());
            detalle.setPrecioUnitario(precioUnitario);
            detalle.setPorcentajeBonificacion(0);
            detalle.setPorcentajeIva(PORCENTAJE_IVA);
            detalle.setImporteNeto(neto);
            detalle.setImporteIva(iva);
            detalle.setImporteSubtotal(subtotal);
            factura.getDetalles().add(detalle);
            total += subtotal;
        }

        factura.setImporteTotal(redondear(total));
        factura.setImporteCobrado(redondear(total));
        factura.setImporteSaldo(0);
        entityManager.persist(factura);
    }

    // ------------------------------------------------------------------
    // Utilidades
    // ------------------------------------------------------------------

    private <T> T buscarUnico(String jpql, Map<String, Object> parametros, Class<T> tipo) {
        TypedQuery<T> query = entityManager.createQuery(jpql, tipo);
        parametros.forEach(query::setParameter);
        List<T> resultados = query.setMaxResults(1).getResultList();
        return resultados.isEmpty() ? null : resultados.get(0);
    }

    private void guardarAuditado(AuditoriaApp entidad, Usuario usuario) {
        auditar(entidad, usuario);
        entityManager.persist(entidad);
    }

    private void auditar(AuditoriaApp entidad, Usuario usuario) {
        Date ahora = new Date();
        entidad.setFechaAlta(ahora);
        entidad.setFechaModificacion(ahora);
        entidad.setUsuarioCarga(usuario);
        entidad.setUsuarioModificacion(usuario);
    }

    private Date fecha(int anio, int mes, int dia) {
        return Date.from(LocalDate.of(anio, mes, dia).atStartOfDay(ZoneId.systemDefault()).toInstant());
    }

    private double redondear(double valor) {
        return Math.round(valor * 100.0) / 100.0;
    }
}
