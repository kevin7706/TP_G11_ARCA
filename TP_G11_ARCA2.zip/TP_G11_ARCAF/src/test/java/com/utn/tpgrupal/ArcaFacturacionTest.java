package com.utn.tpgrupal;

import com.utn.tpgrupal.dto.*;
import com.utn.tpgrupal.entities.*;
import com.utn.tpgrupal.exception.DatosInvalidosException;
import com.utn.tpgrupal.service.*;
import com.utn.tpgrupal.service.arca.*;
import jakarta.persistence.EntityManager;
import java.util.*;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@SpringBootTest(properties = {"arca.habilitada=true", "arca.cuit=20111111112", "arca.clave=/no-utilizada.key",
        "arca.certificado=/no-utilizado.crt", "arca.emisor-razon-social=Emisor TEST", "arca.emisor-domicilio=Mendoza 123", "arca.emisor-condicion-iva=Responsable Inscripto"})
class ArcaFacturacionTest {
    @Autowired FacturaService facturas;
    @Autowired EmisionArcaService emision;
    @Autowired FacturaPdfService pdf;
    @Autowired EntityManager em;
    @Autowired PlatformTransactionManager tm;
    @MockitoBean WsfeService wsfe;
    Long id;
    TransactionTemplate tx() { return new TransactionTemplate(tm); }
    @BeforeEach void preparar() throws Exception {
        id = tx().execute(status -> {
            var dto = new FacturaRequestDTO(); dto.setFechaEmision(new Date()); dto.setConsumidorFinal(true);
            dto.setCondicionIvaId(em.createQuery("SELECT c.id FROM CondicionIva c WHERE c.codigoAfip=5", Long.class).getSingleResult());
            dto.setPuntoVentaId(em.createQuery("SELECT p.id FROM PuntoVenta p", Long.class).setMaxResults(1).getSingleResult());
            dto.setTipoMonedaId(em.createQuery("SELECT m.id FROM TipoMoneda m", Long.class).setMaxResults(1).getSingleResult());
            var detalle = new FacturaDetalleRequestDTO();
            detalle.setListaPrecioArticuloId(em.createQuery("SELECT p.id FROM ListaPrecioArticulo p", Long.class).setMaxResults(1).getSingleResult());
            detalle.setCantidad(2.0); detalle.setPrecioUnitario(100.0); detalle.setPorcentajeIva(21.0);
            dto.setDetalles(List.of(detalle));
            return facturas.crear(dto).getId();
        });
        when(wsfe.ultimo(anyInt(), anyInt())).thenReturn(40L);
        when(wsfe.autorizar(anyString())).thenReturn(new WsfeService.Respuesta("A", "12345678901234", "20261231", ""));
    }
    @AfterEach void limpiar() { if (id != null) tx().execute(status -> { em.remove(em.find(FacturaVenta.class, id)); return null; }); }
    FacturaVenta estado() { return tx().execute(status -> em.find(FacturaVenta.class, id)); }

    @Autowired com.utn.tpgrupal.service.ClienteFiscalService clientes;
    @Autowired com.utn.tpgrupal.config.DatosIniciales semillas;

    @Test void personaSembradaEnviaDniYNoElCuitInventado() throws Exception {
        tx().execute(status -> {
            Cliente c = em.createQuery("SELECT c FROM Cliente c WHERE c.tipoDocumento=96 ORDER BY c.id", Cliente.class).setMaxResults(1).getSingleResult();
            em.find(FacturaVenta.class,id).setCliente(c); return null;
        });
        emision.informar(id);
        verify(wsfe).autorizar(contains("<DocTipo>96</DocTipo>"));
        assertEquals("AUTORIZADA",estado().getEstado());
    }
    @Test void empresaConCuitSinteticoSeBloqueaAntesDeLlamarArca() throws Exception {
        tx().execute(status -> {
            Cliente c = em.createQuery("SELECT c FROM Cliente c WHERE c.tipoDocumento=80 AND c.datosEjemplo=true", Cliente.class).setMaxResults(1).getSingleResult();
            em.find(FacturaVenta.class,id).setCliente(c); return null;
        });
        var error = assertThrows(DatosInvalidosException.class, () -> emision.informar(id));
        assertTrue(error.getMessage().contains("ficticio")); verify(wsfe, never()).ultimo(anyInt(),anyInt());
        assertEquals("PENDIENTE",estado().getEstado());
    }
    @Test void corregirClienteNoModificaDocumentoDeFacturaYaAutorizada() {
        Long clienteId = tx().execute(status -> {
            Cliente c=em.createQuery("SELECT c FROM Cliente c WHERE c.tipoDocumento=96 ORDER BY c.id",Cliente.class).setMaxResults(1).getSingleResult();
            em.find(FacturaVenta.class,id).setCliente(c); return c.getId();
        });
        emision.informar(id); String documento = emision.datosImpresion(id).documento();
        try {
            clientes.actualizar(clienteId,new ClienteFiscalService.Solicitud(99,"0",5));
            semillas.run();
            Integer tipoGuardado = tx().execute(status -> em.find(Cliente.class,clienteId).getTipoDocumento());
            assertEquals(Integer.valueOf(99),tipoGuardado);
            assertEquals(documento,emision.datosImpresion(id).documento());
        } finally { clientes.actualizar(clienteId,new ClienteFiscalService.Solicitud(96,documento,5)); }
    }
    @Test void montoQueExigeIdentificacionNoSaleComoAnonimo() throws Exception {
        tx().execute(status -> { em.find(FacturaVenta.class,id).setImporteTotal(10000000); return null; });
        assertThrows(DatosInvalidosException.class, () -> emision.informar(id)); verify(wsfe,never()).autorizar(anyString());
    }
    @Test void apiFiscalRechazaDniConIvaResponsableInscripto() {
        Long clienteId=tx().execute(status -> em.createQuery("SELECT c.id FROM Cliente c",Long.class).setMaxResults(1).getSingleResult());
        assertThrows(DatosInvalidosException.class, () -> clientes.actualizar(clienteId,new ClienteFiscalService.Solicitud(96,"10000001",1)));
    }
    @Test void creaPendienteSinNumeroFiscal() {
        assertEquals("PENDIENTE", estado().getEstado()); assertNull(estado().getNumero()); assertNull(estado().getCae());
    }
    @Test void autorizaPermiteAnulacionLocalPeroBloqueaEdicionYBorradoFisico() throws Exception {
        emision.informar(id);
        assertEquals("AUTORIZADA", estado().getEstado()); assertEquals(41L, estado().getNumero());
        assertEquals("12345678901234", estado().getCae()); assertNotNull(estado().getCaeFechaVencimiento());
        var cambio = new FacturaRequestDTO(); cambio.setObservaciones("No permitido");
        assertThrows(DatosInvalidosException.class, () -> facturas.actualizar(id, cambio));
        facturas.eliminar(id);
        assertEquals("ANULADA", estado().getEstado());
        assertEquals("12345678901234", estado().getCae());
        assertThrows(DatosInvalidosException.class, () -> facturas.eliminarFisicamente(id));
        emision.informar(id);
        assertEquals("ANULADA", estado().getEstado());
        verify(wsfe, times(1)).autorizar(anyString());
    }
    @Test void rechazoPermiteCorregirYReintentar() throws Exception {
        when(wsfe.autorizar(anyString())).thenReturn(new WsfeService.Respuesta("R", "", "", "Documento invalido"));
        emision.informar(id); assertEquals("RECHAZADA", estado().getEstado()); assertNull(estado().getNumero());
        var cambio = new FacturaRequestDTO(); cambio.setObservaciones("Corregida"); facturas.actualizar(id, cambio);
        when(wsfe.autorizar(anyString())).thenReturn(new WsfeService.Respuesta("A", "12345678901234", "20261231", ""));
        emision.informar(id); assertEquals("AUTORIZADA", estado().getEstado());
    }
    @Test void timeoutNoDuplicaEmisionYRecuperaCAE() throws Exception {
        when(wsfe.autorizar(anyString())).thenThrow(new java.net.http.HttpTimeoutException("timeout"));
        assertThrows(DatosInvalidosException.class, () -> emision.informar(id)); assertEquals("A_VERIFICAR", estado().getEstado());
        assertNotNull(estado().getSolicitudArca()); assertEquals(41L, estado().getNumeroTentativo());
        assertThrows(DatosInvalidosException.class, () -> facturas.eliminar(id));
        assertThrows(DatosInvalidosException.class, () -> facturas.eliminarFisicamente(id));
        when(wsfe.consultarVerificada(any(Comprobante.class), anyLong())).thenReturn(new WsfeService.Respuesta("A", "12345678901234", "20261231", "Recuperada"));
        emision.informar(id); assertEquals("AUTORIZADA", estado().getEstado()); verify(wsfe, times(1)).autorizar(anyString());
    }
    @Test void caidaAntesDeEnviarDejaPendienteEditable() throws Exception {
        when(wsfe.ultimo(anyInt(), anyInt())).thenThrow(new java.io.IOException("sin conexion"));
        assertThrows(DatosInvalidosException.class, () -> emision.informar(id)); assertEquals("PENDIENTE", estado().getEstado());
        verify(wsfe, never()).autorizar(anyString()); facturas.eliminar(id);
    }
    @Test void filtrosPaginanFacturasSinMultiplicarPorDetalles() {
        var pagina = facturas.buscarPagina(null, null, null, null, null, null, false, 0, 1);
        assertEquals(1, pagina.contenido().size()); assertTrue(pagina.totalElementos() >= 3);
        var otra = facturas.buscarPagina(null, null, null, null, null, null, false, 1, 1);
        assertNotEquals(pagina.contenido().get(0).getId(), otra.contenido().get(0).getId());
        assertThrows(DatosInvalidosException.class, () -> facturas.buscarPagina(null, null, null, null, null, null, null, -1, 10));
        assertThrows(DatosInvalidosException.class, () -> facturas.buscarPagina(null, null, null, null, null, null, null, 0, 101));
    }
    @Test void filtraNumeroYAutorizacionCombinados() {
        emision.informar(id);
        var pagina = facturas.buscarPagina(null, null, "AUTORIZADA", 200.0, 41L, null, true, 0, 10);
        assertEquals(1, pagina.totalElementos()); assertEquals(id, pagina.contenido().get(0).getId());
        assertEquals(0, facturas.buscarPagina(null, null, null, null, 41L, null, false, 0, 10).totalElementos());
    }
    @Test void pdfIndividualIncluyeCAEYVencimiento() throws Exception {
        emision.informar(id);
        byte[] bytes = pdf.generar(id);
        var reader = new com.lowagie.text.pdf.PdfReader(bytes);
        String texto = new com.lowagie.text.pdf.parser.PdfTextExtractor(reader).getTextFromPage(1);
        assertTrue(texto.contains("12345678901234")); assertTrue(texto.contains("2026-12-31")); assertTrue(texto.contains("HOMOLOGACION"));
        reader.close();
        java.nio.file.Path dir = java.nio.file.Path.of("target/qa"); java.nio.file.Files.createDirectories(dir);
        java.nio.file.Files.write(dir.resolve("factura-autorizada-test.pdf"), bytes);
    }
    @Test void qrSeDecodificaYContieneLosDatosAutorizados() throws Exception {
        emision.informar(id);
        var reader = new com.lowagie.text.pdf.PdfReader(pdf.generar(id));
        var objetos = reader.getPageN(1).getAsDict(com.lowagie.text.pdf.PdfName.RESOURCES).getAsDict(com.lowagie.text.pdf.PdfName.XOBJECT);
        String url = null;
        for (var nombre : objetos.getKeys()) {
            var objeto = com.lowagie.text.pdf.PdfReader.getPdfObject(objetos.get(nombre));
            if (objeto instanceof com.lowagie.text.pdf.PRStream stream && com.lowagie.text.pdf.PdfName.IMAGE.equals(stream.getAsName(com.lowagie.text.pdf.PdfName.SUBTYPE))) {
                int w = stream.getAsNumber(com.lowagie.text.pdf.PdfName.WIDTH).intValue();
                int h = stream.getAsNumber(com.lowagie.text.pdf.PdfName.HEIGHT).intValue();
                byte[] pixels = com.lowagie.text.pdf.PdfReader.getStreamBytes(stream);
                var source = new com.google.zxing.PlanarYUVLuminanceSource(pixels, w, h, 0, 0, w, h, false);
                url = new com.google.zxing.MultiFormatReader().decode(new com.google.zxing.BinaryBitmap(new com.google.zxing.common.HybridBinarizer(source))).getText();
            }
        }
        reader.close(); assertNotNull(url); assertTrue(url.startsWith("https://www.arca.gob.ar/fe/qr/?p="));
        String payload = new String(Base64.getDecoder().decode(url.split("p=", 2)[1]), java.nio.charset.StandardCharsets.UTF_8);
        assertTrue(payload.contains("12345678901234")); assertTrue(payload.contains("\"nroCmp\":41")); assertTrue(payload.contains("242.00"));
    }
    @Test void vistaPreviaNoInventaAutorizacion() throws Exception {
        var reader = new com.lowagie.text.pdf.PdfReader(pdf.generar(id));
        String texto = new com.lowagie.text.pdf.parser.PdfTextExtractor(reader).getTextFromPage(1);
        assertTrue(texto.contains("NO AUTORIZADA")); assertFalse(texto.contains("12345678901234")); reader.close();
    }
    @Test void pdfDeMuchasLineasRepiteEncabezadosYConservaPie() throws Exception {
        tx().execute(status -> {
            FacturaVenta f = em.find(FacturaVenta.class, id);
            FacturaVentaDetalle base = f.getDetalles().get(0);
            for (int i = 0; i < 90; i++) {
                var d = new FacturaVentaDetalle(); d.setFactura(f); d.setListaPrecioArticulo(base.getListaPrecioArticulo());
                d.setDescripcion("Articulo de prueba numero " + i); d.setCantidad(2); d.setPrecioUnitario(100);
                d.setPorcentajeIva(21.0); d.setImporteNeto(200); d.setImporteIva(42); d.setImporteSubtotal(242);
                f.getDetalles().add(d);
            }
            f.setImporteTotal(242 * 91); return null;
        });
        emision.informar(id);
        byte[] bytes = pdf.generar(id); var reader = new com.lowagie.text.pdf.PdfReader(bytes);
        assertTrue(reader.getNumberOfPages() > 1);
        String ultima = new com.lowagie.text.pdf.parser.PdfTextExtractor(reader).getTextFromPage(reader.getNumberOfPages());
        assertTrue(ultima.contains("12345678901234")); assertTrue(ultima.contains("TOTAL")); reader.close();
        java.nio.file.Path dir = java.nio.file.Path.of("target/qa"); java.nio.file.Files.createDirectories(dir);
        java.nio.file.Files.write(dir.resolve("factura-multipagina-test.pdf"), bytes);
    }
    @Test void conservaInstantaneaAunqueCambienLosCatalogos() {
        emision.informar(id);
        String original = emision.datosImpresion(id).items().get(0).descripcion();
        tx().execute(status -> {
            FacturaVenta f = em.find(FacturaVenta.class, id);
            f.getDetalles().get(0).setDescripcion("Descripcion modificada fuera del circuito normal"); return null;
        });
        assertEquals(original, emision.datosImpresion(id).items().get(0).descripcion());
    }
    @Test void envioSimultaneoDeMismaFacturaNoDuplica() throws Exception {
        var executor = java.util.concurrent.Executors.newFixedThreadPool(2);
        try {
            var uno = executor.submit(() -> emision.informar(id)); var dos = executor.submit(() -> emision.informar(id));
            uno.get(); dos.get();
        } finally { executor.shutdownNow(); }
        verify(wsfe, times(1)).autorizar(anyString());
    }
}
