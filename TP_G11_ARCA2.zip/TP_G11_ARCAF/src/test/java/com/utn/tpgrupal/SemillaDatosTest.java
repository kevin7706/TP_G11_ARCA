package com.utn.tpgrupal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.utn.tpgrupal.config.DatosIniciales;
import com.utn.tpgrupal.entities.Articulo;
import com.utn.tpgrupal.entities.Cliente;
import com.utn.tpgrupal.entities.FacturaVenta;
import com.utn.tpgrupal.entities.FacturaVentaDetalle;
import com.utn.tpgrupal.entities.ListaPrecio;
import com.utn.tpgrupal.entities.ListaPrecioArticulo;
import jakarta.persistence.EntityManager;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

/**
 * La semilla de datos iniciales: tiene que dejar la base con datos de sobra
 * para probar los exploradores y, sobre todo, tiene que ser idempotente
 * (poder volver a correrla sin duplicar nada).
 */
@SpringBootTest
@Transactional
class SemillaDatosTest {

    private static final int CANTIDAD_ARTICULOS = 100;
    private static final int CANTIDAD_CLIENTES = 100;

    @Autowired
    private DatosIniciales datosIniciales;

    @Autowired
    private EntityManager entityManager;

    @Test
    void siembraCienArticulos() {
        assertEquals(CANTIDAD_ARTICULOS, contar(Articulo.class));
    }

    @Test
    void siembraCienClientes() {
        assertEquals(CANTIDAD_CLIENTES, contar(Cliente.class));
    }

    @Test
    void cadaArticuloQuedaConSuPrecioEnLaListaGeneral() {
        ListaPrecio listaGeneral = listaPorCodigo("LP-01");
        assertNotNull(listaGeneral);
        assertEquals("Lista General", listaGeneral.getDenominacion());

        List<ListaPrecioArticulo> precios = entityManager.createQuery("""
                SELECT lpa FROM ListaPrecioArticulo lpa
                JOIN lpa.listaPrecio lp
                WHERE lp.id = :listaId
                """, ListaPrecioArticulo.class)
                .setParameter("listaId", listaGeneral.getId())
                .getResultList();

        assertEquals(CANTIDAD_ARTICULOS, precios.size());
        assertTrue(precios.stream().allMatch(p -> p.getPrecioVenta() > 0));
        assertEquals(CANTIDAD_ARTICULOS,
                precios.stream().map(p -> p.getArticulo().getId()).distinct().count());
    }

    @Test
    void existenDosListasConTodosLosArticulosYPreciosPropios() {
        List<ListaPrecio> listas = entityManager.createQuery(
                "SELECT lp FROM ListaPrecio lp ORDER BY lp.codigo", ListaPrecio.class).getResultList();

        assertEquals(2, listas.size());
        assertEquals("LP-01", listas.get(0).getCodigo());
        assertEquals("LP-02", listas.get(1).getCodigo());

        List<Object[]> preciosCompartidos = entityManager.createQuery("""
                SELECT general.articulo.id, general.precioVenta, mayorista.precioVenta
                FROM ListaPrecioArticulo general, ListaPrecioArticulo mayorista
                WHERE general.articulo.id = mayorista.articulo.id
                  AND general.listaPrecio.codigo = 'LP-01'
                  AND mayorista.listaPrecio.codigo = 'LP-02'
                """, Object[].class).getResultList();

        assertEquals(CANTIDAD_ARTICULOS, preciosCompartidos.size());
        assertTrue(preciosCompartidos.stream().allMatch(p ->
                ((Number) p[1]).doubleValue() > ((Number) p[2]).doubleValue()));
    }

    @Test
    void losClientesTienenDenominacionYCuit() {
        List<Cliente> clientes = entityManager.createQuery(
                "SELECT c FROM Cliente c", Cliente.class).getResultList();

        assertEquals(CANTIDAD_CLIENTES, clientes.size());
        assertTrue(clientes.stream().allMatch(c -> c.getDenominacion() != null
                && !c.getDenominacion().isBlank()));
        assertEquals(CANTIDAD_CLIENTES,
                clientes.stream().map(Cliente::getCuitCuil).distinct().count());
    }

    @Test
    void lasFacturasDeEjemploCuentanElIva() {
        List<FacturaVenta> facturas = entityManager.createQuery(
                "SELECT f FROM FacturaVenta f WHERE f.observaciones LIKE 'Ejemplo local %' ORDER BY f.id",
                FacturaVenta.class).getResultList();

        assertEquals(3, facturas.size());
        for (FacturaVenta factura : facturas) {
            assertFalse(factura.getDetalles().isEmpty());
            for (FacturaVentaDetalle detalle : factura.getDetalles()) {
                assertTrue(detalle.getImporteNeto() > 0, "el detalle debe tener importe neto");
                assertTrue(detalle.getImporteIva() > 0, "el detalle debe tener IVA calculado");
                assertEquals(detalle.getImporteNeto() + detalle.getImporteIva(),
                        detalle.getImporteSubtotal(), 0.01);
                assertEquals(21.0, porcentajeIva(detalle), 0.01);
            }
            double sumaSubtotales = factura.getDetalles().stream()
                    .mapToDouble(FacturaVentaDetalle::getImporteSubtotal).sum();
            assertEquals(sumaSubtotales, factura.getImporteTotal(), 0.01);
        }
    }

    @Test
    void volverASembrarNoDuplicaDatos() {
        long articulos = contar(Articulo.class);
        long clientes = contar(Cliente.class);
        long precios = contar(ListaPrecioArticulo.class);
        long facturas = contar(FacturaVenta.class);
        long listas = contar(ListaPrecio.class);

        datosIniciales.run();

        assertEquals(articulos, contar(Articulo.class));
        assertEquals(clientes, contar(Cliente.class));
        assertEquals(precios, contar(ListaPrecioArticulo.class));
        assertEquals(facturas, contar(FacturaVenta.class));
        assertEquals(listas, contar(ListaPrecio.class));
    }

    @Test
    void sembrarSobreUnaBaseVaciaTraeLosDatosDelTP() {
        // Lo que el TP de los TPs anteriores dejaba siempre cargado.
        assertEquals(1, entityManager.createQuery(
                "SELECT COUNT(u) FROM Usuario u WHERE u.usuario = 'jperez'", Long.class)
                .getSingleResult());
        assertEquals(1, entityManager.createQuery(
                "SELECT COUNT(pv) FROM PuntoVenta pv WHERE pv.descripcion = 'Sucursal Central'",
                Long.class).getSingleResult());
        assertEquals(1, entityManager.createQuery(
                "SELECT COUNT(ci) FROM CondicionIva ci WHERE ci.denominacion = 'Responsable Inscripto'",
                Long.class).getSingleResult());
        assertEquals(1, entityManager.createQuery(
                "SELECT COUNT(tm) FROM TipoMoneda tm WHERE tm.denominacion = 'Pesos Argentinos'",
                Long.class).getSingleResult());
        assertEquals(1, entityManager.createQuery(
                "SELECT COUNT(r) FROM Rubro r WHERE r.denominacion = 'Informatica'", Long.class)
                .getSingleResult());
        assertEquals(1, entityManager.createQuery(
                "SELECT COUNT(m) FROM Marca m WHERE m.denominacion = 'Logitech'", Long.class)
                .getSingleResult());
    }

    // ------------------------------------------------------------------
    // Utilidades
    // ------------------------------------------------------------------

    private <T> long contar(Class<T> tipo) {
        return entityManager.createQuery("SELECT COUNT(e) FROM " + tipo.getSimpleName() + " e", Long.class)
                .getSingleResult();
    }

    private ListaPrecio listaPorCodigo(String codigo) {
        List<ListaPrecio> listas = entityManager.createQuery(
                        "SELECT lp FROM ListaPrecio lp WHERE lp.codigo = :codigo", ListaPrecio.class)
                .setParameter("codigo", codigo)
                .getResultList();
        return listas.isEmpty() ? null : listas.get(0);
    }

    private double porcentajeIva(FacturaVentaDetalle detalle) {
        return detalle.getImporteIva() / detalle.getImporteNeto() * 100.0;
    }
}
