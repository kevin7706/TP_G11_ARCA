# Instrucciones para Codex — conectar ARCA homologación en Windows

## Solicitud del usuario que ejecuta este archivo

Revisá esta copia del proyecto, diagnosticá el fallo de conexión con ARCA en Windows y realizá las correcciones locales necesarias. Ejecutá las comprobaciones hasta obtener una respuesta real satisfactoria del diagnóstico. Conservá los cambios de mis compañeros y los datos guardados. Explicame brevemente lo que encontraste y cómo arrancarlo al terminar.

Avanzá con las operaciones reversibles necesarias para este objetivo. Si falta un dato que solo puedo aportar yo, completá primero las comprobaciones independientes y pedime ese dato concreto. Cumplí las autorizaciones y restricciones del entorno donde estás trabajando.

## Contexto del trabajo

Es un TP universitario de facturas de venta, basado en TP_G11_CRUD. Usa Java 17 o superior, Spring Boot 3.5.9, Maven Wrapper, JPA/Hibernate y frontend HTML + TypeScript + Vite. La versión corregida fue preparada por compañeros y se distribuyó como ZIP desde GitHub.

La copia de referencia en Linux está en:

```text
/home/tecno-booster/Escritorio/UTN Lean/UTN Lean/Desarrollo de Software/TPgrupalArca (corregido)
```

En Windows debés descubrir la ubicación real del proyecto. La raíz contiene `pom.xml`, `mvnw.cmd`, `src` y `frontend`. Ejecutá el backend con esa carpeta como directorio de trabajo, porque carga configuración y base de datos mediante rutas relativas.

El objetivo es usar los servicios de homologación de ARCA. El código de referencia utiliza estos endpoints:

```text
WSAA: https://wsaahomo.afip.gov.ar/ws/services/LoginCms
WSFE: https://wswhomo.afip.gov.ar/wsfev1/service.asmx
```

En la computadora del autor ya se verificó la autenticación y se autorizaron comprobantes ficticios con CAE en homologación. El 18/11/2026, el diagnóstico de la versión corregida devolvió `autenticado=true`, punto de venta 1, tipo de comprobante 6 y último autorizado 6. El número del último comprobante y el vencimiento del ticket varían con el uso y el tiempo.

En Windows aparece un mensaje equivalente a:

```text
No se pudo completar el diagnostico de homologacion: <tipo de excepcion>.
Revise certificado, autorizacion wsfe y conectividad.
```

Ese mensaje agrupa distintas causas. Determiná la causa a partir del código, la configuración efectiva y las excepciones disponibles.

## Causa probable que hay que comprobar

La copia corregida incluía un `application-local.properties` con rutas absolutas de la computadora Linux original:

```properties
arca.clave=/home/tecno-booster/arca-pruebas/privada_test.key
arca.certificado=/home/tecno-booster/arca-pruebas/certificado_test.crt
```

En Windows esas rutas deben señalar los archivos locales correspondientes. También pueden faltar los archivos, haberse usado una clave y un certificado de pares distintos, estar vencido el certificado, faltar la autorización de `wsfe`, existir un problema de red/TLS o una configuración efectiva diferente de la esperada.

## 1. Inspección inicial

1. Localizá la raíz correcta y leé las instrucciones aplicables de `AGENTS.md`, si existen.
2. Revisá los cambios locales con Git cuando la descarga incluya `.git`. Un ZIP puede funcionar sin información Git.
3. Inspeccioná estos archivos antes de modificar:
   - `application-local.properties`.
   - `src/main/resources/application.properties`.
   - `src/main/resources/application-homologacion.properties`.
   - `pom.xml` y `frontend/package.json`.
   - `src/main/java/com/utn/tpgrupal/service/arca/ArcaConfig.java`.
   - `WsaaService.java`, `WsfeService.java` y `SoapArca.java`, en ese mismo paquete.
   - `src/main/java/com/utn/tpgrupal/rest/ArcaEstadoController.java`.
4. Comprobá herramientas con `java -version`, `javac -version`, `node --version` y `npm.cmd --version`. El proyecto incluye Maven Wrapper. Java 21 es una opción compatible con la referencia.
5. Identificá las instancias del proyecto que ya estén ejecutándose. Revisá los puertos 8081 y 5174 y sus procesos antes de iniciar servidores adicionales.

## 2. Credenciales locales y configuración efectiva

Buscá primero en las rutas configuradas y en carpetas razonables del proyecto y del usuario, por ejemplo `arca-pruebas`, `credenciales` y `certificados`. Buscá por nombre y extensión sin imprimir contenidos privados. Si no encontrás la clave o el certificado, pedí al usuario la ubicación de sus archivos locales.

El certificado X.509 suele ser `.crt` o `.pem`. La clave de la implementación de referencia es PEM RSA PKCS#1 o PKCS#8 sin cifrar. `solicitud_test.csr` es la solicitud utilizada para obtener el certificado. La configuración de ejecución requiere la clave privada y el certificado emitido.

Verificá:

- Que ambos archivos existen, son archivos normales y pueden leerse desde la cuenta que ejecuta Java.
- Que el certificado está vigente según el reloj del equipo.
- Que la clave privada corresponde a la clave pública del certificado.
- Que la autorización de WSASS vincula el alias con `wsfe` y el CUIT representado configurado.
- Que la configuración cargada corresponde a la copia corregida que se quiere ejecutar.

Podés usar OpenSSL si está disponible. Para inspeccionar metadatos públicos:

```powershell
openssl x509 -in "C:/ruta/al/certificado_test.crt" -noout -subject -dates
```

Compará las claves públicas mediante resúmenes criptográficos calculados en memoria. Evitá mostrar o guardar la clave privada en logs, respuestas o archivos temporales innecesarios.

El CUIT del titular del certificado identifica al computador. `arca.cuit` identifica al representado autorizado en WSASS. Pueden coincidir, como en la configuración del autor, o diferir si existe una autorización de representación válida. Conservá el CUIT representado respaldado por esa autorización. Si falta información para determinarlo, preguntá al usuario.

El archivo principal de referencia carga:

```properties
spring.config.import=optional:file:./application-local.properties
```

Revisá además variables de entorno, opciones del IDE y argumentos de arranque. Las propiedades explícitas del archivo local pueden prevalecer sobre propiedades del archivo base que utilizan placeholders de variables. Confirmá qué valor efectivo usa Spring sin exponer secretos.

Actualizá el archivo local con las rutas que hayas encontrado. Usá barras `/` en rutas de Windows dentro de `.properties`. Este es un ejemplo de estructura, cuyos valores entre corchetes debés resolver antes de ejecutar:

```properties
arca.habilitada=true
arca.cuit=[CUIT REPRESENTADO AUTORIZADO, 11 DIGITOS]
arca.clave=C:/Users/[USUARIO]/arca-pruebas/privada_test.key
arca.certificado=C:/Users/[USUARIO]/arca-pruebas/certificado_test.crt
arca.tipo-comprobante=6
arca.punto-venta=1
arca.emisor-razon-social=TPgrupalArca - Emisor de prueba
arca.emisor-domicilio=Domicilio ficticio de homologacion
arca.emisor-condicion-iva=Prueba de homologacion - sin validez fiscal
```

Conservá el punto de venta y el tipo de comprobante si el equipo ya tiene una combinación de homologación confirmada. El tipo 6 corresponde a Factura B. Los datos de emisor del ejemplo son etiquetas para la impresión del TP.

Mantené `application-local.properties`, las claves, certificados y `datos/` excluidos de Git. Si aparecen archivos privados ya versionados, informá el hallazgo y prepará una corrección local del seguimiento sin borrar los archivos necesarios. No publiques credenciales ni las incluyas en la respuesta final.

## 3. Diagnóstico según el error

| Error o síntoma | Qué comprobar y corregir |
| --- | --- |
| `NoSuchFileException`, `FileNotFoundException` | Rutas de Linux copiadas, nombre del archivo, extensión oculta de Windows y carpeta efectiva de arranque. |
| `AccessDeniedException` | Permiso de lectura de la cuenta que ejecuta Java y ubicación de los archivos. |
| `CertificateException`, certificado vencido o aún no válido | Archivo X.509 correcto, vigencia y reloj del sistema. La renovación de un certificado vencido necesita el trámite correspondiente de WSASS. |
| Fallo al cargar la clave o firmar CMS | Formato PEM soportado, integridad del archivo y correspondencia clave/certificado. Si hace falta convertir un formato, conservá el original y generá una copia local protegida. |
| `UnknownHostException`, timeout o conexión rechazada | Resolución DNS, acceso a los dominios oficiales, proxy y conectividad HTTPS. |
| `SSLHandshakeException` | Reloj, versión de Java, cadena de certificados y posible inspección TLS de la red. Corregí la causa manteniendo la validación TLS. |
| SOAP Fault de autorización | Alias, servicio `wsfe`, ambiente y CUIT representado autorizado en WSASS. |
| `alreadyAuthenticated` o equivalente de WSAA | Existencia de un ticket vigente para ese certificado y servicio. Reutilizá el ticket local válido o identificá su vencimiento. Evitá repetir solicitudes de autenticación indefinidamente. |
| `The file is locked` o H2 en uso | Instancia previa del proyecto con la misma base. Detené ordenadamente solo la instancia identificada y conservá los datos. |
| Puerto ocupado | Identificá al proceso dueño. Si cambiás el puerto del backend, actualizá también la URL que usa el frontend. |

En la referencia, `WsaaService` reutiliza tickets hasta su vencimiento y guarda su caché en `datos/wsaa-<CUIT>-<huella>.properties`. La carpeta debe ser escribible por el proceso. Los tickets contienen `token` y `sign`, que también deben tratarse como privados. Un ticket copiado puede estar vencido, lo cual debe manejarse renovándolo mediante el flujo existente.

Si los mensajes actuales impiden diagnosticar el fallo, aplicá un cambio acotado para distinguir categorías y códigos de error. Sanitizá mensajes de excepciones y SOAP antes de registrarlos o devolverlos. Conservá fuera de la respuesta cuerpos SOAP completos, tokens, firmas, CMS y contenido de claves. Si agregás código de diagnóstico, probá específicamente que no exponga esos valores.

## 4. Arranque en PowerShell y prueba real de conexión

Desde la raíz del proyecto:

```powershell
.\mvnw.cmd -Pdev spring-boot:run "-Dspring-boot.run.profiles=homologacion" "-Dspring-boot.run.arguments=--server.port=8081"
```

El perfil Maven `-Pdev` incluye el driver H2. El perfil Spring `homologacion` usa la base persistente `datos/facturacion_arca.mv.db`. El perfil Spring `dev` tiene otra configuración de datos, por lo que el comando de esta guía utiliza explícitamente `homologacion`.

Esperá el mensaje de aplicación iniciada y comprobá, desde otra terminal:

```powershell
Invoke-RestMethod http://localhost:8081/api/arca/estado | Format-List
```

La respuesta satisfactoria incluye estos campos:

```json
{
  "ambiente": "HOMOLOGACION",
  "autenticado": true,
  "ticketVencimiento": "FECHA DEVUELTA POR ARCA",
  "puntoVenta": 1,
  "tipoComprobante": 6,
  "ultimoAutorizado": 6
}
```

Este JSON es ilustrativo. La fecha y el número del último comprobante deben venir de ARCA. El diagnóstico de referencia llama a WSAA y consulta `FECompUltimoAutorizado` de WSFE. Comprobá la respuesta real del endpoint y su estado HTTP.

Si falla, seguí diagnosticando y corrigiendo dentro del alcance autorizado. Evitá declarar el problema resuelto por el solo hecho de compilar o iniciar Spring. Si falta una credencial o una autorización del portal, indicá exactamente qué se pudo verificar y qué dato o acción está pendiente.

## 5. Frontend y comprobaciones de integración

Después de verificar el diagnóstico, desde otra terminal situada en la raíz:

```powershell
Set-Location .\frontend
npm.cmd ci
$env:VITE_API_BASE_URL = "http://localhost:8081"
npm.cmd run dev -- --port 5174 --strictPort
```

Abrí `http://localhost:5174`. Comprobá que aparece API conectada, se carga la grilla y se puede crear y editar una factura pendiente. Si el frontend ya estaba abierto con otra URL de backend, reinicialo con la variable correcta.

El diagnóstico permite verificar la conexión sin crear comprobantes. Si el usuario también pidió explícitamente emitir una factura de prueba, usá una pendiente identificada como prueba, con fecha vigente, punto de venta correcto, moneda PES y receptor coherente. Para Factura B puede repetirse el caso de un renglón de $100 más IVA 21%, total $121, Consumidor Final sin identificar cuando corresponda. Confirmá CAE, vencimiento, bloqueo de edición/eliminación y PDF. Diferenciá en el informe una conexión comprobada de una emisión comprobada.

## 6. Verificación de cambios y entrega

- Ejecutá las pruebas apropiadas para los cambios realizados. Para una corrección exclusiva de rutas/configuración, priorizá el diagnóstico real. Si cambiaste Java o frontend, ejecutá las pruebas relevantes y compilá.
- Comandos disponibles en la raíz y en `frontend`, respectivamente:

```powershell
.\mvnw.cmd test
```

```powershell
npm.cmd test
npm.cmd run build
```

- Si la corrección solo requería configuración local, mantené el cambio centrado en esa configuración. Si la causa exige código, corregí el origen y preservá las interfaces y reglas existentes.
- Entregá un resumen de la causa comprobada, archivos cambiados, pruebas y resultado real de `/api/arca/estado`, con datos sensibles omitidos.
- Indicá los comandos de arranque desde la ubicación real del compañero y dónde quedó su configuración privada.
- Informá qué servidores dejaste abiertos. Al entregar el control de arranque al usuario, cerrá los servidores temporales que hayas iniciado para liberar la base y los puertos.

## Fuentes para errores del portal o protocolo

Usá la documentación oficial vigente si necesitás confirmar un procedimiento de WSASS o interpretar un error de ARCA:

- Certificados de homologación y manuales de WSASS: https://www.afip.gov.ar/ws/documentacion/certificados.asp
- Documentación WSAA: https://www.afip.gov.ar/ws/documentacion/wsaa.asp
- Servicio WSFE de homologación: https://wswhomo.afip.gov.ar/wsfev1/service.asmx

Este archivo contiene contexto e instrucciones. Las credenciales deben estar disponibles en la computadora donde se realiza la configuración.
